<?php
$light_logo_id = alpaca_get_theme_mod( 'alpaca_site_footer_bottom_light_color_scheme_logo' );
//$dark_logo_id = alpaca_get_theme_mod( 'alpaca_site_footer_bottom_dark_color_scheme_logo' );
$has_logo = alpaca_is_item_exists( $light_logo_id );
$has_bottom_menu = alpaca_has_nav_menu( 'footer-bottom-menu' );
?>
<div class="dark-color middle-footer">
<div class="container">
<div class="footer-site layout-grid-4">

    <?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
        <div class="col col-1">
            <div class="widget-col">
            <?php dynamic_sidebar('footer-1'); ?>
            </div>
        </div>
    <?php endif; ?>
      
    <?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
        <div class="col col-2">
            <div class="widget-col">
                <h3>Links</h3>
            <?php dynamic_sidebar('footer-2'); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
        <div class="col col-3">
            <div class="widget-col">
            <?php dynamic_sidebar('footer-3'); ?>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
        <div class="col col-4">
            <div class="widget-col">
            <?php dynamic_sidebar('footer-4'); ?>
            </div>
        </div>
    <?php endif; ?>

      </div>
      </div>
   </div>