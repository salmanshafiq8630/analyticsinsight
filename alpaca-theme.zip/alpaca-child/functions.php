<?php
add_action('wp_enqueue_scripts', 'alpaca_child_enqueue_scripts');
function alpaca_child_enqueue_scripts(){

    wp_enqueue_style( 'alpaca-child-theme-style', get_stylesheet_uri(), array( 'alpaca-theme-style' ) );
    wp_enqueue_style( 'alpaca-child-theme-responsive', get_stylesheet_directory_uri().'/assets/css/responsive.css', array( 'alpaca-theme-style' ) );

}

add_filter( 'alpaca_front_inline_styles_handler', 'alpaca_child_inline_style_handler', 999 );
function alpaca_child_inline_style_handler( $handler ) {

    return 'alpaca-child-theme-style';

}

/********Include ads customizer file */
require_once('inc/ads-customizer.php');
require_once('inc/second-walker-nav-menu.php');
require_once('inc/shortcode.php');
require_once('inc/cpt.php');
require_once('inc/ajax.php');
require_once('inc/theme-setup.php');
require_once('inc/widgets.php');
require_once('inc/menus.php');
require_once('inc/thumbnail-crop.php');

add_filter( 'body_class', 'alpaca_custom_class' );
function alpaca_custom_class( $classes ) {
    foreach($classes as $key => $class) {
		if( $class != "page-template-default" ){
        $classes[] = 'page-template-default';
    }
}
	return $classes;
}

add_filter( 'body_class', function( $classes ) {
	foreach($classes as $key => $class) {
		if( $class == "page-template-fullwidth" ){
			unset($classes[$key]);
		}
	}
	return $classes;
}, 1000);

/********* CUSTOM WORK FOR NEW SCOPE JS*/
function alpaca_theme_enqueue_scripts() {
	/**
	 * frontend ajax requests.
	 */
	wp_enqueue_script( 'alpaca-custom', get_stylesheet_directory_uri() . '/js/custom.js', array('jquery'), null, true );
	wp_localize_script( 'alpaca-custom', 'frontend_ajax_object',
		array( 
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'alpaca_theme_enqueue_scripts' );
