<?php
 $show_signup_form = alpaca_is_mc4wp_activated() && alpaca_module_enabled( 'alpaca_site_footer_show_signup_form' );
 
 ?>
            </div> <!-- end of #content -->
            
            <?php //do_action( 'alpaca_the_site_footer' ); ?>
        </div> <!-- end of #page -->
        <?php $show_signup_form ? get_template_part( 'template-parts/site-footer/footer-signup' ) : ''; ?>
        <?php get_template_part( 'template-parts/site-footer/four-column-layout' ); ?>
        <?php  get_template_part( 'template-parts/site-footer/bottom' );?>
        <?php get_template_part( 'template-parts/site-footer/fullmenu' ); ?>
        <?php get_template_part( 'template-parts/site-footer/popup-signup-form' ); ?>
        
        <?php get_template_part( 'template-parts/site-footer/fullscreen-search' ); ?>
        
        <?php wp_footer(); ?>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    </body>
    <script type="text/javascript">
     function googleTranslateElementInit() {
      new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
     }
    </script>
    <script type="text/javascript">
    jQuery(document).ready(function(){
        <?php if( is_page_template( 'template_women_mag.php' ) ):?>
        spx_load_women_magazines_data(1);
        <?php endif;?>
        <?php if( is_page_template( 'template_magazine.php' ) ):?>
        spx_load_mag_data(1);
        <?php endif;?>
        <?php if( is_page_template( 'template_reports.php' ) ):?>
        spx_load_report_data(1);
        <?php endif;?>
        <?php if( is_page_template( 'template_web_stories.php' ) ):?>
        spx_load_web_tech_stories_data(1);
        <?php endif;?>


        // Magazine Ajax

        function spx_load_mag_data(num){

            var page_number = num;
            jQuery.ajax({
                type: "POST",
                dataType: "JSON",
                url: '<?php echo admin_url('admin-ajax.php');?>',
                data: {action:'spx_get_magazine_data',page_number:page_number},
                beforeSend: function() {
                
                jQuery('.pagination-container.load-more').addClass('loading');

                },
                success: function(data){

                    var htmlData = data.html;
                    var paginate = data.paginate;
                    jQuery('#row_magazine').append(htmlData);
                    jQuery('#row_magazine_load_more').html(paginate);
                    jQuery('.pagination-container.load-more').removeClass('loading');

                }
            });

        }

        jQuery(document).on('click','.mag_load.load-more-btn',function(){

            var num = jQuery(this).attr('id');
            spx_load_mag_data(num);
            
        });
        // Magazines Ajax End

        // Reports Ajax
     

        function spx_load_report_data(num){

            var page_number = num;
            jQuery.ajax({
                type: "POST",
                dataType: "JSON",
                url: '<?php echo admin_url('admin-ajax.php');?>',
                data: {action:'spx_get_reports_data',page_number:page_number},
                beforeSend: function() {
                
                jQuery('.pagination-container.load-more').addClass('loading');

                },
                success: function(data){

                    var htmlData = data.html;
                    var paginate = data.paginate;
                    jQuery('#row_reports').append(htmlData);
                    jQuery('#row_reports_load_more').html(paginate);
                    jQuery('.pagination-container.load-more').removeClass('loading');

                }
            });

        }

        jQuery(document).on('click','.report_load.load-more-btn',function(){

            var num = jQuery(this).attr('id');
            spx_load_report_data(num);
            
        });
        // Reports Ajax End

        // Women Magazines Ajax
        

        function spx_load_women_magazines_data(num){

            var page_number = num;
            jQuery.ajax({
                type: "POST",
                dataType: "JSON",
                url: '<?php echo admin_url('admin-ajax.php');?>',
                data: {action:'spx_get_women_magazines_data',page_number:page_number},
                beforeSend: function() {
                
                jQuery('.pagination-container.load-more').addClass('loading');

                },
                success: function(data){

                    var htmlData = data.html;
                    var paginate = data.paginate;
                    jQuery('#row_women_magazine').append(htmlData);
                    jQuery('#row_women_magazine_load_more').html(paginate);
                    jQuery('.pagination-container.load-more').removeClass('loading');

                }
            });

        }

        jQuery(document).on('click','.Women_Magazines.load-more-btn',function(){

            var num = jQuery(this).attr('id');
            spx_load_women_magazines_data(num);
            
        });
        // Women Magazines Ajax End

        // Web Tech Stories AJAX START

        function spx_load_web_tech_stories_data(num){

        var page_number = num;
        jQuery.ajax({
            type: "POST",
            dataType: "JSON",
            url: '<?php echo admin_url('admin-ajax.php');?>',
            data: {action:'spx_get_web_stories_data',page_number:page_number},
            beforeSend: function() {
            
            jQuery('.pagination-container.load-more').addClass('loading');

            },
            success: function(data){

                var htmlData = data.html;
                var paginate = data.paginate;
                jQuery('#row_web_tech_stories').append(htmlData);
                jQuery('#row_web_tech_stories_load_more').html(paginate);
                jQuery('.pagination-container.load-more').removeClass('loading');

            }
        });

        }

        jQuery(document).on('click','.web_tech_load.load-more-btn',function(){

        var num = jQuery(this).attr('id');
        spx_load_web_tech_stories_data(num);

        });

        // Web Tech Stories AJAX END

        // Magazines slider in sidebar top
        jQuery('.mag_slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        
        autoplaySpeed: 2000,
        });

        jQuery('.events_media_slider').slick({
        slidesToShow: 4,
        dots: true,
        slidesToScroll: 1,
        centerMode: false,
        responsive: [
        {
            breakpoint: 1024,
            settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            centerMode: false,
          
            }
        },
        {
            breakpoint: 768,
            settings: {
            slidesToShow: 1,
            centerMode: false, 
            slidesToScroll: 1
            }
        }
        ]

        });

        jQuery('.Featured_slider').slick({
        slidesToShow: 4,
        dots: true,
        slidesToScroll: 1,
        centerMode: false,
        responsive: [
        {
            breakpoint: 1024,
            settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
            centerMode: false,
          
            }
        },
        {
            breakpoint: 768,
            settings: {
            slidesToShow: 1,
            centerMode: false, 
            slidesToScroll: 1
            }
        }
        ]

        });

    });
    </script>
    
</html>
