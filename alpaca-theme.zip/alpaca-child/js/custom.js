jQuery(document).ready(function(){
//alert();
    home_page_latest_news();
    var page_no = 1
    function home_page_latest_news(){

       // var page_number = num;
       jQuery.ajax({
           type: "POST",
           dataType: "JSON",
           url : frontend_ajax_object.ajaxurl,
           data: {action:'home_page_latest_news_ajax',page_no:page_no},
           beforeSend: function() {
           
           jQuery('.pagination-container.load-more').addClass('loading');

           },
           success: function(data){
               page_no++;
               var htmlData = data.html;
               var paginate = data.paginate;
               jQuery('#latest_post_home').append(htmlData);
               jQuery('#home_latest_news_home_load_more').html(paginate);
               jQuery('.pagination-container.load-more').removeClass('loading');

           }
       });

   }

   jQuery(document).on('click','.home_latest_new.load-more-btn',function(){

        // var num = jQuery(this).attr('id');
        home_page_latest_news();
   
    });

});
