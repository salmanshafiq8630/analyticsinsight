<?php
get_header();
if(is_user_logged_in()):
    $user_id =  get_current_user_id();
    $member_subscriptions = pms_get_member_subscriptions( array( 'user_id' => $user_id, 'include_abandoned' => true ) );
    $subscription_status = $member_subscriptions[0]->status;
    $subscription_plan = pms_get_subscription_plan($member_subscriptions[0]->subscription_plan_id);
    //$digital_magazine_url = get_field('digital_magazine_url');
    $digital_report_url = get_field('digital_report_url');
    if(!empty($digital_magazine_url)):
    if((strpos($digital_magazine_url,'https')!==false) || strpos($digital_magazine_url,'http')!==false){
    $digital_url = $digital_report_url;
    }else{
    $digital_url = site_url($digital_report_url);
    }
    endif;
    if($subscription_status=='active'){

    
?>
<header class="entry-header page-header">
    	<div class="header-text">
        	<h1 class="entry-title"><?php the_title()?></h1>
        </div>
</header>
<div class="main">
<div class="container">
<?php if(!empty($digital_report_url)):?>
    <iframe style="width: 100%; height: 100vh;" src="<?php echo $digital_report_url;?>">
        <span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start"></span>
        <span data-mce-type="bookmark" style="display: inline-block; width: 0px; overflow: hidden; line-height: 0;" class="mce_SELRES_start"></span>
    </iframe>
<?php endif;?>
</div>	
</div>	

<?php
}else{
    wp_redirect('/plus');
}
else:
    wp_redirect('/plus');
endif;
get_footer();