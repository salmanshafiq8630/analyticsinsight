<?php
/****************** Shortcode foe media and events */
function event_and_media_partners() { 
	ob_start();
    ?>
    <div class="section-header">
        <h5 class="section-title">Event and Media Partners</h5>
    </div>
    <ul class="events_media_slider">
    <?php
    $args = array(
                'post_type' => 'event-media',
                'posts_per_page' => -1,
                'post_status' => 'publish',
    );
    $query = new WP_Query( $args );
    while ( $query->have_posts() ) : $query->the_post();
    $logo_id = get_field('thumbnail_logo');
    //echo $logo_id;
    $image_url = etheme_get_resized_url($logo_id,200,70,true);
    
    if($logo_id):
    ?>
        <li>
        <img src="<?php echo $image_url;?>" alt="<?php echo get_the_title();?>" />
        </li>
    <?php
    endif;
    endwhile;
    wp_reset_postdata();
    ?>
    </ul>
	<?php
	$content = ob_get_contents(); 
	ob_get_clean();
	return trim($content);
	}
	 
add_shortcode('event_media_partners', 'event_and_media_partners');


/****************** Shortcode foe media and events end */

/****************** Shortcode Analytics Insight Featured */
function analytics_insight_featured() { 
	ob_start();
    ?>
    <div class="section-header">
        <h5 class="section-title">Analytics Insight Featured the Most Recognized Brands in the World</h5>
    </div>
    <ul class="Featured_slider">
    <?php
    $args = array(
                'post_type' => 'ai-featured',
                'posts_per_page' => -1,
                'post_status' => 'publish',
    );
    $query = new WP_Query( $args );
    while ( $query->have_posts() ) : $query->the_post();
    $logo_id = get_field('thumbnail_logo');
    $image_url = etheme_get_resized_url($logo_id,200,70,true);
    if($logo_id):
    ?>
        <li>
         <img src="<?php echo $image_url;?>" alt="<?php echo get_the_title();?>" />
        </li>
    <?php
    endif;
    endwhile;
    wp_reset_postdata();
    ?>
    </ul>
	<?php
	$content = ob_get_contents(); 
	ob_get_clean();
	return trim($content);
	}
	 
add_shortcode('ai_feature', 'analytics_insight_featured');


/****************** Analytics Insight Featured end */

/****************** Shortcode Analytics Insight Lists */
function spx_analytics_insight_lists() { 
	ob_start();
    ?>
    <div class="section-header">
        <h5 class="section-title">Analytics Insight Lists</h5>
    </div>
    <ul class="Featured_slider">
    <?php
    $args = array(
                'post_type' => 'ai-lists',
                'posts_per_page' => -1,
                'post_status' => 'publish',
    );
    $query = new WP_Query( $args );
    while ( $query->have_posts() ) : $query->the_post();
    $logo_id = get_field('analytics_insight_lists_logo');
    $image_url = etheme_get_resized_url($logo_id,250,70,true);
    $list_target = get_field('target_ai_list');
    $list_url = get_field('analytics_insight_lists_ulr');
    if((strpos($list_url,'https')!==false) || strpos($list_url,'http')!==false){
    $list_url = $list_url;
    }else{
    $list_url = site_url($list_url);
    }
    if($logo_id && $list_url):
    ?>
        <li>
        <?php
        //$image_attributes = wp_get_attachment_image_src($logo_id,'full');
        ?>
        <a href="<?php echo $list_url;?>" target="<?php echo $list_target;?>">
        <img src="<?php echo $image_url;?>" alt="<?php echo get_the_title();?>" />
        </a>
        </li>
    <?php
    endif;
    endwhile;
    wp_reset_postdata();
    ?>
    </ul>
	<?php
	$content = ob_get_contents(); 
	ob_get_clean();
	return trim($content);
	}
	 
add_shortcode('ai_lists', 'spx_analytics_insight_lists');


/****************** Analytics Insight Lists END */

/**** Shortcode advertise*/
/*********
 * 
 * advertise shortcode for components
 */

function advertise_components_shortcode($attr) { 
	ob_start();

	$id = $attr['id'];
	$title = $attr['title'];
    $ad_url = get_field('ad_url', $id);
    $ad_banner = get_field('ad_banner', $id);
    $target = get_field('target', $id);
    if($ad_banner && $ad_url):
    ?>
    <a href="<?php echo $ad_url;?>" target="<?php echo $target;?>">
    <?php
    $image_attributes = wp_get_attachment_image_src($ad_banner,'full');
    if ( $image_attributes ) : ?>
	<img src="<?php echo $image_attributes[0]; ?>" width="<?php echo $image_attributes[1]; ?>" height="<?php echo $image_attributes[2]; ?>" alt="<?php echo $title;?>" />
    <?php endif; ?>
    </a>
    <?php
    endif;
	$content = ob_get_contents(); 
	ob_get_clean();
	return trim($content);
	}
	
add_shortcode('advertise', 'advertise_components_shortcode');


/**********Shortcode For Magazine Template */

function spx_magazine_page_with_active_members(){

    ob_start();

    echo '<div class="postslayout-gridcolumn-4grid-style-2">
            <div class="posts-wrapper layout-grid-4" id="row_magazine">
            </div>
            <div id="row_magazine_load_more"></div>
          </div>';

    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('analyticsinsight_magazine' , 'spx_magazine_page_with_active_members');

/*********end */

/**********Shortcode For Women Magazine Template */

function spx_women_magazines_(){

    ob_start();

    echo '<div class="postslayout-gridcolumn-4grid-style-2">
            <div class="posts-wrapper layout-grid-4" id="row_women_magazine">
            </div>
            <div id="row_women_magazine_load_more"></div>
          </div>';

    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('analyticsinsight_women_magazines' , 'spx_women_magazines_');
/**********END Shortcode For Women Magazine Template */

/*****Shortcode For Reports */
function spx_reports_page_(){

    ob_start();

    echo '<div class="postslayout-gridcolumn-4grid-style-2">
            <div class="posts-wrapper layout-grid-4" id="row_reports">
            </div>
            <div id="row_reports_load_more"></div>
          </div>';

    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('analyticsinsight_reports' , 'spx_reports_page_');

/*****Footer Shortcode For Magazine */
function spx_footer_mag_(){

    ob_start();
    $per_page   = 1;
    $args       = array(
                        'post_type' => 'magazine',
                        'posts_per_page' => $per_page,
                        'post_status' => 'publish',
                        'tax_query'      => array(
                            array(
                                'taxonomy' => 'magazine-category',
                                'operator' => 'NOT EXISTS'
                            )
                        )                          
    );

    $query      = new WP_Query( $args );
    $post_count = $query->found_posts;

    while ( $query->have_posts() ) : $query->the_post();
    $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);

    $html .= '<div class="post-'.get_the_ID().'">
                <div class="featured-thumbnail">
                <a href="'.get_the_permalink().'"><img src="'.$image_url.'" alt="'.get_the_title().'" /></a>
                </div>
                <div class="article-content">
                    <div class="read-more-magazine">
                        <div class="read-more-btn">
                        <a href="'.site_url('plus').'"><span>Subscribe</span></a>
                        </div>
                    </div>
                </div>
             </div>';
    echo $html;

    endwhile;
    wp_reset_postdata();
    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('analyticsinsight_footer_mag' , 'spx_footer_mag_');

/*********Magazine slider home page********** */
function spx_magazine_slider(){
    ob_start();
    ?>
    <ul class="mag_slider">
    <?php
    $args = array(
                'post_type' => 'magazine',
                'posts_per_page' => 4,
                'post_status' => 'publish',
                'tax_query'      => array(
                    array(
                        'taxonomy' => 'magazine-category',
                        'operator' => 'NOT EXISTS'
                    )
                )
                //  'paged' => $paged,

    );
    $query = new WP_Query( $args ); 

    $post_count = $query->found_posts;

    while ( $query->have_posts() ) : $query->the_post();
    $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);
    ?>
        <li>
        <a href="<?php echo get_the_permalink();?>"><img src="<?php echo $image_url;?>" alt="<?php echo get_the_title();?>" /></a>
        <!-- <a href="<?php //echo get_the_permalink();?>"><?php //echo get_the_post_thumbnail(get_the_ID(),'large');?></a> -->
        </li>
    <?php 
    endwhile;
    wp_reset_postdata();
    ?>
    </ul>
    <?php
    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);
}
add_shortcode('spx_magazine_slider' , 'spx_magazine_slider');

/*******Home page Magazine Shortcode */
function spx_magazine_home_page_with_active_members(){
    ob_start();

    echo '<div class="postslayout-gridcolumn-4grid-style-2">
    <div class="posts-wrapper layout-grid-4">';

    $per_page   = 4;
    $paged      = $_POST['page_number'];
    $next_page  = $paged+1;
    $args       = array(
                        'post_type' => 'magazine',
                        'posts_per_page' => $per_page,
                        'post_status' => 'publish',
                        'paged' => $paged,
                        'tax_query'      => array(
                        array(
                            'taxonomy' => 'magazine-category',
                            'operator' => 'NOT EXISTS'
                        )
                    )
    );
    $query      = new WP_Query( $args ); 

    if ( $query->have_posts() ) : 
        $n          = 1; 
        $post_count = $query->found_posts;

        while ( $query->have_posts() ) : $query->the_post();
        $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);

        $web_magazine_url = get_field('web_magazine_url');

        if(!empty($web_magazine_url)):

                if((strpos($web_magazine_url,'https')!==false) || strpos($web_magazine_url,'http')!==false){

                $web_url = $web_magazine_url;

                }else{

                $web_url = site_url($web_magazine_url);

                }

        endif;

        echo '<article class="post-'.get_the_ID().' col">
                <div class="featured-thumbnail">
                <img src="'.$image_url.'" alt="'.get_the_title().'" />
                </div>
                <div class="article-content">
                    <header class="entry-header entry-header-mag">
                    <h2 class="entry-title">
                    <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                    </h2>            
                    </header>
                <div class="read-more-magazine">
                    <div class="read-more-btn">
                    <a href="'.get_the_permalink().'"><span>Digital Version</span></a>
                    </div>
                    <div class="read-more-btn">
                    <a href="'.$web_url.'"><span>Web Version</span></a>
                    </div>
                </div>
                </div>
            </article>';


        $n++;
        endwhile;
        wp_reset_postdata();
    endif;

    echo '</div>
            <nav class="navigation pagination read-more-magazine">
                    <div class="pagination-container">
                        <a href="'.site_url('magazines').'" class="load-more-btn">
                        <span>View More Magazines</span>
                        </a>
                    </div>
            </nav>
            </div>';
    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);
}
add_shortcode('analyticsinsight_magazine_home' , 'spx_magazine_home_page_with_active_members');

/********** Shortcode Home page reports */
function spx_reports_home_page_with_active_members(){
    ob_start();

    echo '<div class="postslayout-gridcolumn-4grid-style-2">
    <div class="posts-wrapper layout-grid-4">';

    $per_page   = 4;
    $paged      = $_POST['page_number'];
    $next_page  = $paged+1;
    $args       = array(
                        'post_type' => 'report',
                        'posts_per_page' => $per_page,
                        'post_status' => 'publish',
                        'paged' => $paged,
    );
    $query      = new WP_Query( $args ); 

    if ( $query->have_posts() ) : 
        $n          = 1; 
        $post_count = $query->found_posts;

        while ( $query->have_posts() ) : $query->the_post();
        $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);

        $web_magazine_url = get_field('web_magazine_url');

        if(!empty($web_magazine_url)):

            if((strpos($web_magazine_url,'https')!==false) || strpos($web_magazine_url,'http')!==false){

            $web_url = $web_magazine_url;

            }else{

            $web_url = site_url($web_magazine_url);

            }

        endif;

        echo '<article class="post-'.get_the_ID().' col">
                <div class="featured-thumbnail">
                <a href="'.get_the_permalink().'"><img src="'.$image_url.'" alt="'.get_the_title().'" /></a>
                </div>
                <div class="article-content">
                    <header class="entry-header entry-header-mag">
                    <h2 class="entry-title">
                    <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                    </h2>            
                    </header>
                <div class="read-more-magazine">
                    <div class="read-more-btn">
                    <a href="'.get_the_permalink().'"><span>Read More</span></a>
                    </div>
                </div>
                </div>
            </article>';


        $n++;
        endwhile;
        wp_reset_postdata();
    endif;

    echo '</div>
            <nav class="navigation pagination read-more-report">
                <div class="pagination-container">
                <a href="'.site_url('reports-5').'" class="load-more-btn">
                <span>View More Reports</span>
                </a>
                </div>
            </nav>   
          </div>';
    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);
}
add_shortcode('analyticsinsight_reports_home' , 'spx_reports_home_page_with_active_members');

/*************** */
/*****Shortcode For Web Tech Stories Template START*/
function spx_web_tech_stories_page_(){

    ob_start();

    echo '<div class="layout-4-col WebTechStories postslayout-gridcolumn-4grid-style-2">
            <div class="posts-wrapper layout-grid-4" id="row_web_tech_stories">
            </div>
            <div id="row_web_tech_stories_load_more"></div>
          </div>';

    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('web_tech_stories' , 'spx_web_tech_stories_page_');

/*****Shortcode For Web Tech Stories Template END */

/*****Shortcode For Web Tech Stories HOME PAGE*/
function spx_web_tech_stories_page_home_(){

    ob_start();
    echo '<div class="layout-4-col WebTechStories postslayout-gridcolumn-4grid-style-2">
           <div class="posts-wrapper layout-grid-4" id="row_web_tech_stories">';
    
    $per_page   = 4;
    $args       = array(
                        'post_type' => 'web-story',
                        'posts_per_page' => $per_page,
                        'post_status' => 'publish',
    );
    $query      = new WP_Query( $args ); 

    if ( $query->have_posts() ) : 
        $n          = 1; 
        $post_count = $query->found_posts;

        while ( $query->have_posts() ) : $query->the_post();
        $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);
    
        echo '<div class="story-'.get_the_ID().' col">
            <div class="featured-thumbnail">
            <a href="'.get_the_permalink().'"><img src="'.$image_url.'" alt="'.get_the_title().'" /></a>
            </div>
            <div class="article-content">
                <header class="entry-header entry-header-web-stories">
                <h2 class="entry-title">
                <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                </h2>
                </header>
                <div class="read-more-magazine">
                    <div class="read-more-btn">
                    <a href="'.get_the_permalink().'"><span>Read More</span></a>
                    </div>
                </div>
            </div>
            </div>';
         
        endwhile;
        wp_reset_postdata();
    endif;
    echo '</div>
    <nav class="navigation pagination">
			<div class="pagination-container load-more">
				<h2 class="screen-reader-text">Stories Navigation</h2>
				<a href="'.site_url('web-tech-stories').'"  class="load-more-btn  manual">
					<span>Load More Stories</span>
				</a>
			</div>
    </nav>
    </div>';
    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('web_tech_stories_home' , 'spx_web_tech_stories_page_home_');

/*****Shortcode For Web Tech Stories HOME PAGE END */


/**********Breaking News Home Page START*/
function spx_breaking_news_page_home_(){

    ob_start();
    
    $per_page   = 12;
    $args       = array(
                        'post_type' => 'post',
                        'posts_per_page' => $per_page,
                        'post_status' => 'publish',
                        'meta_query' => array(
                                            array(
                                                    'key' => 'breaking_news',
                                                    'value' => true,
                                                    'compare' => '='
                                                ),
                        ),
    );
    $query      = new WP_Query( $args ); 

    if ( $query->have_posts() ) : 
        $post_count = $query->found_posts;
        ?>
        <div class="breaking_marq">
        <marquee class="breaking_news" behavior="alternate" scrolldelay="100" scrollamount="3" onmouseover="this.stop();" onmouseout="this.start();">
        <?php
        $n=1;
        while ( $query->have_posts() ) : $query->the_post();
        $cate_arr = get_the_category( get_the_ID() );
        ?>
        <div class="item">
          <div class="left_cate">
          <a href="<?php echo get_category_link($cate_arr[0]->term_id);?>" class="hyper_breaking_cate"><?php echo $cate_arr[0]->name;?></a>  
          </div>
          <div class="title_right">
          <a href="<?php the_permalink();?>" class="hyper_breaking"><?php the_title();?></a>
          </div>         
        </div>
        <!-- <?php if( $n != $post_count ){?> | <?php } ?> -->
        <?php
         $n++;
        endwhile;
        ?>
        </marquee>
         </div>
        <?php
        wp_reset_postdata();
    endif;
   
    $content = ob_get_contents(); 
    ob_get_clean();
    return trim($content);

}
add_shortcode('breaking_news' , 'spx_breaking_news_page_home_');
/**********Breaking News Home Page END*/

/******************START HOME PAGE TOP SLIDER */
function home_page_top_sliders() { 
	ob_start();
    $post_id = 106081;
    $posts = get_field('top_slider_home',$post_id);
    //echo $posts;
    
    ?>
    <div class="posts layout-carousel alignfull" data-carousel-column="3" data-enable-autoplay="on" data-autoplay-pause-on-hover="on" data-autoplay-pause-duration="5">
        <div class="posts-wrapper fade-in"> 
            <?php
                // $args = array( 
                //     'post_type' => 'post',
                //     'fields' => 'ids',
                //     'post__in'  => $posts,
                //     'orderby' => 'post__in',
                //    // 'paged' => $paged,
                // );
                $args = array( 
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'meta_query' => array(      
                                        array(
                                                'key' => 'show_post_on_slider',
                                                'value' => true,
                                                'compare' => '='
                                            ),
                                    ),
                );
                $query = new WP_Query( $args );
                while ( $query->have_posts() ) : $query->the_post(); 
                //foreach($posts as $post):
                    global $post;
                    $ID = get_the_ID();
                    $author_id = get_the_author_meta( 'ID' );
                    $display_name = get_the_author_meta( 'display_name', $author_id );
                    $author_url = get_author_posts_url($author_id);
                    $post_title = get_the_title();
                    $post_excerpt = get_the_excerpt();
                    $permalink = get_the_permalink();
                    $terms = get_the_category($ID);
                    $image_id = get_post_thumbnail_id($ID);
                    $image_url = etheme_get_resized_url($image_id,800,800,true);
            ?>   
                    <article class="post-<?php echo $ID; ?> post type-post status-publish format-video has-post-thumbnail hentry category-life category-travel category-world tag-cultural-diversity post_format-post-format-video" style="width: 100%; display: inline-block;">
                        <div class="featured-img">
                            <a href="<?php echo esc_url($permalink);?>" tabindex="-1">
                                <div class="featured-img-container" style="background-image: url('<?php echo esc_url($image_url);?>');"></div>
                            </a>
                        </div>
                        <div class="article-content">
                            <header class="entry-header">
                                <div class="cat-links">
                                        <?php
                                        foreach($terms as $term):
                                        $term_name = $term->name;
                                        $term_link = get_term_link( $term );
                                        ?>
                                        <a href="<?php echo esc_url($term_link);?>" rel="tag" tabindex="-1"><?php echo esc_html($term_name); ?></a>
                                        <?php endforeach;?>
                                </div>
                                <h2 class="entry-title">
                                    <a href="<?php echo esc_url($permalink);?>" tabindex="-1">
                                        <?php echo esc_html($post_title);?>
                                    </a>
                                </h2>
                                <div class="entry-meta has-author-photo">
                                <div class="meta-group author">
                                    <div class="author-photo">
                                        <a href="<?php echo esc_url($author_url);?>" tabindex="-1">
                                            <?php echo get_avatar( get_the_author_meta( 'email', $author_id ), 160 ); ?>
                                        </a>
                                    </div>
                                    <div class="meta-item author-name">
                                        <a href="<?php echo esc_url($author_url);?>" tabindex="-1"><?php echo esc_html($display_name);?></a>
                                    </div>
                                </div>
                                <div class="meta-group">
                                    <div class="meta-item post-date"><a href="<?php echo esc_url($permalink);?>" tabindex="-1"><?php echo esc_html( get_the_date() ); ?></a></div>
                                    <div class="meta-item read-time"><?php alpaca_the_post_reading_time( $ID ); ?></div>
                                </div>
                                </div>
                            </header>
                            <div class="entry-excerpt">
                                <p><?php echo esc_html($post_excerpt);?></p>
                            </div>
                        </div>
                    </article>
                <?php endwhile; wp_reset_postdata();?>
        </div>
    </div>
	<?php
	$content = ob_get_contents(); 
	ob_get_clean();
	return trim($content);
	}
	 
add_shortcode('home_page_top_slider', 'home_page_top_sliders');

/******************END HOME PAGE TOP SLIDER */

/******************START LATEST NEWS */
function home_page_latest_news() { 
	ob_start();
    $post_id = 106081;
    // $latest_posts = get_field('latest_news',$post_id);
    ?>
      <div id="primary" class="primary content-area" style="">
         <div class="section-header">
            <h5 class="section-title">Latest News</h5>
         </div>
         <div class="posts layout-zigzag">
            <div class="posts-wrapper" id="latest_post_home">
         
         </div>
         </div>
         <div id="home_latest_news_home_load_more">
        </div>
      </div>
      <aside id="secondary" class="sidebar widget-area" data-enable-sticky-sidebar="on">
         <div class="sidebar-container">
           <?php get_sidebar();?>
         </div>
         <!-- end of .sidebar-container -->
      </aside>
      <!-- end of .sidebar -->
	<?php
	$content = ob_get_contents(); 
	ob_get_clean();
	return trim($content);
	}
	 
add_shortcode('home_latest_news', 'home_page_latest_news');

/******************END LATEST NEWS */
