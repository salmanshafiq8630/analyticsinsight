<?php
add_action('customize_register', 'spx_register_ads_customize_sections');
function spx_register_ads_customize_sections( $wp_customize ){
    //Settings
    $wp_customize->add_setting( 'header_top_ad_url', array( 'default' => '' ) );
    $wp_customize->add_setting( 'header_top_ad_image', array( 'default' => '' ) );

    //Sections
    $wp_customize->add_section(
        'spx_alpaca_ads',
        array(
            'title' => __( 'Custom Advertisement', 'alpaca' ),
            'priority' => 30,
            'description' => __( 'Enter the URL and image to your ad to appear in the header.', 'alpaca' )
        )
    );

    //Controls
    // URl
    $wp_customize->add_control(
        new WP_Customize_Control(
            $wp_customize, 'header_top_ad_url',
            array(
                'label' => __( 'Top Header Ad URL', 'alpaca' ),
                'section' => 'spx_alpaca_ads',
                'settings' => 'header_top_ad_url'
            )
        )
    );
    // Image
    $wp_customize->add_control(
        new WP_Customize_Image_Control(
            $wp_customize, 'header_top_ad_image',
            array(
                'label' => __( 'Top Header Ad Image', 'alpaca' ),
                'section' => 'spx_alpaca_ads',
                'settings' => 'header_top_ad_image'
            )
        )
    );
   
    
}