<?php
/*********** Magazines*/
add_action( 'wp_ajax_nopriv_spx_get_magazine_data', 'spx_get_magazine_data' );
add_action( 'wp_ajax_spx_get_magazine_data', 'spx_get_magazine_data' );

function spx_get_magazine_data() {
            $per_page   = 12;
            $paged      = $_POST['page_number'];
            $next_page  = $paged+1;
            $args       = array(
                                'post_type' => 'magazine',
                                'posts_per_page' => $per_page,
                                'post_status' => 'publish',
                                'paged' => $paged,
                                'tax_query'      => array(
                                    array(
                                        'taxonomy' => 'magazine-category',
                                        'operator' => 'NOT EXISTS'
                                    )
                                )
                                //'category__in'=>248
            );
            $query      = new WP_Query( $args ); 

            if ( $query->have_posts() ) : 
                $n          = 1; 
                $post_count = $query->found_posts;

                while ( $query->have_posts() ) : $query->the_post();
                $years = get_the_terms( get_the_ID(), 'mag_year' );
                if($years):
                $year = $years[0]->name;
                endif;
                $web_magazine_url = get_field('web_magazine_url');

                if(!empty($web_magazine_url)):

                    if((strpos($web_magazine_url,'https')!==false) || strpos($web_magazine_url,'http')!==false){

                        $web_url = $web_magazine_url;

                    }else{

                        $web_url = site_url($web_magazine_url);

                    }

                endif;

                $html .= '<div class="post-'.get_the_ID().'  col">
                            <div class="featured-thumbnail">
                            '.get_the_post_thumbnail(get_the_ID(),'large').'
                            </div>
                            <div class="article-content">
                                <header class="entry-header entry-header-mag">
                                <span><strong>Year:</strong> '.$year.'</span>
                                <h2 class="entry-title">
                                <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                                </h2>
                                </header>
                            <div class="read-more-magazine">
                                <div class="read-more-btn">
                                <a href="'.get_the_permalink().'"><span>Digital Version</span></a>
                                </div>
                                <div class="read-more-btn">
                                <a href="'.$web_url.'"><span>Web Version</span></a>
                                </div>
                            </div>
                            </div>
                        </div>';

                $n++;
                endwhile;
                wp_reset_postdata();
            endif;
            if( ( $post_count > $per_page ) && ( $post_count > $paged*$per_page ) ):
                $paginateData .= '<nav class="navigation pagination">
                                    <div class="pagination-container load-more loading">
                                        <h2 class="screen-reader-text">'. __( 'Magazines Navigation', 'alpaca' ).'</h2>
                                        <a href="javascript:void(0);" id="'.$next_page.'" data-no-post-text="'. __( 'No More Magazines', 'alpaca' ).'" class="mag_load load-more-btn ajax manual">
                                        <span>'. __( 'Load More Magazines', 'alpaca' ).'</span>
                                        </a>
                                    </div>
                                </nav>';
                else:
                $paginateData .= '<nav class="navigation pagination">
                                    <div class="pagination-container load-more">
                                    <h2 class="screen-reader-text">Magazines Navigation</h2>
                                    <span class="no-more-posts-message">No More Magazines</span>
                                    </div>
                                </nav>';
            endif;

            $datas      =  array(
                                'html' => $html,
                                'paginate' => $paginateData
            );

            $json_data  = json_encode($datas);
            echo $json_data;
            wp_die();
}

/******************* Magazines end */

/*********** Women Magazines AJax query*/
add_action( 'wp_ajax_nopriv_spx_get_women_magazines_data', 'spx_get_women_magazines_data' );
add_action( 'wp_ajax_spx_get_women_magazines_data', 'spx_get_women_magazines_data' );

function spx_get_women_magazines_data() {
            $per_page   = 12;
            $paged      = $_POST['page_number'];
            $next_page  = $paged+1;
            $args       = array(
                                'post_type' => 'magazine',
                                'posts_per_page' => $per_page,
                                'post_status' => 'publish',
                                'paged' => $paged,
                                'tax_query'         => array(
                                    array(
                                        'taxonomy'  => 'magazine-category',
                                        'field'     => 'slug',
                                        'terms'     => 'women-in-technology'
                                    )
                                )
                               
                              
            );
            $query      = new WP_Query( $args ); 

            if ( $query->have_posts() ) : 
                $n          = 1; 
                $post_count = $query->found_posts;

                while ( $query->have_posts() ) : $query->the_post();
                $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);
                $years = get_the_terms( get_the_ID(), 'mag_year' );
                if($years):
                $year = $years[0]->name;
                endif;
                $web_magazine_url = get_field('web_magazine_url');

                if(!empty($web_magazine_url)):

                    if((strpos($web_magazine_url,'https')!==false) || strpos($web_magazine_url,'http')!==false){

                        $web_url = $web_magazine_url;

                    }else{

                        $web_url = site_url($web_magazine_url);

                    }

                endif;

                $html .= '<div class="post-'.get_the_ID().'  col">
                            <div class="featured-thumbnail">
                            <img src="'.$image_url.'" alt="'.get_the_title().'" />
                            </div>
                            <div class="article-content">
                                <header class="entry-header entry-header-mag">
                                <span><strong>Year:</strong> '.$year.'</span>
                                <h2 class="entry-title">
                                <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                                </h2>
                                </header>
                            <div class="read-more-magazine">
                                <div class="read-more-btn">
                                <a href="'.get_the_permalink().'"><span>Digital Version</span></a>
                                </div>
                                <div class="read-more-btn">
                                <a href="'.$web_url.'"><span>Web Version</span></a>
                                </div>
                            </div>
                            </div>
                        </div>';

                $n++;
                endwhile;
                wp_reset_postdata();
            endif;
            if( ( $post_count > $per_page ) && ( $post_count > $paged*$per_page ) ):
                $paginateData .= '<nav class="navigation pagination">
                                    <div class="pagination-container load-more loading">
                                        <h2 class="screen-reader-text">'. __( 'Magazines Navigation', 'alpaca' ).'</h2>
                                        <a href="javascript:void(0);" id="'.$next_page.'" data-no-post-text="'. __( 'No More Magazines', 'alpaca' ).'" class="Women_Magazines load-more-btn ajax manual">
                                        <span>'. __( 'Load More Magazines', 'alpaca' ).'</span>
                                        </a>
                                    </div>
                                </nav>';
                else:
                $paginateData .= '<nav class="navigation pagination">
                                    <div class="pagination-container load-more">
                                    <h2 class="screen-reader-text">Magazines Navigation</h2>
                                    <span class="no-more-posts-message">No More Magazines</span>
                                    </div>
                                </nav>';
            endif;

            $datas      =  array(
                                'html' => $html,
                                'paginate' => $paginateData
            );

            $json_data  = json_encode($datas);
            echo $json_data;
            wp_die();
}

/******************* end women magazine query ajax*/

/*********** Reports*/
add_action( 'wp_ajax_nopriv_spx_get_reports_data', 'spx_get_reports_data' );
add_action( 'wp_ajax_spx_get_reports_data', 'spx_get_reports_data' );

function spx_get_reports_data() {
        $per_page   = 12;
        $paged      = $_POST['page_number'];
        $next_page  = $paged+1;
        $args       = array(
                            'post_type' => 'report',
                            'posts_per_page' => $per_page,
                            'post_status' => 'publish',
                            'paged' => $paged,
                            //'category__in'=>248
        );
        $query      = new WP_Query( $args ); 

        if ( $query->have_posts() ) : 
            $n          = 1; 
            $post_count = $query->found_posts;

            while ( $query->have_posts() ) : $query->the_post();
            $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);
            $years = get_the_terms( get_the_ID(), 'mag_year' );
            if($years):
            $year = $years[0]->name;
            endif;
            $web_magazine_url = get_field('digital_report_url');

            if(!empty($web_magazine_url)):

                if((strpos($web_magazine_url,'https')!==false) || strpos($web_magazine_url,'http')!==false){

                $web_url = $web_magazine_url;

                }else{

                $web_url = site_url($web_magazine_url);

                }

            endif;

            $html .= '<div class="post-'.get_the_ID().' col">
                        <div class="featured-thumbnail">
                        <a href="'.get_the_permalink().'"><img src="'.$image_url.'" alt="'.get_the_title().'" /></a>
                        </div>
                        <div class="article-content">
                            <header class="entry-header entry-header-mag">
                            <span><strong>Year:</strong> '.$year.'</span>
                            <h2 class="entry-title">
                            <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                            </h2>
                            </header>
                            <div class="read-more-magazine">
                                <div class="read-more-btn">
                                <a href="'.get_the_permalink().'"><span>Read More</span></a>
                                </div>
                            </div>
                        </div>
                    </div>';


            $n++;
            endwhile;
            wp_reset_postdata();
        endif;
        if( ( $post_count > $per_page ) && ( $post_count > $paged*$per_page ) ):
        $paginateData .= '<nav class="navigation pagination">
                            <div class="pagination-container load-more loading">
                                <h2 class="screen-reader-text">'. __( 'Reports Navigation', 'alpaca' ).'</h2>
                                <a href="javascript:void(0);" id="'.$next_page.'" data-no-post-text="'. __( 'No More Reports', 'alpaca' ).'" class="report_load load-more-btn ajax manual">
                                <span>'. __( 'Load More Reports', 'alpaca' ).'</span>
                                </a>
                            </div>
                          </nav>';
        else:
        $paginateData .= '<nav class="navigation pagination">
                            <div class="pagination-container load-more">
                                <h2 class="screen-reader-text">Reports Navigation</h2>
                                <span class="no-more-posts-message">No More Reports</span>
                            </div>
                          </nav>';
        endif;

        $datas      =  array(
                            'html' => $html,
                            'paginate' => $paginateData
        );

        $json_data  = json_encode($datas);
        echo $json_data;
        wp_die();
}

/*********** Reports AJAX END */

/*********** WEB TECH STORIES PAGE AJAX START*/

add_action( 'wp_ajax_nopriv_spx_get_web_stories_data', 'spx_get_web_stories_data' );
add_action( 'wp_ajax_spx_get_web_stories_data', 'spx_get_web_stories_data' );

function spx_get_web_stories_data() {
        $per_page   = 5;
        $paged      = $_POST['page_number'];
        $next_page  = $paged+1;
        $args       = array(
                            'post_type' => 'web-story',
                            'posts_per_page' => $per_page,
                            'post_status' => 'publish',
                            'paged' => $paged,
                            //'category__in'=>248
        );
        $query      = new WP_Query( $args ); 

        if ( $query->have_posts() ) : 
            $n          = 1; 
            $post_count = $query->found_posts;

            while ( $query->have_posts() ) : $query->the_post();
            $image_id = get_post_thumbnail_id(); $image_url = etheme_get_resized_url($image_id,402,525,true);

            $html .= '<div class="post-'.get_the_ID().' col">
                        <div class="featured-thumbnail">
                        <a href="'.get_the_permalink().'"><img src="'.$image_url.'" alt="'.get_the_title().'" /></a>
                        </div>
                        <div class="article-content">
                            <header class="entry-header entry-header-web-stories">
                            <h2 class="entry-title">
                            <a href="'.get_the_permalink().'">'.get_the_title().'</a>
                            </h2>
                            </header>
                            <div class="read-more-magazine">
                                <div class="read-more-btn">
                                <a href="'.get_the_permalink().'"><span>Read More</span></a>
                                </div>
                            </div>
                        </div>
                    </div>';


            $n++;
            endwhile;
            wp_reset_postdata();
        endif;
        if( ( $post_count > $per_page ) && ( $post_count > $paged*$per_page ) ):
        $paginateData .= '<nav class="navigation pagination">
                            <div class="pagination-container load-more loading">
                                <h2 class="screen-reader-text">'. __( 'Stories Navigation', 'alpaca' ).'</h2>
                                <a href="javascript:void(0);" id="'.$next_page.'" data-no-post-text="'. __( 'No More Stories', 'alpaca' ).'" class="web_tech_load load-more-btn ajax manual">
                                <span>'. __( 'Load More Stories', 'alpaca' ).'</span>
                                </a>
                            </div>
                          </nav>';
        else:
        $paginateData .= '<nav class="navigation pagination">
                            <div class="pagination-container load-more">
                                <h2 class="screen-reader-text">'. __( 'Stories Navigation', 'alpaca' ).'</h2>
                                <span class="no-more-posts-message">'. __( 'No More Stories', 'alpaca' ).'</span>
                            </div>
                          </nav>';
        endif;

        $datas      =  array(
                            'html' => $html,
                            'paginate' => $paginateData
        );

        $json_data  = json_encode($datas);
        echo $json_data;
        wp_die();
}

/*********** WEB TECH STORIES PAGE AJAX END*/

/*********** LATEST NEWS HOME PAGE PAGE AJAX START*/
function home_page_latest_news_ajax() {
    ob_start();
    $post_id = 106081;
    // $latest_posts = get_field('latest_news',$post_id);
    $page = $_POST['page_number'];
    //$per_page   = 4;
    $total = count( $latest_posts ); //total items in array    
      
    $totalPages = ceil( $total/ $limit ); //calculate total pages
    $page = max($page, 1); //get 1 page when $_GET['page'] <= 0
    $page = min($page, $totalPages); //get last page when $_GET['page'] > $totalPages
    $offset = ($page - 1) * $limit;
    if( $offset < 0 ) $offset = 0;
    $next_page  = $page+1;
    //echo $total;

    $latest_posts = array_slice( $latest_posts, $offset, $limit );
    //print_r($latest_posts);



    $limit = 3; //per page  
    $page_no = $_POST['page_no'];
    
   
   
?>

            <?php
            //$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
            // $args = array( 
            //     'post_type' => 'post',
            //     'fields' => 'ids',
            //     'post__in'  => $latest_posts,
            //     //'posts_per_page' => $per_page,
            //     'orderby' => 'post__in',
            //     'paged' => $paged,
            // );


            $args = array( 
                'post_type' => 'post',
                'paged' => $page_no,
                'posts_per_page' => $limit,
                'meta_query' => array(      
                                        array(
                                                'key' => 'show_post_on_latest_news_section',
                                                'value' => true,
                                                'compare' => '='
                                            ),
                                    ),
            );


            $query = new WP_Query( $args );

            $post_count = $query->found_posts;

            while ( $query->have_posts() ) : $query->the_post(); 
               // foreach($posts as $post):
                global $post;
                $ID = get_the_ID();
                $author_id = get_the_author_meta( 'ID' );
                $display_name = get_the_author_meta( 'display_name', $author_id );
                $author_url = get_author_posts_url($author_id);
                $post_title = get_the_title();
                $post_excerpt = get_the_excerpt();
                $permalink = get_the_permalink();
                $terms = get_the_category($ID);
                $image_id = get_post_thumbnail_id($ID);
                $image_url = etheme_get_resized_url($image_id,800,800,true);
            ?>  
               <article class="post-<?php echo $ID;?> post type-post status-publish format-standard has-post-thumbnail hentry category-data-science category-latest-news category-top-list tag-ph-d-data-science-courses">
                  <div class="featured-img">
                     <a href="<?php echo esc_url($permalink);?>" tabindex="-1">
                        <div class="featured-img-container" style="background-image: url('<?php echo esc_url($image_url);?>');"></div>
                     </a>
                  </div>
                  <div class="article-content">
                    <header class="entry-header">
                        <div class="cat-links">
                            <?php
                                foreach($terms as $term):
                                $term_name = $term->name;
                                $term_link = get_term_link( $term );
                                ?>
                                    <a href="<?php echo esc_url($term_link);?>" rel="tag" tabindex="-1"><?php echo esc_html($term_name); ?></a>
                            <?php endforeach;?>
                        </div>
                        <h2 class="entry-title">
                            <a href="<?php echo esc_url($permalink);?>" tabindex="-1"><?php echo esc_html($post_title);?></a>
                        </h2>
                        <div class="entry-meta has-author-photo">
                           <div class="meta-group author">
                            <div class="author-photo">
                                <a href="<?php echo esc_url($author_url);?>" tabindex="-1">
                                    <?php echo get_avatar( get_the_author_meta( 'email', $author_id ), 160 ); ?>
                                </a>
                            </div>
                            <div class="meta-item author-name">
                                <a href="<?php echo esc_url($author_url);?>" tabindex="-1"><?php echo esc_html($display_name);?></a>			
                            </div>
                           </div>
                           <div class="meta-group">
                                <div class="meta-item post-date"><a href="<?php echo esc_url($permalink);?>" tabindex="-1"><?php echo esc_html( get_the_date() ); ?></a></div>
                                <div class="meta-item read-time"><?php alpaca_the_post_reading_time( $ID ); ?></div>
                           </div>
                        </div>
                    </header>
                    <div class="entry-excerpt">
                        <p><?php echo esc_html($post_excerpt);?></p>
                    </div>
                     <div class="read-more-btn">
                        <a href="<?php echo esc_url($permalink);?>"><span>Read More</span></a>
                     </div>
                  </div>
               </article>
               <?php endwhile;wp_reset_postdata();?>
         
<?php
	$html = ob_get_contents(); 
	ob_get_clean();
    ob_start();
    if( ( $post_count > $limit ) && ( $post_count > $page_no*$limit ) ):
?>
<nav class="navigation pagination">
    <div class="pagination-container load-more loading">
        <h2 class="screen-reader-text"><?php  _e( 'News Navigation', 'alpaca' ); ?></h2>
        <a href="javascript:void(0);" id="<?php echo $next_page; ?>" data-no-post-text="<?php  _e( 'No More Posts', 'alpaca' ); ?>" class="home_latest_new load-more-btn ajax manual">
        <span><?php _e( 'Load More Posts', 'alpaca' );?> </span>
        </a>
    </div>
</nav>
<?php else: ?>
<nav class="navigation pagination">
    <div class="pagination-container load-more">
        <h2 class="screen-reader-text">News Navigation</h2>
        <span class="no-more-posts-message"><?php _e( 'No More Posts', 'alpaca' );?></span>
    </div>
</nav>
<?php
   endif;
   $paginateData = ob_get_contents(); 
	ob_get_clean();
    $datas      =  array(
    'html' => $html,
    'paginate' => $paginateData
    );

    $json_data  = json_encode($datas);
    echo $json_data;

    wp_die();
}

add_action( 'wp_ajax_nopriv_home_page_latest_news_ajax', 'home_page_latest_news_ajax' );
add_action( 'wp_ajax_home_page_latest_news_ajax', 'home_page_latest_news_ajax' );
/*********** LATEST NEWS HOME PAGE PAGE AJAX START*/
