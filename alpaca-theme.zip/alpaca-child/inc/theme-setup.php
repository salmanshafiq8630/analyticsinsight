<?php
/****** */
// ADD NEW COLUMN
function advertise_columns_head($columns) {

	foreach($columns as $key => $column):
		$new[$key] = $column;
		if($key == 'title'):
			$new['shortcode'] = __('Shortcode');
		endif;
	endforeach;  
  return $new;
}
 
// SHOW THE ShortCode
function advertise_columns_content($column_name, $post_ID) {
    if ($column_name == 'shortcode') {
        echo '<code>[advertise id="'.$post_ID.'" title="'.get_the_title($post_ID).'"]</code>';
    }
}
add_filter('manage_advertise_posts_columns', 'advertise_columns_head');
add_action('manage_advertise_posts_custom_column', 'advertise_columns_content', 10, 2);


/** 
 * Display page template's name column into admin
 */
//Add the custom column to the post type
add_filter( 'manage_pages_columns', 'sp_add_custom_column' );
function sp_add_custom_column( $columns ) {
	foreach($columns as $key => $column):
		$new[$key] = $column;
		if($key == 'title'):
			$new['template'] = __('Template');
		endif;
	endforeach;  
  return $new;
}
// Add the data to the custom column
add_action( 'manage_pages_custom_column' , 'sp_add_custom_column_data', 10, 2 );
function sp_add_custom_column_data( $column, $post_id ) {
  switch ( $column ) {
    case 'template' :
      $post = get_post( $post_id );      
      $template_slug = get_page_template_slug( $post );      
      $templates = wp_get_theme()->get_page_templates();
      //print_r($templates);
      if(!empty($template_slug)):
      	echo $templates[$template_slug];
      else:
      	_e('Default template');
      endif;
    break;
  }
}


if ( is_admin() ) {
    add_action( 'load-post.php', function(){
    	add_action( 'add_meta_boxes', function($post_type){

    		if ( $post_type ==  'advertise') {
	            add_meta_box(
	                'advertise_shortcode',
	                __( 'Shortcode' ),
	                'render_meta_box_advertise_shortcode',
	                $post_type,
	                'side',
	                'high'
	            );
	        }

    	} );

    	function render_meta_box_advertise_shortcode($post){
    		echo '<code>[advertise id="'.$post->ID.'" title="'.$post->post_title.'"]</code>';
    	}
    });
    
}
/**
 * 
 * Add Shortcode Support In ACF Text Field 
 * 
 **/

add_filter('acf/format_value/type=textarea', 'do_shortcode');


/****Login Logout Items to Primary menu */
add_filter( 'wp_nav_menu_items', 'add_loginout_link', 10, 2 );

function add_loginout_link( $items, $args ) {
    $mobilespx = '';
    if(wp_is_mobile()) {
        $mobilespx = '<button class="dropdown-toggle" aria-expanded="false"><span class="screen-reader-text">expand child menu</span></button>';
    }
    if (is_user_logged_in() && $args->theme_location == 'secondary_menu') {
            $items .= '<li id="menu-item-32312" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-105201">
                        <a href="#"><i class="fa fa-user"></i></a>
                        '.$mobilespx.'
                        <ul class="sub-menu">
                            <li id="menu-item-213123" class="menu-item menu-item-17061">
                            <a title="PMS Account" href="'. site_url('pms-account') .'">'. __( 'PMS Account', 'alpaca' ). '</a>
                            </li>
                            <li id="menu-item-5453" class="menu-item menu-item-17061">
                            <a title="Log Out" href="'. wp_logout_url( site_url('pms-login') ). '">'. __( 'Log Out', 'alpaca' ). '</a>
                            </li>
                        </ul>
                      </li>';        
    }
    elseif (!is_user_logged_in() && $args->theme_location == 'secondary_menu') {

    $items .= '<li id="menu-item-67454" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-105201">
                    <a href="#"><i class="fa fa-user"></i></a>
                    '.$mobilespx.'
                    <ul class="sub-menu">
                        <li id="menu-item-45642" class="menu-item menu-item-17061">
                         <a title="PMS Account" href="'. site_url('pms-login') .'">'. __( 'Log In', 'alpaca' ). '</a>
                        </li>
                        <li id="menu-item-242343" class="menu-item menu-item-17061">
                         <a title="Sign Up" href="'. site_url('pms-register') .'">'. __( 'Sign Up', 'alpaca' ). '</a>
                        </li>
                    </ul>
                </li>';
    }

    return $items;

}

/****filter magazine category url magazine page url*/

add_filter('wp_nav_menu_objects', 'add_magazine_page_link', 10, 2);

function add_magazine_page_link($sorted_menu_objects, $args) {
   
    if ($args->theme_location == 'primary-menu')  {
   
    foreach ($sorted_menu_objects as $key => $menu_object) {
        if ($menu_object->title == 'Magazines' && $menu_object->type_label == 'Category') {
          
            $menu_object->url = site_url('magazines');

            break;
        }
    }
   }

   return $sorted_menu_objects;
   
}

/****** */
function alpaca_secondary_nav( $args = array(), $before = '', $after = '', $show_mega_menu = false ) {
	if ( alpaca_has_nav_menu( 'secondary_menu' ) ) {
		$walker = $show_mega_menu ? ( new Alpaca_Mega_Walker_Nav_Menu_Second() ) : ( new Alpaca_Walker_Nav_Menu_Second() );
		$menu_wrap_allowed_html = array( 'div' => array( 'class' => 1, 'id' => 1, 'data-*' => 1 ) );
		echo wp_kses( $before, $menu_wrap_allowed_html );
		wp_nav_menu( array_merge( array(
			'echo'				=> true,
			'theme_location' 	=> 'secondary_menu',
			'container' 		=> 'nav',
			'container_id' 		=> 'site-navigation',
			'container_class' 	=> 'main-navigation',
			'menu_id' 			=> 'menu-main-menu',
			'menu_class' 		=> 'primary-menu',
			'depth' 			=> 3,
			'walker' 			=> $walker
		), $args ) );
		echo wp_kses( $after, $menu_wrap_allowed_html );
	}
}
