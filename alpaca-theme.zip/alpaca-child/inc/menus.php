<?php
/***Register Menu SPX */

if ( ! function_exists( 'spx_alpaca_register_nav_menu' ) ) {

    function spx_alpaca_register_nav_menu(){
        register_nav_menus( array(
            'footer_1_nav' => __( 'About Menu', 'alpaca' ),
            'footer_2_nav' => __( 'Reach Us Menu', 'alpaca' ),
            'footer_3_nav' => __( 'Special Editions Menu', 'alpaca' ),
            'secondary_menu' => __( 'Secondary Menu', 'alpaca' ),
        ) );
    }
    add_action( 'after_setup_theme', 'spx_alpaca_register_nav_menu', 0 );
    }