<?php
/*
* Creating a function to create our CPT magazine
******Custom post type magazine */
function custom_post_type() {

    // Set UI labels for Custom Post Type
    $labels = array(
                    'name'                => _x( 'Magazines', 'Post Type General Name', 'alpaca' ),
                    'singular_name'       => _x( 'Magazine', 'Post Type Singular Name', 'alpaca' ),
                    'menu_name'           => __( 'Magazines', 'alpaca' ),
                    'parent_item_colon'   => __( 'Parent Magazine', 'alpaca' ),
                    'all_items'           => __( 'All Magazines', 'alpaca' ),
                    'view_item'           => __( 'View Magazine', 'alpaca' ),
                    'add_new_item'        => __( 'Add New Magazine', 'alpaca' ),
                    'add_new'             => __( 'Add New', 'alpaca' ),
                    'edit_item'           => __( 'Edit Magazine', 'alpaca' ),
                    'update_item'         => __( 'Update Magazine', 'alpaca' ),
                    'search_items'        => __( 'Search Magazine', 'alpaca' ),
                    'not_found'           => __( 'Not Found', 'alpaca' ),
                    'not_found_in_trash'  => __( 'Not found in Trash', 'alpaca' ),
    );

    // Set other options for Custom Post Type

    $args = array(
                'label'               => __( 'magazines', 'alpaca' ),
                'description'         => __( 'Magazine news and reviews', 'alpaca' ),
                'labels'              => $labels,
                // Features this CPT supports in Post Editor
                'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
                // You can associate this CPT with a taxonomy or custom taxonomy. 
                'taxonomies'          => array( 'genres' ),
                /* A hierarchical CPT is like Pages and can have
                * Parent and child items. A non-hierarchical CPT
                * is like Posts.
                */
                'hierarchical'        => false,
                'public'              => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 5,
                'can_export'          => true,
                'has_archive'         => true,
                'exclude_from_search' => false,
                'publicly_queryable'  => true,
                'menu_icon'   => 'dashicons-book',
                'capability_type'     => 'post',
                'show_in_rest' => true,

    );

    // Registering your Custom Post Type
    register_post_type( 'magazine', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/

add_action( 'init', 'custom_post_type', 0 );

/*********Reposrt CPT */
function reports_custom_post_type() {

    // Set UI labels for Custom Post Type
    $labels = array(
                    'name'                => _x( 'Reports', 'Post Type General Name', 'alpaca' ),
                    'singular_name'       => _x( 'Report', 'Post Type Singular Name', 'alpaca' ),
                    'menu_name'           => __( 'Reports', 'alpaca' ),
                    'parent_item_colon'   => __( 'Parent Report', 'alpaca' ),
                    'all_items'           => __( 'All Report', 'alpaca' ),
                    'view_item'           => __( 'View Report', 'alpaca' ),
                    'add_new_item'        => __( 'Add New Report', 'alpaca' ),
                    'add_new'             => __( 'Add New', 'alpaca' ),
                    'edit_item'           => __( 'Edit Report', 'alpaca' ),
                    'update_item'         => __( 'Update Report', 'alpaca' ),
                    'search_items'        => __( 'Search Report', 'alpaca' ),
                    'not_found'           => __( 'Not Found', 'alpaca' ),
                    'not_found_in_trash'  => __( 'Not found in Trash', 'alpaca' ),
    );

    // Set other options for Custom Post Type

    $args = array(
                'label'               => __( 'reports', 'alpaca' ),
                'description'         => __( 'Report news and reviews', 'alpaca' ),
                'labels'              => $labels,
                // Features this CPT supports in Post Editor
                'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
                // You can associate this CPT with a taxonomy or custom taxonomy. 
                'taxonomies'          => array( 'genres' ),
                /* A hierarchical CPT is like Pages and can have
                * Parent and child items. A non-hierarchical CPT
                * is like Posts.
                */
                'hierarchical'        => false,
                'public'              => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 5,
                'can_export'          => true,
                'has_archive'         => true,
                'exclude_from_search' => false,
                'publicly_queryable'  => true,
                'menu_icon'   => 'dashicons-open-folder',
                'capability_type'     => 'post',
                'show_in_rest' => true,

    );

    // Registering your Custom Post Type
    register_post_type( 'report', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/

add_action( 'init', 'reports_custom_post_type', 0 );

/********** Create Ads CPT */
add_action( 'init', 'create_cpt_post_type' );

function create_cpt_post_type() {		

	register_post_type( 'advertise',
		array(
			'labels' => array(
			'name' => __( 'Advertise' ),
			'singular_name' => __( 'Advertise' ),
			'add_new'		=> 'Add New',
			'add_new_item'	=> 'Add New Advertise',
			'edit_item'		=> 'Edit Advertise',
		),
		'public' => true,
		'hierarchical'  => false,
		//'taxonomies' => array( 'filter', 'art-category' ),
		'show_in_menu' => true,
		'show_in_nav_menus' => false,
        'exclude_from_search' => true,
		'has_archive' => false,
        'menu_position'       => 4,
		'publicly_queryable' => true,
		'rewrite' => false,
		'menu_icon'   => 'dashicons-text-page',
		'supports'      =>  array('title')
		)
	);
   
    register_post_type( 'event-media',
		array(
			'labels' => array(
                'name' => __( 'Event and Media Partners' ),
			    'singular_name' => __( 'Event and Media Partners' ),
			    'add_new'		=> 'Add New',
			    'add_new_item'	=> 'Add New Event and Media Partner',
			    'edit_item'		=> 'Edit Event and Media Partner',
              
                ),
                'public' => true,
                'hierarchical'  => false,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'exclude_from_search' => true,
                'has_archive' => false,
                'menu_position'       => 4,
                'publicly_queryable' => true,
                'rewrite' => false,
                'menu_icon'   => 'dashicons-calendar',
                'supports'      =>  array('title')
               
		)
	);

    register_post_type( 'ai-featured',
		array(
			'labels' => array(
                'name' => __( 'Analytics Insight Featured' ),
			    'singular_name' => __( 'Analytics Insight Featured' ),
			    'add_new'		=> 'Add New',
			    'add_new_item'	=> 'Add New Analytics Insight Featured',
			    'edit_item'		=> 'Edit Analytics Insight Featured',
              
                ),
                'public' => true,
                'hierarchical'  => false,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'exclude_from_search' => true,
                'has_archive' => false,
                'menu_position'       => 4,
                'publicly_queryable' => true,
                'rewrite' => false,
                'menu_icon'   => 'dashicons-shield-alt',
                'supports'      =>  array('title')
               
		)
	);

    register_post_type( 'ai-lists',
		array(
			'labels' => array(
                'name' => __( 'Analytics Insight Lists' ),
			    'singular_name' => __( 'Analytics Insight List' ),
			    'add_new'		=> 'Add New',
			    'add_new_item'	=> 'Add New Analytics Insight List',
			    'edit_item'		=> 'Edit Analytics Insight List',
              
                ),
                'public' => true,
                'hierarchical'  => false,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'exclude_from_search' => true,
                'has_archive' => false,
                'menu_position'       => 4,
                'publicly_queryable' => true,
                'rewrite' => false,
                'menu_icon'   => 'dashicons-list-view',
                'supports'      =>  array('title')
               
		)
	);

    flush_rewrite_rules();
}


/**
 * Create two taxonomies, genres and writers for the post type "book".
 *
 * @see register_post_type() for registering custom post types.
 */
function spx_create_year_taxonomies() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Years', 'taxonomy general name', 'alpaca' ),
		'singular_name'     => _x( 'Year', 'taxonomy singular name', 'alpaca' ),
		'search_items'      => __( 'Search Years', 'alpaca' ),
		'all_items'         => __( 'All Years', 'alpaca' ),
		'parent_item'       => __( 'Parent Year', 'alpaca' ),
		'parent_item_colon' => __( 'Parent Year:', 'alpaca' ),
		'edit_item'         => __( 'Edit Year', 'alpaca' ),
		'update_item'       => __( 'Update Year', 'alpaca' ),
		'add_new_item'      => __( 'Add New Year', 'alpaca' ),
		'new_item_name'     => __( 'New Year Name', 'alpaca' ),
		'menu_name'         => __( 'Years', 'alpaca' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'mag_year' ),
	);

	register_taxonomy( 'mag_year', array( 'magazine','report' ), $args );


    // Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Categories', 'taxonomy general name', 'alpaca' ),
		'singular_name'     => _x( 'Category', 'taxonomy singular name', 'alpaca' ),
		'search_items'      => __( 'Search Categories', 'alpaca' ),
		'all_items'         => __( 'All Categories', 'alpaca' ),
		'parent_item'       => __( 'Parent Category', 'alpaca' ),
		'parent_item_colon' => __( 'Parent Category:', 'alpaca' ),
		'edit_item'         => __( 'Edit Category', 'alpaca' ),
		'update_item'       => __( 'Update Category', 'alpaca' ),
		'add_new_item'      => __( 'Add New Category', 'alpaca' ),
		'new_item_name'     => __( 'New Category Name', 'alpaca' ),
		'menu_name'         => __( 'Categories', 'alpaca' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'magazine-category' ),
	);

	register_taxonomy( 'magazine-category', array( 'magazine'), $args );

}
// hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'spx_create_year_taxonomies', 0 );