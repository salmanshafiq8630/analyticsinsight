<?php
/***********
 Template Name: Women Magazine Template
 * 
 * 
 * 
 */
get_header();

?>
<header class="entry-header page-header">
    	<div class="header-text">
        	<h1 class="entry-title"><?php the_title()?></h1>
         </div>
</header>
<div class="main">
<div class="container">
<div>
<?php

    while( have_posts() ) : the_post();

    the_content();
   
    endwhile;
    echo do_shortcode('[analyticsinsight_women_magazines]');
?>
</div>
</div>	
</div>	

<?php
get_footer();
?>






