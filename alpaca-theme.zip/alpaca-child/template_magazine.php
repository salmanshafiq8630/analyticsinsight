<?php
/***********
 Template Name: Magazine Template
 * 
 * 
 * 
 */
get_header();

    $user_id =  get_current_user_id();
    $member_subscriptions = pms_get_member_subscriptions( array( 'user_id' => $user_id, 'include_abandoned' => true ) );
    $subscription_status = $member_subscriptions[0]->status;
    $subscription_plan = pms_get_subscription_plan($member_subscriptions[0]->subscription_plan_id);
    //if($subscription_status=='active'):
?>
<header class="entry-header page-header">
    	<div class="header-text">
        	<h1 class="entry-title"><?php the_title()?></h1>
         </div>
</header>
<div class="main">
<div class="container">
<div>
<?php

    while( have_posts() ) : the_post();

    the_content();
   
    endwhile;
    echo do_shortcode('[analyticsinsight_magazine]');
?>
</div>
</div>	
</div>	

<?php
get_footer();
?>






