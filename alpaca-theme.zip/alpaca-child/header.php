<!DOCTYPE html>
<html <?php language_attributes(); ?><?php alpaca_the_html_class(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="//gmpg.org/xfn/11">
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<?php endif; ?>
		<?php wp_head(); ?>
	</head>
	<!-- <style>
		/* start leader board banner style */
		.leader-board-area{
			 max-width:728px; 
			margin:10px auto;
		}
		.leader-board-web{display:block;Visibility:visible}
		.leader-board-mobile{display:none;Visibility:hidden}
		@media screen and (min-width: 320px) and (max-width: 768px){
			.leader-board-area{
				max-width:428px;
				margin:5px auto;
			}
		.leader-board-mobile{display:block;Visibility:visible}
		.leader-board-web{display:none;Visibility:hidden}
		}
		/* end leader board banner style */
	</style> -->
	<body <?php body_class(); ?>>
	
		<?php alpaca_body_open(); ?>

		<?php do_action( 'alpaca_the_advertisement', 'site_top' ); ?>
		
		<?php get_template_part( 'template-parts/site-header/site-header' ); ?>
		<div id="page">
			<?php if( is_singular( 'event' ) ) {?>
			<div id="content" class="site-content with-sidebar-right">
			<?php }else if(is_page()){?>
			<div id="content" class="site-content with-sidebar-right">
			<?php }else{?>
			<div id="content" <?php alpaca_the_content_class(); ?>>
			<?php } ?>
			<!-- <?php  //if ( is_singular( 'event' ) || is_page() ): ?>
			<div id="content" class="site-content full-width-inner-page">
			<?php //else:?>
			<div id="content" <?php //alpaca_the_content_class(); ?>>
			<?php //endif;?> -->
