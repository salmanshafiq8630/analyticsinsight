<?php
global $wp_query;
$has_posts = have_posts();
get_header();

if ( $has_posts ) : ?>
    <header class="archive-header">
        <div class="header-text">
            <?php alpaca_show_yoast_seo_breadcrumbs( 'search' ); ?>
            <h1 class="archive-title">
            <?php
                printf(
                    // translators: search keywords
                    esc_html__( 'Search results: "%s"', 'alpaca' ),
                    get_search_query()
                );
            ?>
            </h1>
        </div>
    </header><?php
endif; ?>

    <div class="main">
    	<div class="container">
    		<div id="primary" class="primary content-area"><?php
                if ( $has_posts ) {
                    do_action( 'alpaca_the_list_content', 'search' );
                } else {
                    get_template_part( 'template-parts/archive/content-none', 'search' );
                } ?>
        	</div><?php
    		get_sidebar(); ?>
    	</div>
    </div><!-- end of .main --> <?php
get_footer();
