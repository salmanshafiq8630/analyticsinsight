<div class="no-results not-found">
    <header class="entry-header">
        <h1 class="entry-title"><?php esc_html_e( 'Nothing Found', 'alpaca' ); ?></h1>
    </header>
    <div class="entry-content">
        <p class="error-message nothing-found"><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'alpaca' ); ?></p>
        <?php get_search_form(); ?>
    </div><!-- end of .post-entry  -->
</div>
