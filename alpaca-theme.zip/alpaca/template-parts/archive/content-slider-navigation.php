<?php
$metas = alpaca_get_post_list_prop( 'metas', array() );
$show_thumbnail = in_array( 'thumbnail', $metas );
$show_date = in_array( 'date', $metas );
$show_update_date = in_array( 'update_date', $metas );
$show_reading_time = in_array( 'reading_time', $metas ); ?>


<div class="slider"><?php
    if ( $show_thumbnail && has_post_thumbnail() ) {
        alpaca_the_preload_bg( array( 'id' => get_post_thumbnail_id(), 'class' => 'slider-thumbnail', 'sizes' => alpaca_get_post_list_prop( 'image_sizes', array( 'full', 'full' ) ) ) );
    } ?>

    <div class="slider-info">
        <?php alpaca_list_category( $metas ); ?>
        <div class="entry-title">
            <a href="<?php the_permalink(); ?>" tabindex="-1"><?php the_title(); ?></a>
        </div>
        <?php if ( $show_date || $show_update_date || $show_reading_time ) : ?>
        <div class="entry-meta">
            <div class="meta-group">
                <?php alpaca_list_date( $metas ); ?>
                <?php alpaca_list_update_date( $metas ); ?>
                <?php alpaca_list_reading_time( $metas ); ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
