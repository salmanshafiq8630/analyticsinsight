<?php
$masonry_settings = alpaca_get_post_list_prop( 'masonry', false );
$is_masonry_start = false;
$is_masonry_end = false;
if ( ! empty( $masonry_settings ) && is_array( $masonry_settings ) ) {
	$is_masonry_start = $masonry_settings['is_start'];
	$is_masonry_end = $masonry_settings['is_end'];
} ?>

<?php if ( $is_masonry_start ) : ?><div class="masonry-column"><?php endif; ?>
    <article <?php post_class(); ?> data-post-id="<?php the_ID(); ?>">
        <?php alpaca_list_featured_media( 'image' ); ?>
	    <?php get_template_part( 'template-parts/archive/article-content' ); ?>
    </article>
<?php if ( $is_masonry_end ) : ?></div><?php endif;
