<article <?php post_class(); ?>>
    <div class="article-content">
        <header class="entry-header">
            <p class="error-message nothing-found"><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'alpaca' ); ?></p>
        </header>
        <?php get_search_form(); ?>
    </div>
</article>
