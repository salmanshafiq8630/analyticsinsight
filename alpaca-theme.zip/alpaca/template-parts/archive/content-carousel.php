<article <?php post_class(); ?>>
    <?php has_post_thumbnail() ? alpaca_list_featured_image( 'background' ) : ''; ?>
    <?php get_template_part( 'template-parts/archive/article-content' ); ?>
</article>
