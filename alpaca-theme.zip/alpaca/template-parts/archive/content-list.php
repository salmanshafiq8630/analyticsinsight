<article <?php post_class(); ?>>
    <?php alpaca_list_featured_media( 'background' ); ?>
    <?php get_template_part( 'template-parts/archive/article-content' ); ?>
</article>
