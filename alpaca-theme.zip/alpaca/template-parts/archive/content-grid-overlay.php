<?php
$post_class = get_post_class();
$post_class = array_merge( array( 'post-overlay' ), $post_class );
$metas = alpaca_get_post_list_prop( 'post_meta', array() );
$show_author = in_array( 'author', $metas );
$show_date = in_array( 'date', $metas );
$show_update_date = in_array( 'update_date', $metas );
$show_reading_time = in_array( 'reading_time', $metas ); ?>

<article class="<?php echo esc_attr( implode( ' ', $post_class ) ); ?>"><?php
    $format = get_post_format();
    $video_id = apply_filters( 'loftocean_front_has_post_featured_media', false ) && ( 'video' == $format )
        ? apply_filters( 'loftocean_get_current_video_id', false, apply_filters( 'loftocean_front_get_post_featured_media', '' ) ) : false;
    if ( has_post_thumbnail() ) :
        alpaca_list_featured_image( 'background' );
    else : ?>
        <div class="featured-img"></div><?php
    endif; ?>
    <div class="article-content">
        <header class="entry-header">
            <?php alpaca_list_format_label( get_post_format(), $video_id ); ?>
            <?php if ( in_array( 'sticky', $post_class ) ) : ?><div class="sticky-label"><?php esc_html_e( 'Sticky', 'alpaca' ); ?></div><?php endif; ?>
            <?php alpaca_list_category( $metas ); ?>
            <h2 class="entry-title">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <?php if ( $show_author || $show_date || $show_update_date || $show_reading_time ) : ?>
            <div class="entry-meta<?php if ( $show_author && alpaca_current_user_has_avatar() ) : ?> has-author-photo<?php endif; ?>">
                <?php alpaca_list_author( $metas ); ?>
                <?php if ( $show_date || $show_update_date || $show_reading_time ) : ?>
                <div class="meta-group">
                    <?php alpaca_list_date( $metas ); ?>
                    <?php alpaca_list_update_date( $metas ); ?>
                    <?php alpaca_list_reading_time( $metas ); ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </header>
    </div>
</article>
