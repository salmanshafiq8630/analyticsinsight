<?php
if ( alpaca_is_popup_signup_form_enabled() ) :
    $is_preview = alpaca_is_customize_preview();
    $form_id = alpaca_get_theme_mod( 'alpaca_popup_signup_form_id' );
    $form_exists = alpaca_is_item_exists( $form_id );
	$form = $form_exists ? get_post( $form_id ) : '';
	$form_title = $form_exists ? $form->post_title : '';
	$not_disturb_text = alpaca_get_theme_mod( 'alpaca_popup_signup_form_not_distrub_text' );
	$leave_message = alpaca_get_theme_mod( 'alpaca_popup_signup_form_exit_message_after_signed' );
	$background_image_id = alpaca_get_theme_mod( 'alpaca_popup_signup_form_image' );
    $auto_display = alpaca_module_enabled( 'alpaca_popup_signup_form_auto_display' );
	$class = array( 'popup-signup', alpaca_get_theme_mod( 'alpaca_popup_signup_form_color_scheme' ) );
    alpaca_is_item_exists( $background_image_id ) ? array_push( $class, 'has-img' ) : ''; ?>

	<div class="<?php echo esc_attr( implode( ' ', $class ) ); ?>">
		<div class="container">
            <span class="close-button"><?php esc_html_e( 'Close', 'alpaca' ); ?></span>
			<div class="container-inner">
                <?php alpaca_is_item_exists( $background_image_id ) ? alpaca_the_preload_bg( array(
    				'id' => $background_image_id,
    				'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'popup-form-background' ) ),
    				'class' => 'img-wrapper'
    			) ) : ''; ?>
				<div class="widget widget_mc4wp_form_widget"><?php
					if ( ! empty( $form_title ) ) : ?>
		    			<h5 class="widget-title"><?php echo esc_html( $form_title ); ?></h5><?php
					endif;
					$form_exists ? mc4wp_show_form( $form_id ) : ''; ?>
				</div><?php
				if ( has_nav_menu( 'popup-form' ) ) {
					wp_nav_menu( array(
						'theme_location' => 'popup-form',
						'container_class' => 'signup-screen-nav',
						'container' => 'div',
						'menu_class' => 'nav',
						'menu_id' => 'site-popup-form-menu',
						'depth' => 1
					) );
				} ?>
			</div><?php
    		if ( $is_preview || ( ! empty( $not_disturb_text ) || ! empty( $leave_message ) ) ) : ?>
    			<div class="popup-exit"><?php
    			if ( ! empty( $not_disturb_text ) && ( alpaca_module_enabled( 'alpaca_popup_signup_form_auto_display' ) || $is_preview ) ) : ?>
    				<a href="#" class="alpaca-disable-popup-signup-form"><?php echo esc_html( $not_disturb_text ); ?></a><?php
    			endif;
    			if ( ! empty( $leave_message ) ) : ?>
    				<a href="#" class="alpaca-exit-popup-signup-form"><?php echo esc_html( $leave_message ); ?></a><?php
    			endif; ?>
    			</div><?php
    		endif; ?>
		</div>
	</div><?php
endif;
