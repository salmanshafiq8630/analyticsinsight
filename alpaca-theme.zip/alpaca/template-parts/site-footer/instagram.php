<?php
$account = esc_attr( alpaca_get_theme_mod( 'alpaca_site_footer_instagram_username' ) );
$instagram_title = alpaca_get_theme_mod( 'alpaca_site_footer_instagram_title' );
$cols = intval( alpaca_get_theme_mod( 'alpaca_site_footer_instagram_columns' ) );
$rows = intval( alpaca_get_theme_mod( 'alpaca_site_footer_instagram_rows' ) );
$cols = ( $cols > 0 ) ? $cols : 6;
$number = $cols * ( ( $rows > 0 ) ? $rows : 1 );
$new_tab = alpaca_module_enabled( 'alpaca_site_footer_instagram_new_tab' );
$by_ajax = ( 'ajax' === apply_filters( 'loftocean_instagram_render_method', '' ) );
$attrs = array( 'class' => 'widget alpaca-widget_instagram column-' . esc_attr( $cols ) . ' fullwidth ' . alpaca_get_theme_mod( 'alpaca_site_footer_instagram_color_scheme' ) );
if ( $by_ajax ) {
    $attrs['data-user'] = $account;
    $attrs['data-limit'] = $number;
    $attrs['data-column'] = $cols;
    $attrs['data-new-tab'] = $new_tab;
    $attrs['data-location'] = 'footer';
} ?>

<div<?php alpaca_the_html_attributes( $attrs ); ?>>
    <?php if ( ! empty( $instagram_title ) ) : ?>
        <?php $url = 'https://www.instagram.com/' . $account; ?>
        <h5 class="widget-title">
            <a href="<?php echo esc_url( $url ); ?>"<?php if ( $new_tab ) : ?> target="_blank" rel="noopenner noreferrer"<?php endif; ?>><?php echo esc_html( $instagram_title ) ; ?></a>
        </h5>
    <?php endif; ?>
    <?php if ( ! $by_ajax ) {
        do_action( 'loftocean_instagram_the_html', $account, $number, $new_tab, array( 'column' => $cols ) );
    } ?>
</div>
