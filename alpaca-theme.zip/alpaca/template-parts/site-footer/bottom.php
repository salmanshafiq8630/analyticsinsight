<?php
$light_logo_id = alpaca_get_theme_mod( 'alpaca_site_footer_bottom_light_color_scheme_logo' );
$dark_logo_id = alpaca_get_theme_mod( 'alpaca_site_footer_bottom_dark_color_scheme_logo' );
$copyright_text = alpaca_get_theme_mod( 'alpaca_site_footer_bottom_copyright_text' );

$has_logo = alpaca_is_item_exists( $light_logo_id ) || alpaca_is_item_exists( $dark_logo_id );
$has_bottom_menu = alpaca_has_nav_menu( 'footer-bottom-menu' );
$has_copyright = ! empty( $copyright_text );

if ( $has_bottom_menu || $has_logo || $has_copyright ) : ?>
    <div class="footer-bottom <?php echo esc_attr( alpaca_get_theme_mod( 'alpaca_site_footer_bottom_color_scheme' ) ); ?>">
        <div class="container"><?php
        if ( $has_bottom_menu ) : ?>
            <div class="widget widget_nav_menu">
                <?php wp_nav_menu( array(
                    'theme_location' 	=> 'footer-bottom-menu',
                    'container' 		=> 'div',
                    'container_id' 		=> 'footer-bottom-menu-container',
                    'container_class' 	=> 'menu-footer-bottom-menu-container',
                    'menu_id' 			=> 'footer-bottom-menu',
                    'menu_class' 		=> 'menu',
                    'depth' 			=> 1
                ) ); ?>
            </div><?php
        endif;
        if ( $has_logo ) : ?>
            <div class="footer-logo">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php
                    $logo_width = absint( alpaca_get_theme_mod( 'alpaca_site_footer_bottom_logo_width' ) );
                    $size = array( $logo_width, 99999 );
                    if ( alpaca_is_item_exists( $light_logo_id ) && alpaca_is_item_exists( $dark_logo_id ) ) {
                        echo wp_get_attachment_image( $light_logo_id, $size, '', array( 'class' => 'light-logo' ) );
                        echo wp_get_attachment_image( $dark_logo_id, $size, '', array( 'class' => 'dark-logo' ) );
                    } else {
                        $logo_id = alpaca_is_item_exists( $light_logo_id ) ? $light_logo_id : $dark_logo_id;
                        echo wp_get_attachment_image( $logo_id, $size );
                    } ?>
                </a>
            </div><?php
        endif;
        if ( $has_copyright ) : ?>
            <div class="footer-site-info">
                <div class="widget widget_text">
                    <div class="textwidget"><?php echo do_shortcode( $copyright_text ); ?></div>
                </div>
            </div><?php
        endif; ?>
        </div>
    </div><?php
endif;
