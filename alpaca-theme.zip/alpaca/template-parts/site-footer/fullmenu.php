<div class="alpaca-fullmenu"><?php
	$show_search_form = alpaca_module_enabled( 'alpaca_fullscreen_menu_show_search_form' );
	$copyright_text = alpaca_get_theme_mod( 'alpaca_fullscreen_menu_copyright_text' );
	$is_customize_preview = alpaca_is_customize_preview();
	$has_menu_sidebar = is_active_sidebar( 'fullscreen-menu-sidebar' );
	if ( alpaca_has_nav_menu( 'primary-menu' ) || $show_search_form || ! empty( $copyright_text ) || $is_customize_preview ) : ?>
	<div class="menu-wrapper <?php echo esc_attr( alpaca_get_theme_mod( 'alpaca_fullscreen_menu_color_scheme' ) ); ?>">
		<span class="close-button"><?php esc_html_e( 'Close', 'alpaca' ); ?></span><?php
		$background_image_id = alpaca_get_theme_mod( 'alpaca_fullscreen_menu_background_image' );
		if ( alpaca_is_item_exists( $background_image_id ) ) : ?>
			<div class="fullmenu-bg<?php if ( alpaca_module_enabled( 'alpaca_fullscreen_menu_enable_overlay' ) ) : ?> has-overlay<?php endif; ?>">
			<?php alpaca_the_preload_bg( array(
	   			'id' => $background_image_id,
	   			'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => ( $has_menu_sidebar ?  'fullscreen-menu-background-with-widgets' : 'fullscreen-menu-background' ) ) ),
	   			'class' => 'fullmenu-bg-container'
	   		) ); ?>
			</div><?php
		endif; ?>
		<div class="container">
			<?php alpaca_primary_nav( array(
				'container' 		=> 'nav',
				'container_id' 		=> 'fullscreen-menu-main-navigation-wrap',
				'container_class' 	=> 'main-navigation',
				'menu_id' 			=> 'fullscreen-menu-main-menu',
				'menu_class' 		=> 'primary-menu'
			) ); ?>
			<?php if ( $show_search_form || $is_customize_preview ) : ?>
			<div class="search<?php if ( ! $show_search_form ) : ?> hide<?php endif; ?>">
				<form class="search-form" action="<?php echo esc_attr( apply_filters( 'loftocean_search_url', esc_url( home_url( '/' ) ) ) ); ?>">
					<label>
						<span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'alpaca' ); ?></span>
						<input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Hit enter to search', 'alpaca' ); ?>" autocomplete="off" name="s">
					</label>
					<?php do_action( 'loftocean_search_form' ); ?>
				</form>
			</div>
			<?php endif; ?>
			<?php if ( ! empty( $copyright_text ) || $is_customize_preview ) : ?><div class="text"><?php echo do_shortcode( $copyright_text ); ?></div><?php endif; ?>
		</div>
	</div><!-- end of .menu-wrapper -->
	<?php endif; ?>

	<?php if ( $has_menu_sidebar ) : ?>
	<aside class="widgets-wrapper widget-area <?php echo esc_attr( alpaca_get_theme_mod( 'alpaca_fullscreen_menu_widgets_color_scheme' ) ); ?>">
		<div class="container"><?php dynamic_sidebar( 'fullscreen-menu-sidebar' ); ?></div>
	</aside><!-- end of .widgets-wrapper -->
	<?php endif; ?>
</div>
