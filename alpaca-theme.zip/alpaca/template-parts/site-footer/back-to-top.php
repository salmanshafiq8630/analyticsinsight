<a href="#" class="top-btn"><span><?php esc_html_e( 'Scroll to top', 'alpaca' ); ?></span></a>
