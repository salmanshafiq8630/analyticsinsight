<?php
if ( alpaca_is_mc4wp_activated() && alpaca_module_enabled( 'alpaca_site_footer_show_signup_form' ) ) :
    $form_id = alpaca_get_theme_mod( 'alpaca_site_footer_signup_form_id' );
    $form_exists = alpaca_is_item_exists( $form_id );
	$form = $form_exists ? get_post( $form_id ) : '';
	$form_title = $form_exists ? $form->post_title : '';
	$background_image_id = alpaca_get_theme_mod( 'alpaca_site_footer_signup_form_background_image' );
    $has_background_image = alpaca_is_item_exists( $background_image_id );
    $class = array( 'site-footer-signup', alpaca_get_theme_mod( 'alpaca_site_footer_signup_form_color_scheme' ) );
    $has_background_image && alpaca_module_enabled( 'alpaca_site_footer_signup_form_enable_color_overlay' ) ? array_push( $class, 'has-overlay' ) : ''; ?>

	<div class="<?php echo esc_attr( implode( ' ', $class ) ); ?>">
        <?php alpaca_is_item_exists( $background_image_id ) ? alpaca_the_preload_bg( array(
            'id' => $background_image_id,
            'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'footer-background-image' ) ),
            'class' => 'bg-container'
        ) ) : ''; ?>
		<div class="container">
			<div class="widget widget_mc4wp_form_widget"><?php
				if ( ! empty( $form_title ) ) : ?>
	    			<h5 class="widget-title"><?php echo esc_html( $form_title ); ?></h5><?php
				endif;
				$form_exists ? mc4wp_show_form( $form_id ) : ''; ?>
			</div>
		</div>
	</div><?php
endif;
