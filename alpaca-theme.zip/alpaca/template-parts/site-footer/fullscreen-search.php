<?php if ( alpaca_module_enabled( 'alpaca_site_header_show_search_button' ) ) :
    $search_screen_class = array( 'search-screen' );
    alpaca_get_theme_mod( 'alpaca_site_header_fullscreen_search_style' ) ? array_push( $search_screen_class, 'minimal' ) : ''; ?>
    <div class="<?php echo esc_attr( implode( ' ', $search_screen_class ) ); ?>">
    	<div class="container">
    		<span class="close-button"><?php esc_html_e( 'Close', 'alpaca' ); ?></span>

    		<?php get_search_form(); ?>

    		<div class="search-filters"><?php
                $terms = array(
                    'category' => array( 'label' => esc_html__( 'Browse Categories', 'alpaca' ), 'class' => 'filter-categories', 'show' => alpaca_module_enabled( 'alpaca_site_header_fullscreen_search_show_category' ) ),
                    'post_tag' => array( 'label' => esc_html__( 'Browse Tags', 'alpaca' ), 'class' => 'filter-tags', 'show' => alpaca_module_enabled( 'alpaca_site_header_fullscreen_search_show_tag' ) )
                );
                // Author list
                $authors = array();
                $users = get_users( array( 'fields' => array( 'id', 'display_name' ) ) );
                foreach ( $users as $user ) {
                    if ( count_user_posts( $user->id ) > 0 ) {
                        $authors[] = $user;
                    }
                }
                foreach ( $terms as $tax_type => $attr ) :
                    $items = get_terms( array( 'taxonomy' => $tax_type ) );
                    if ( ! is_wp_error( $items ) && alpaca_is_valid_array( $items ) && $attr['show'] ) : ?>
        			<div class="<?php echo esc_attr( $attr['class'] ); ?>">
        				<span class="filter-title"><?php echo esc_html( $attr['label'] ); ?></span>
        				<ul>
                            <?php foreach( $items as $item ) : ?>
        					<li><a href="<?php echo esc_url( get_term_link( $item, $tax_type ) ); ?>"><?php echo esc_html( $item->name ); ?></a></li>
                            <?php endforeach; ?>
        				</ul>
        			</div><?php
                    endif;
                endforeach;
                if ( alpaca_is_valid_array( $authors ) && alpaca_module_enabled( 'alpaca_site_header_fullscreen_search_show_author' ) ) : ?>
    			<div class="filter-authors">
    				<span class="filter-title"><?php esc_html_e( 'Browse Authors', 'alpaca' ); ?></span>
    				<ul><?php
                        foreach( $authors as $author ) : ?>
    					<li><a href="<?php echo esc_url( get_author_posts_url( $author->id ) ); ?>"><?php echo esc_html( $author->display_name ); ?></a></li><?php
                        endforeach; ?>
    				</ul>
    			</div><?php
                endif; ?>
    		</div>
    	</div>
    </div>
<?php endif;
