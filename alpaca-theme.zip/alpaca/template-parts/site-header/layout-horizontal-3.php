<header id="masthead" <?php alpaca_the_site_header_class(); ?>>
	<div class="site-header-main header-3">
		<div class="container">
	        <?php get_template_part( 'template-parts/site-header/branding' ); ?>

			<button id="menu-toggle" class="menu-toggle"><?php esc_html_e( 'Menu', 'alpaca' ); ?></button>

			<?php alpaca_primary_nav(
				array( 'menu_id' => 'horizontal-site-header-main-menu', 'container_id' => 'horizontal-site-header-navigation' ),
				'<div class="menu-container">',
				'</div>',
				true
			); ?>

	        <div class="header-section-misc right">
				<?php get_template_part( 'template-parts/site-header/cart' ); ?>
	            <?php get_template_part( 'template-parts/site-header/more-section' ); ?>
				<?php if ( alpaca_module_enabled( 'alpaca_site_header_show_social_menu' ) && alpaca_has_nav_menu( 'social-menu' ) ) : ?>
					<?php alpaca_social_menu( array(
						'container' 		=> 'nav',
						'container_id' 	    => 'site-header-social-menu-wrap',
						'container_class' 	=> 'social-navigation',
						'menu_id' 			=> 'site-header-social-menu',
						'menu_class' 		=> 'social-nav menu'
					) ); ?>
				<?php endif; ?>
	        </div><!-- end of .misc right -->
	    </div><!-- end of .container -->
		<?php get_template_part( 'template-parts/single/post/reading-progress-bar' ); ?>
	</div>
</header>
