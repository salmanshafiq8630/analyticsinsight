<header id="masthead" <?php alpaca_the_site_header_class(); ?>>
	<div class="site-header-main">
		<div class="container">
	        <?php get_template_part( 'template-parts/site-header/branding' ); ?>
			<div class="header-section-misc left">
				<?php if ( alpaca_module_enabled( 'alpaca_site_header_show_social_menu' ) && alpaca_has_nav_menu( 'social-menu' ) ) {
					alpaca_social_menu( array(
						'container' 		=> 'nav',
						'container_id' 	    => 'site-header-social-menu-wrap',
						'container_class' 	=> 'social-navigation',
						'menu_id' 			=> 'site-header-social-menu',
						'menu_class' 		=> 'social-nav menu',
					) );
				} ?>
				<button id="menu-toggle" class="menu-toggle"><?php esc_html_e( 'Menu', 'alpaca' ); ?></button>
			</div>

			<div class="header-section-misc right">
				<?php get_template_part( 'template-parts/site-header/cart' ); ?>
				<?php get_template_part( 'template-parts/site-header/more-section' ); ?>
	        </div><!-- end of .misc right -->
		</div>
		<?php get_template_part( 'template-parts/single/post/reading-progress-bar' ); ?>
	</div>
</header>
