<header id="masthead" <?php alpaca_the_site_header_class(); ?>>
	<div class="site-header-main">
		<div class="container">
	        <?php get_template_part( 'template-parts/site-header/branding' ); ?>
			<?php if ( alpaca_has_nav_menu( 'primary-menu' ) ) : ?>
			<div class="nav-wrapper">
				<?php alpaca_primary_nav( array(
					'container' 		=> 'nav',
					'container_id' 		=> 'site-header-main-navigation-wrap',
					'container_class' 	=> 'main-navigation',
					'menu_id' 			=> 'site-header-main-menu',
					'menu_class' 		=> 'primary-menu'
				) ); ?>
			</div>
			<?php endif; ?>

			<button id="menu-toggle" class="menu-toggle"><?php esc_html_e( 'Menu', 'alpaca' ); ?></button>

			<div class="header-section-misc">
				<?php get_template_part( 'template-parts/site-header/cart' ); ?>
				<?php get_template_part( 'template-parts/site-header/more-section' ); ?>
				<?php if ( alpaca_module_enabled( 'alpaca_site_header_show_social_menu' ) && alpaca_has_nav_menu( 'social-menu' ) ) : ?>
					<?php alpaca_social_menu( array(
						'container' 		=> 'nav',
						'container_id' 	    => 'site-header-social-menu-wrap',
						'container_class' 	=> 'social-navigation',
						'menu_id' 			=> 'site-header-social-menu',
						'menu_class' 		=> 'social-nav menu',
					) ); ?>
				<?php endif; ?>
			</div>
		</div>
		<?php get_template_part( 'template-parts/single/post/reading-progress-bar' ); ?>
	</div>
</header>

<div class="top-corner is-sticky show-it">
	<?php add_filter( 'alpaca_show_more_toggle_button', 'alpaca_show_more_toggle_button' ); ?>
	<?php get_template_part( 'template-parts/site-header/more-section' ); ?>
	<?php get_template_part( 'template-parts/site-header/cart' ); ?>
</div>
