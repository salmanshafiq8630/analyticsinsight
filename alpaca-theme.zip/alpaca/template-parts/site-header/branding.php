<div class="site-branding">
    <?php if ( alpaca_has_site_header_logo() ) : ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link"><?php alpaca_the_site_logo_group(); ?></a>
    <?php endif; ?>
    <div class="site-titles<?php if ( ! display_header_text() ) : ?> hide-title-tagline<?php endif; ?>">
        <<?php if ( is_home() ) : ?>h1<?php else : ?>p<?php endif; ?> class="site-title">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
        </<?php if ( is_home() ) : ?>h1<?php else : ?>p<?php endif; ?>><?php
        $description = get_bloginfo( 'description', 'display' );
        if ( ! empty( $description ) || alpaca_is_customize_preview() ) : ?>
            <div class="site-description"><?php bloginfo( 'description', 'display' ); ?></div> <?php
        endif; ?>
    </div>
</div><!-- end of .site-branding -->
