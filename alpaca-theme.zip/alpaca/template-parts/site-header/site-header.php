<?php
get_template_part( 'template-parts/site-header/layout', alpaca_get_theme_mod( 'alpaca_site_header_layout' ) );
