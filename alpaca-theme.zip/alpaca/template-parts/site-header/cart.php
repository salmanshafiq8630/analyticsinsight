<?php if ( alpaca_is_woocommerce_activated() ) :
    $cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : WC()->cart->get_cart_url();
    $cart = WC()->cart->get_cart(); ?>
    <div id="site-header-cart" class="site-header-cart">
        <a class="cart-contents" href="<?php echo esc_url( $cart_url ); ?>" title="<?php esc_attr_e( 'View your shopping cart', 'alpaca' ); ?>">
            <span class="cart-icon"></span>
            <?php if ( alpaca_is_valid_array( $cart ) ) : ?><span class="cart-notification"></span><?php endif; ?>
        </a>

        <div class="widget woocommerce widget_shopping_cart">
            <div class="widget_shopping_cart_content">
                <?php woocommerce_mini_cart(); ?>
            </div>
        </div>
    </div>
<?php endif;
