<?php
alpaca_the_social_bar( false, alpaca_is_social_sharing_enabled( 'main' ) );
$footer_metas = array();
$tags = get_the_tag_list( '<aside class="post-tag-cloud"><div class="tagcloud">', ' ', '</div></aside>' );

if ( alpaca_module_enabled( 'alpaca_single_post_footer_meta_show_comment_counts' ) ) {
    $num = get_comments_number();
    if ( comments_open() || $num ) {
        array_push( $footer_metas, 'comment' );
    }
}
if ( current_user_can( 'edit_post', get_the_ID() ) ) {
    array_push( $footer_metas, 'edit' );
}
if ( alpaca_is_extension_activated() ) {
    alpaca_module_enabled( 'alpaca_single_post_footer_meta_show_view_counts' ) ? array_push( $footer_metas, 'view' ) : '';
    alpaca_module_enabled( 'alpaca_single_post_footer_meta_show_like_counts' ) ? array_push( $footer_metas, 'like' ) : '';
}
if ( ! empty( $tags ) || alpaca_is_valid_array( $footer_metas ) ) : ?>
    <footer class="entry-footer">
        <?php the_tags( '<aside class="post-tag-cloud"><div class="tagcloud">', ' ', '</div></aside>' ); ?>
        <?php if ( alpaca_is_valid_array( $footer_metas ) ) : ?>
        <div class="meta">
            <?php in_array( 'view', $footer_metas ) ? do_action( 'loftocean_post_metas_view_label' ) : ''; ?>
            <?php in_array( 'like', $footer_metas ) ? do_action( 'loftocean_post_metas_like_label' ) : ''; ?>
            <?php in_array( 'comment', $footer_metas ) ? alpaca_meta_comment() : ''; ?>
            <?php in_array( 'edit', $footer_metas ) ? alpaca_meta_edit_link() : ''; ?>
        </div>
        <?php endif; ?>
    </footer><?php
endif;
