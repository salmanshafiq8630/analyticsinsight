<?php
    if ( alpaca_is_single_signup_form_enabled() ):
    	$form_id = alpaca_get_theme_mod( 'alpaca_single_post_signup_form_id' );
    	$form = get_post( $form_id );
    	$form_title = $form->post_title;
        $classes = array( 'signup-form', alpaca_get_theme_mod( 'alpaca_single_post_signup_form_color_scheme' ) );
        alpaca_module_enabled( 'alpaca_single_post_signup_form_enable_color_overlay' ) ? array_push( $classes, 'has-overlay' ) : '';
        $bg_image = alpaca_get_theme_mod( 'alpaca_single_post_signup_form_bg_image' );
        $bg_image_args = array( 'id' => $bg_image, 'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'singular-form', 'sub_module' => 'signup' ) ) ); ?>

    	<aside class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"<?php if ( alpaca_is_item_exists( $bg_image ) ) : ?> <?php alpaca_the_background_image_attrs( $bg_image_args ); ?><?php endif; ?>>
    		<div class="widget widget_mc4wp_form_widget">
    		<?php if ( ! empty( $form_title ) ) : ?>
    			<h2 class="widget-title"><?php echo esc_html( $form_title ); ?></h2>
    		<?php endif; ?>
    		<?php mc4wp_show_form( $form_id ); ?>
    		</div>
    	</aside> <?php
    endif;
