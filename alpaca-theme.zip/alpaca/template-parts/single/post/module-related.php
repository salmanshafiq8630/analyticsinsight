<?php
if ( alpaca_module_enabled( 'alpaca_single_post_show_related_posts' ) ) :
	$number = intval( alpaca_get_theme_mod( 'alpaca_single_post_related_post_number' ) );
	$filter = alpaca_get_theme_mod( 'alpaca_single_post_related_post_filter' );
	$related_title = alpaca_get_theme_mod( 'alpaca_single_post_related_post_section_title' );
	$related_posts = apply_filters( 'alpaca_front_get_related_posts', '', $filter, $number );
    $image_sizes = alpaca_Utils_Image::get_image_sizes( array( 'module' => 'singular', 'sub_module' => 'related-posts' ) );
	if ( ! empty( $related_posts ) && ! is_wp_error( $related_posts ) && $related_posts->have_posts() ) : ?>

        <div class="related-posts">
            <h4 class="related-posts-title"><?php echo esc_html( $related_title ); ?></h4>
			<div class="posts layout-grid column-4 <?php echo esc_attr( alpaca_get_theme_mod( 'alpaca_single_post_related_post_image_ratio' ) ); ?>">
				<div class="posts-wrapper"><?php
	            while ( $related_posts->have_posts() ) :
	                $related_posts->the_post(); ?>
					<article class="post<?php if ( has_post_thumbnail() ) : ?> has-post-thumbnail<?php endif; ?>">
						<?php if ( has_post_thumbnail() ) : ?>
						<div class="featured-img">
							<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $image_sizes[0] ); ?></a>
						</div>
						<?php endif; ?>
						<div class="article-content">
							<header class="entry-header">
								<h2 class="entry-title">
									<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
								</h2>
								<div class="entry-meta">
									<div class="meta-group">
										<div class="meta-item post-date">
											<a href="<?php the_permalink() ?>"><?php echo esc_html( get_the_date() ); ?></a>
										</div>
										<?php alpaca_the_meta_reading_time(); ?>
									</div>
								</div>
							</header>
						</div>
					</article><?php
	            endwhile;
				wp_reset_postdata(); ?>
				</div>
            </div>
        </div><?php
    endif;
endif;
