<?php
if ( alpaca_module_enabled( 'alpaca_single_post_show_author_info_box' ) ) :
	$authors = alpaca_get_post_authors();
	$show_info_box = false;
	$has_co_author = false;
	foreach ( $authors as $author ) {
		$description = get_the_author_meta( 'description', $author->ID );
		if ( ! empty( $description ) ) {
			$has_co_author = $show_info_box ? true : false;
			$show_info_box = true;
		}
		if ( $has_co_author ) {
			break;
		}
	}
	if ( $show_info_box ) : ?>
		<aside class="author-info-box<?php if ( $has_co_author ) : ?> multi-authors<?php endif; ?>"><?php
		foreach ( $authors as $author ) :
			$author_id = $author->ID;
			$author_name = $author->display_name;
			$author_url = get_author_posts_url( $author_id );
			$avatar = get_avatar( $author->user_email, 160 );
			$description = get_the_author_meta( 'description', $author_id );
			if ( ! empty( $description ) ) : ?>
				<div class="container">
			        <?php if ( ! empty( $avatar ) ) : ?>
			        <div class="author-photo">
			            <?php echo get_avatar( $author->user_email, 160 ); ?>
			        </div>
			        <?php endif; ?>
			        <div class="author-info">
			            <h4 class="author-name">
			                <a href="<?php echo esc_url( $author_url ); ?>"><?php echo esc_html( $author_name ); ?></a>
			            </h4>
			            <div class="author-bio-text"><?php the_author_meta( 'description', $author_id ); ?></div>
			            <?php do_action( 'loftocean_front_the_user_social', $author_id ); ?>
			        </div>
				</div><?php
			endif;
		endforeach; ?>
		</aside> <?php
	endif;
endif;
