<?php if ( is_singular( 'post' ) && alpaca_module_enabled( 'alpaca_single_post_show_reading_progress_bar' ) ) : ?>
    <div class="reading-progress"></div>
<?php endif;
