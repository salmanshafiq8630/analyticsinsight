<?php
if ( alpaca_module_enabled( 'alpaca_single_post_show_pagination' ) ) {
	$prev = get_adjacent_post( false, '', true, 'category' );
	$next = get_adjacent_post( false, '', false, 'category' );
	$image_size_args = array( 'module' => 'singular' , 'sub_module' => 'single-pagination' );
	$prev_text = sprintf(
		'[[ALPACA_POST_NAV_PREV_BG]]<div class="post-info"><span class="text">%1$s</span><span class="post-title entry-title">%2$s</span></div>',
		esc_html__( 'Prev', 'alpaca' ),
		'%title'
	);
	$next_text = sprintf(
		'[[ALPACA_POST_NAV_NEXT_BG]]<div class="post-info"><span class="text">%1$s</span><span class="post-title entry-title">%2$s</span></div>',
		esc_html__( 'Next', 'alpaca' ),
		'%title'
	);

	if ( ( $prev && get_post_thumbnail_id( $prev->ID ) ) && ( $next && get_post_thumbnail_id( $next->ID ) ) ) {
		$image_size_args['sub_module'] = 'pagination';
	}
	$image_sizes = Alpaca_Utils_Image::get_image_sizes( $image_size_args );
	$prev = ( $prev && get_post_thumbnail_id( $prev->ID ) ) ? alpaca_get_preload_bg( array(
		'id' => get_post_thumbnail_id( $prev->ID ),
		'sizes' => $image_sizes,
		'class' => 'post-thumb'
	) ) : '<div class="post-thumb"></div>';
	$next = ( $next && get_post_thumbnail_id( $next->ID ) ) ? alpaca_get_preload_bg( array(
		'id' => get_post_thumbnail_id( $next->ID ),
		'sizes' => $image_sizes,
		'class' => 'post-thumb'
	) ) : '<div class="post-thumb"></div>';
	$prev_text = str_replace( '[[ALPACA_POST_NAV_PREV_BG]]', $prev, $prev_text );
	$next_text = str_replace( '[[ALPACA_POST_NAV_NEXT_BG]]', $next, $next_text );
	the_post_navigation( array( 'next_text' => $next_text, 'prev_text' => $prev_text ) );
}
