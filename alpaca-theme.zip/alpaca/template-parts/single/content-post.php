<?php
$post_template = apply_filters( 'alpaca_post_template', '' );
$is_template_split = ( 'split' == $post_template );
$outside_header = in_array( $post_template, array( 'wide', 'overlay' ) );
if ( $outside_header && have_posts() ) {
	the_post();
	get_template_part( 'template-parts/headers/post', $post_template );
	rewind_posts();
} ?>

<div class="main">
	<div class="container">
		<div id="primary" class="primary content-area"><?php
		while ( have_posts() ) :
			the_post(); ?>
			<article <?php post_class(); ?>><?php
				if ( $is_template_split ) {
					get_template_part( 'template-parts/headers/post', $post_template );
				} else {
					alpaca_the_social_bar(
						true,
						alpaca_is_social_sharing_enabled( 'sticky' ),
						array( 'sticky' => true )
					);
				} ?>
				<div class="article-content">
					<?php ( 'normal' == $post_template ) ? get_template_part( 'template-parts/headers/post', $post_template ) : ''; ?>
					<?php if ( 'wide' == $post_template ) : ?>
						<header class="entry-header"><?php get_template_part( 'template-parts/headers/post', 'header-text' ); ?></header>
					<?php endif; ?>
					<?php do_action( 'alpaca_the_advertisement', 'before_single_post_content' ); ?>
					<div class="entry-content"><?php
						the_content();
						alpaca_the_single_pagination(); ?>
					</div><!-- end of .entry-content -->
					<?php do_action( 'alpaca_the_advertisement', 'after_single_post_content' ); ?>
					<?php get_template_part( 'template-parts/single/post/signup-form' ); ?>
					<?php get_template_part( 'template-parts/single/post/after-content' ); ?>
				</div>
				<?php get_template_part( 'template-parts/single/post/authorbox' ); ?>
			</article><?php
			get_template_part( 'template-parts/single/post/module-pagination' );
			get_template_part( 'template-parts/single/post/module-related' );
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }
		endwhile;
		wp_reset_postdata(); ?>
	</div><!-- end of #primary -->
        <?php get_sidebar(); ?>
	</div>
</div>
