<?php
while ( have_posts() ) :
    the_post();
    get_template_part( 'template-parts/headers/page' ); ?>
    <div class="main">
    	<div class="container">
    		<div id="primary" class="primary content-area">
    			<article <?php post_class(); ?>>
    				<div class="article-content">
    					<div class="entry-content"><?php
                            the_content();
                            alpaca_the_single_pagination(); ?>
                        </div><!-- end of .entry-content -->
                        <?php current_user_can( 'edit_post', get_the_ID() ) ? alpaca_meta_edit_link() : ''; ?>
    				</div>
    			</article><?php
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                } ?>
    		</div><!-- end of #primary -->
            <?php get_sidebar(); ?>
    	</div>
    </div><?php
endwhile;
wp_reset_postdata();
