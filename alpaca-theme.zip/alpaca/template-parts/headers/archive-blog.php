<?php
$page_id = get_option( 'page_for_posts' );
if ( alpaca_is_item_exists( $page_id ) && is_home() ) :
    $blog_page = get_post( $page_id );
    $thumb_id = get_post_thumbnail_id( $page_id );
    $has_featured_image = alpaca_is_item_exists( $thumb_id );
    $add_autop = true;
    $blog_page_description = empty( $blog_page ) ? '' : $blog_page->post_content;
    $page_title_allowed_html = array(
        'a' => array( 'href' => 1, 'class' => 1, 'id' => 1, 'target' => 1, 'rel' => 1 ),
        'b' => array(), 'i' => array(), 'span' => array( 'class' => 1, 'id' => 1 ),
        'strong' => array(), 'em' => array(), 'sub' => array(), 'sup' => array()
    );
    if ( function_exists( 'parse_blocks' ) && ! empty( $blog_page_description ) ) {
        $page_blocks = parse_blocks( $blog_page_description );
        if ( count( $page_blocks ) > 0 ) {
        	if ( count( $page_blocks ) > 1 && $page_blocks[0]['blockName'] !== null ) {
                $blog_page_description = '';
                $add_autop = false;
        		foreach ( $page_blocks as $page_block ) {
        			$blog_page_description .= render_block( $page_block );
        		}
        	}
        }
    }
    if ( $add_autop && ! empty( $blog_page_description ) ) {
        $blog_page_description = wpautop( $blog_page_description );
    } ?>

    <header class="archive-header<?php if ( $has_featured_image ) : ?> overlay-header<?php endif; ?>">
        <?php if ( $has_featured_image ) : ?>
    	<div<?php alpaca_the_page_header_class(); ?>>
    		<div class="header-img-container">
                <?php do_action(
                    'alpaca_get_preload_bg',
                    $thumb_id,
                    Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'page-header' ) ),
                    'featured-img-container'
                ); ?>
    		</div>
    	</div>
        <?php endif ; ?>

    	<div class="header-text">
            <?php alpaca_show_yoast_seo_breadcrumbs( 'archive' ); ?>
    		<h1 class="archive-title"><?php echo wp_kses( get_the_title( $page_id ), $page_title_allowed_html ); ?></h1>
    		<?php if ( ! empty( $blog_page_description ) ) : ?><div class="archive-description"><?php echo do_shortcode( $blog_page_description ); ?></div><?php endif; ?>
    	</div>
    </header><?php
endif;
