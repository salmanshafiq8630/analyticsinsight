<?php
$userID = get_queried_object_id();
$description = get_the_author_meta( 'description', $userID );
$avatar = get_avatar( get_the_author_meta( 'user_email', $userID ), 160 );
$has_featured_image = apply_filters( 'loftocean_has_user_featured_image', false , $userID ); ?>

<header class="archive-header<?php if ( $has_featured_image ) : ?> overlay-header<?php endif; ?>">
    <?php if ( $has_featured_image ) : ?>
    <div<?php alpaca_the_page_header_class(); ?>>
		<div class="header-img-container">
        <?php do_action(
            'loftocean_the_user_featured_image',
            $userID,
            Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'page-header' ) ),
            array( 'class' => 'featured-img-container' )
        ); ?>
		</div>
	</div>
    <?php endif; ?>
	<div class="header-text">
        <?php alpaca_show_yoast_seo_breadcrumbs( 'archive' ); ?>
        <?php if ( ! empty( $avatar ) ) : ?>
        <div class="author-photo">
            <?php echo get_avatar( get_the_author_meta( 'user_email', $userID ), 160 ); ?>
        </div>
        <?php endif; ?>
        <div class="author-info">
			<h1 class="archive-title author-name"><?php the_author_meta( 'display_name', $userID ); ?></h1>
            <?php if ( ! empty( $description ) ) : ?>
				<div class="archive-description"><?php the_author_meta( 'description', $userID ); ?></div>
			<?php endif; ?>
            <?php do_action( 'loftocean_front_the_user_social', $userID ); ?>
		</div>
	</div>
</header>
