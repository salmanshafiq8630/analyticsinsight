<header class="entry-header">
	<?php get_template_part( 'template-parts/headers/post', 'header-text' ); ?>
	<?php alpaca_the_single_featured_section( 'normal' ); ?>
</header>
