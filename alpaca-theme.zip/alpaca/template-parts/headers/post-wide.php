<?php alpaca_the_single_featured_section( 'wide' );
