<header class="archive-header">
	<div class="header-text"><?php
        alpaca_show_yoast_seo_breadcrumbs( 'archive' );
		if ( is_year() ) : ?>
			<span><?php esc_html_e( 'Yearly Archives', 'alpaca' ); ?></span><?php
		elseif ( is_month() ) : ?>
			<span><?php esc_html_e( 'Monthly Archives', 'alpaca' ); ?></span><?php
		elseif ( is_day() ) : ?>
			<span><?php esc_html_e( 'Daily Archives', 'alpaca' ); ?></span><?php
		endif; ?>
        <h1 class="archive-title"><?php
            if ( is_year() ) {
				echo esc_html( get_the_date( _x( 'Y', 'yearly archives date format', 'alpaca' ) ) );
            } else if ( is_month() ) {
                echo esc_html( get_the_date( _x( 'F Y', 'monthly archives date format', 'alpaca' ) ) );
            } else if ( is_day() ) {
                echo esc_html( get_the_date( _x( 'F j, Y', 'daily archives date format', 'alpaca' ) ) );
            } ?>
        </h1>
    </div>
</header>
