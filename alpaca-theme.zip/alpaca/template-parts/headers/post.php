<header class="entry-header overlay-header article-side-section is-sticky">
    <?php alpaca_the_single_featured_section( 'split' ); ?>
    <?php get_template_part( 'template-parts/headers/post', 'header-text' ); ?>
    <?php alpaca_the_social_bar( true, alpaca_is_social_sharing_enabled( 'sticky' ), array( 'sticky' => true ) ); ?>
</header>
