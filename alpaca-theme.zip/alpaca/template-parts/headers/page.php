<?php
$has_thumbnail = has_post_thumbnail();
$header_class = array( 'entry-header', 'page-header' );
$has_thumbnail ? array_push( $header_class, 'overlay-header' ) : '';
$page_sub_title = apply_filters( 'alpaca_singular_page_settings', '', 'sub_title' );
$sub_title_allowed_html = array( 'a' => array( 'href' => 1, 'class' => 1, 'target' => 1, 'rel' => 1, 'id' => 1 ) ); ?>

<header class="<?php echo esc_attr( implode( ' ', $header_class ) ); ?>">
    <?php if ( $has_thumbnail ) : ?>
	<div<?php alpaca_the_page_header_class(); ?>>
		<div class="header-img-container">
			<?php alpaca_the_preload_bg( array( 'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'singular', 'sub_module' => 'header' ) ) ) ); ?>
		</div>
	</div>
    <?php endif; ?>
	<div class="header-text">
        <?php is_singular( array( 'page' ) ) ? alpaca_show_yoast_seo_breadcrumbs( 'page' ) : ''; ?>
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
        <?php if ( ! empty( $page_sub_title ) ) : ?><p class="sub-title"><?php echo wp_kses( $page_sub_title, $sub_title_allowed_html ); ?></p><?php endif; ?>
	</div>
</header>
