<?php
$term_queried = get_queried_object();
$has_featured_image = apply_filters( 'loftocean_front_has_taxonomy_featured_image', false, $term_queried ); ?>

<header class="archive-header<?php if ( $has_featured_image ) : ?> overlay-header<?php endif; ?>">
    <?php if ( $has_featured_image ) : ?>
	<div<?php alpaca_the_page_header_class(); ?>>
		<div class="header-img-container">
            <?php do_action(
                'loftocean_front_the_taxonomy_featured_image',
                $term_queried,
                Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'page-header' ) ),
                array( 'class' => 'featured-img-container' )
            ); ?>
		</div>
	</div>
    <?php endif ; ?>

	<div class="header-text">
        <?php alpaca_show_yoast_seo_breadcrumbs( 'archive' ); ?>
		<h1 class="archive-title"><?php single_term_title(); ?></h1>
		<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>
	</div>
</header>
