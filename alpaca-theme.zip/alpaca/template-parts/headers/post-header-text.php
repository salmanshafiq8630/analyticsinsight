<?php
global $post;
$show_date = alpaca_module_enabled( 'alpaca_single_post_header_meta_show_date' );
$show_update_date = alpaca_module_enabled( 'alpaca_single_post_header_meta_show_update_date' );
$show_reading_time = alpaca_module_enabled( 'alpaca_single_post_header_meta_show_reading_time' );
$show_author = alpaca_module_enabled( 'alpaca_single_post_header_meta_show_author' );
$author_metas = alpage_get_author_metas();
$post_template = apply_filters( 'alpaca_post_template', '' );
$is_format_video = ( 'video' == get_post_format() ) && apply_filters( 'loftocean_front_has_post_featured_media', false );
if ( $is_format_video && ( 'split' == $post_template ) ) {
    alpaca_the_single_featured_video_button( 'reslide slide-up' );
} ?>
<div class="header-text">
    <?php alpaca_show_yoast_seo_breadcrumbs(); ?>
    <?php alpaca_module_enabled( 'alpaca_single_post_header_meta_show_category' ) ? alpaca_the_meta_category() : ''; ?>
    <h1 class="entry-title"><?php the_title(); ?></h1>
    <?php if ( $show_date || $show_update_date || $show_reading_time || $show_author ) : ?>
    <div class="entry-meta<?php if ( $show_author && ! empty( $author_metas['avatar'] ) ) : ?> has-author-photo<?php endif; ?>">
        <?php $show_author ? alpaca_meta_author() : ''; ?>
        <?php if ( $show_date || $show_update_date || $show_reading_time ) : ?>
        <div class="meta-group">
            <?php $show_date ? alpaca_the_meta_date() : ''; ?>
            <?php $show_update_date ? alpaca_the_meta_update_date( $show_date ) : ''; ?>
            <?php $show_reading_time ? alpaca_the_meta_reading_time() : ''; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ( alpaca_module_enabled( 'alpaca_single_post_header_meta_show_manual_excerpt' ) && ! empty( $post->post_excerpt ) ) : ?>
    <div class="entry-excerpt"><?php the_excerpt(); ?></div>
    <?php endif; ?>
    <?php if ( $is_format_video && ( 'overlay' == $post_template ) ) : ?>
    <div class="play-btn-wrapper"><?php alpaca_the_single_featured_video_button(); ?></div>
    <?php endif; ?>
</div>
