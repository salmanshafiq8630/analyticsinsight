<header class="archive-header">
	<div class="header-text">
        <?php alpaca_show_yoast_seo_breadcrumbs( 'archive' ); ?>
		<h1 class="archive-title"><?php single_term_title(); ?></h1>
		<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>
	</div>
</header>
