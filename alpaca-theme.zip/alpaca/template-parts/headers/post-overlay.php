<header class="entry-header overlay-header">
	<?php alpaca_the_single_featured_section( 'overlay' ); ?>
	<?php get_template_part( 'template-parts/headers/post', 'header-text' ); ?>
</header>
