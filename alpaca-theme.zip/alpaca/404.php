<?php
/**
* Template for 404 page
*/

do_action( 'alpaca_check_front_requirement' );
$page_title = alpaca_get_theme_mod( 'alpaca_404_page_title' );
$page_content = alpaca_get_theme_mod( 'alpaca_404_page_message' );
$page_bg_image = alpaca_get_theme_mod( 'alpaca_404_page_bg_image' );
$color_scheme = alpaca_get_theme_mod( 'alpaca_404_page_color_scheme' );
$show_search_form = alpaca_module_enabled( 'alpaca_404_page_show_search_form' );
get_header(); ?>

	<div class="main">
		<div class="container">
			<div id="primary" class="primary content-area">
				<article class="page type-page page-404 <?php echo esc_attr( $color_scheme ); ?>">
				<?php alpaca_is_item_exists( $page_bg_image ) ? alpaca_the_preload_bg( array(
					'id' => $page_bg_image,
					'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => '404-background' ) ),
					'class' => 'page-404-bg'
				) ) : ''; ?>
				<?php if ( ! empty( $page_title ) && ! empty( $page_content ) || $show_search_form ) : ?>
					<div class="page-404-content">
					<?php if ( ! empty( $page_title ) ) : ?>
						<?php alpaca_show_yoast_seo_breadcrumbs( 'page' ); ?>
						<h1 class="entry-title"><?php echo esc_html( $page_title ); ?></h1>
					<?php endif; ?>
					<?php if ( ! empty( $page_content ) ) {
						$page_content = wpautop( $page_content );
						echo wp_kses( $page_content, array(
							'p' => array( 'class' => 1, 'id' => 1, 'data-*' => 1 ),
							'b' => array(), 'i' => array(), 'br' => array(),
							'em' => array(), 'strong' => array(),
							'a' => array( 'href' => 1, 'class' => 1, 'id' => 1, 'target' => 1, 'title' => 1, 'data-*' => 1, 'rel' => 1 )
						) );
					} ?>
					<?php if ( $show_search_form ) : ?>
						<?php get_search_form(); ?>
					<?php endif; ?>
					</div>
				<?php endif; ?>
				</article>
			</div>
		</div>
	</div><?php
get_footer();
