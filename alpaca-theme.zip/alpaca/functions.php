<?php
require_once get_template_directory() . '/includes/class-loader.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
alpaca();
