<?php
/**
* Main sidebar template
*/

$sidebar_id = apply_filters( 'alpaca_sidebar_id', 'primary-sidebar' );

if ( ! empty( $sidebar_id ) && alpaca_show_sidebar() && is_active_sidebar( $sidebar_id ) ) : ?>
	<aside id="secondary"<?php alpaca_the_site_sidebar_class(); alpaca_the_site_sidebar_attributes(); ?>>
		<div class="sidebar-container">
			<?php dynamic_sidebar( $sidebar_id ); ?>
		</div> <!-- end of .sidebar-container -->
	</aside><!-- end of .sidebar --> <?php
endif;
