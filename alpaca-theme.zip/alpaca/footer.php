            </div> <!-- end of #content -->
            <?php do_action( 'alpaca_the_site_footer' ); ?>
        </div> <!-- end of #page -->

        <?php get_template_part( 'template-parts/site-footer/fullmenu' ); ?>
        <?php get_template_part( 'template-parts/site-footer/popup-signup-form' ); ?>
        <?php get_template_part( 'template-parts/site-footer/fullscreen-search' ); ?>
        <?php wp_footer(); ?>
    </body>
</html>
