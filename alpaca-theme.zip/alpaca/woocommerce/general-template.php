<?php
// Woocommerce general template

get_header();

while ( have_posts() ) :
    the_post();
    $has_thumbnail = has_post_thumbnail();
    $page_title = get_the_title();
    $header_class = array( 'entry-header', 'page-header' );
    $has_thumbnail ? array_push( $header_class, 'overlay-header' ) : ''; ?>

    <header class="<?php echo esc_attr( implode( ' ', $header_class ) ); ?>">
        <?php if ( $has_thumbnail ) : ?>
    	<div<?php alpaca_the_page_header_class(); ?>>
    		<div class="header-img-container">
    			<?php alpaca_the_preload_bg( array( 'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'singular', 'sub_module' => 'header' ) ) ) ); ?>
    		</div>
    	</div>
        <?php endif; ?>
    	<div class="header-text">
            <?php woocommerce_breadcrumb(); ?>
    		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
    	</div>
    </header>

    <div class="main">
    	<div class="container">
    		<div id="primary" class="primary content-area"><?php the_content(); ?></div>
    	</div>
    </div><?php
endwhile;
wp_reset_postdata();

get_footer();
