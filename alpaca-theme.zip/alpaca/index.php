<?php
// Main template
get_header();

if ( is_singular() ) {
	get_template_part( 'template-parts/single/content', get_post_type() );
} else {
    $archive_page = apply_filters( 'alpaca_achive_page_queried', '' );
    if ( 'home' != $archive_page ) {
        get_template_part( 'template-parts/headers/archive', $archive_page );
    } ?>
    <div class="main">
    	<div class="container">
    		<div id="primary" class="primary content-area">
    			<?php do_action( 'alpaca_the_list_content', $archive_page ); ?>
    		</div>
    		<?php get_sidebar(); ?>
    	</div>
    </div><!-- end of .main --><?php
}

get_footer();
