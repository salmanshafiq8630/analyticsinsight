<div class="search">
    <form class="search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
        <label>
            <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'alpaca' ); ?></span>
            <input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Hit enter to search', 'alpaca' ); ?>" autocomplete="off" name="s">
        </label>
        <?php do_action( 'loftocean_search_form' ); ?>
    </form>
</div>
