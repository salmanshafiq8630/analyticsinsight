<?php
if ( ! class_exists( 'Alpaca_Extension_Filters' ) ) {
    class Alpaca_Extension_Filters {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'loftocean_get_widget_title', array( $this, 'change_widget_title' ), 99, 2 );
            add_filter( 'loftocean_get_widget_class', array( $this, 'change_widget_class' ), 99, 2 );
            add_filter( 'loftocean_get_homepage_widget_class', array( $this, 'homepage_widget_class' ), 99, 2 );
            add_filter( 'loftocean_instagram_widget_class', array( $this, 'instagram_widget_class' ) );
            add_filter( 'loftocean_get_image_sizes', array( $this, 'get_image_sizes' ), 99, 2 );
            add_filter( 'loftocean_get_image_size', array( $this, 'get_image_size' ), 99, 2 );
            add_filter( 'loftocean_front_has_social_menu', array( $this, 'has_social_menu' ), 99, 1 );
            add_filter( 'loftocean_fullscreen_video_wrap_class', array( $this, 'fullscreen_video_wrap_class' ) );
            add_filter( 'loftocean_reading_speed', array( $this, 'reading_speed' ) );
            add_filter( 'loftocean_translate_attachment_options', array( $this, 'translate_attachments' ) );
            add_filter( 'loftocean_translate_mc4wp_forms', array( $this, 'translate_mc4wp_form_settings' ) );
            add_filter( 'loftocean_translate_mc4wp_form',  array( $this, 'translate_mc4wp_form' ) );
			add_filter( 'loftocean_get_primary_color', array( $this, 'get_primary_color' ) );
            add_filter( 'loftocean_is_loading_post_meta_by_ajax', array( $this, 'load_post_metas_by_ajax' ) );
            add_filter( 'loftocean_front_post_list_args', array( $this, 'post_list_args' ), 99 );
            add_filter( 'loftocean_block_name', array( $this, 'editor_block_name' ) );
            add_filter( 'loftocean_get_reading_time', array( $this, 'get_post_reading_time' ), 10, 2 );

            add_filter( 'loftocean_enable_media_lazy_load', '__return_false', 1 );
            add_filter( 'loftocean_disable_media_preload', '__return_true', 1 );

            add_action( 'loftocean_front_the_social_menu', array( $this, 'the_social_menu' ), 10, 1 );
            add_action( 'alpaca_image_loading_attributes', array( $this, 'image_loading_attributes' ) );
        }
		/**
		* Get primary for gutenberg
		*/
		public function get_primary_color( $color ) {
			return alpaca_get_theme_mod( 'alpaca_custom_accent_color' );
		}
        /**
        * Condition function if have social menu
        * @param boolean
        * @return boolean
        */
        public function has_social_menu( $has ) {
            return has_nav_menu( 'social-menu' );
        }
        /**
        * Output the social menu for widget profile
        * @param string
        */
        public function the_social_menu( $id ) {
            alpaca_social_menu( array(
                'container' => 'div',
                'container_class' => 'socialwidget',
                'menu_id' => $id . '-social-menu',
                'menu_class' => 'social-nav menu'
            ) );
        }
        /**
        * Change widget title
        */
        public function change_widget_title( $title, $args ) {
            if ( ! empty( $args ) && ! empty( $args['id' ] ) ) {
                switch ( $args['id'] ) {
                    case 'profile':
                        return esc_html__( 'Alpaca Profile', 'alpaca' );
                    case 'facebook':
                        return esc_html__( 'Alpaca Facebook', 'alpaca' );
                    case 'instagram':
                        return esc_html__( 'Alpaca Instagram', 'alpaca' );
                    case 'social':
                        return esc_html__( 'Alpaca Social', 'alpaca' );
                    case 'banner':
                        return esc_html__( 'Alpaca Ad', 'alpaca' );
                    case 'category':
                        return esc_html__( 'Alpaca Category', 'alpaca' );
                    case 'posts':
                        return esc_html__( 'Alpaca Posts', 'alpaca' );
                }
            }
            return $title;
        }
        /**
        * Change widget class name
        */
        public function change_widget_class( $class, $args ) {
            if ( ! empty( $args ) && ! empty( $args['id' ] ) ) {
                switch ( $args['id'] ) {
                    case 'homepage_widget_banner':
                        return 'alpaca-bannr';
                    case 'profile':
                        return 'alpaca-widget_about';
                    case 'instagram':
                        return 'alpaca-widget_instagram';
                    case 'social':
                        return 'alpaca-widget_social';
                    case 'banner':
                        return 'tinysal-widget_ad';
                    case 'category':
                        return 'alpaca-widget_cat';
                    case 'posts':
                        return 'alpaca-widget_posts';
                }
            }
            return $class;
        }
        /**
        * Get the instagram widget wrapper div classname
        */
        public function instagram_widget_class( $class ) {
            return 'alpaca-widget_instagram';
        }
        /**
        * Homepage widget class name
        */
        public function homepage_widget_class( $class, $args ) {
            if ( ! empty( $args ) && ! empty( $args['id' ] ) ) {
                switch ( $args['id'] ) {
                    case 'featuerd-category':
                        array_push( $class, 'alpaca-widget_cat' );
                        break;
                }
            }
            return $class;
        }
        /**
        * Get image sizes
        */
        public function get_image_sizes( $sizes, $args ) {
            return Alpaca_Utils_Image::get_image_sizes( $args );
        }
        /**
        * Get image size
        */
        public function get_image_size( $size, $args ) {
            return Alpaca_Utils_Image::get_image_size( $args );
        }
        /**
        * Fullscreen video wrap class
        */
        public function fullscreen_video_wrap_class( $class ) {
            return 'alpaca-media-wrapper alpaca-media-fullscreen-playing';
        }
        /**
        * Get reading speed
        */
        public function reading_speed( $speed ) {
            $speed = absint( alpaca_get_theme_mod( 'alpaca_reading_speed_per_minute' ) );
            return empty( $speed ) ? 100 : $speed;
        }
        /**
        * Set the options need to be translated as page id
        */
        public function translate_attachments( $attach ) {
            return array_merge( array(
                'theme_mod_custom_logo',
                'theme_mod_alpaca_site_header_light_desktop_logo',
            	'theme_mod_alpaca_site_header_light_mobile_logo',
            	'theme_mod_alpaca_site_header_dark_desktop_logo',
            	'theme_mod_alpaca_site_header_dark_mobile_logo',
                'theme_mod_alpaca_site_header_image',
                'theme_mod_alpaca_fullscreen_menu_background_image',
                'theme_mod_alpaca_site_footer_signup_form_background_image',
                'theme_mod_alpaca_site_footer_bottom_light_color_scheme_logo',
                'theme_mod_alpaca_site_footer_bottom_dark_color_scheme_logo',
                'theme_mod_alpaca_single_post_signup_form_bg_image',
                'theme_mod_alpaca_404_page_bg_image',
                'theme_mod_alpaca_popup_signup_form_image'
            ), (array) $attach );
        }
        /**
        * Get current form settings
        */
        public function translate_mc4wp_form_settings( $val ) {
            return get_option( 'alpaca_polylang_mc4wp_settings', $val );
        }
        /**
        * Set the mc4wp form theme mod need to be translated
        */
        public function translate_mc4wp_form( $mods ) {
            return array_merge( array(
                'alpaca_site_footer_signup_form_id',
                'alpaca_popup_signup_form_id',
                'alpaca_single_post_signup_form_id'
            ), (array) $mods );
        }
        /**
        * Disable image preload
        */
        public function disable_image_preload( $disable ) {
            return ! alpaca_module_enabled( 'alpaca_general_enable_progressive_image_loading' );
        }
        /**
        * Enable image lazy load
        */
        public function enable_lazy_load( $enable ) {
            return alpaca_module_enabled( 'alpaca_general_enable_lazy_load' );
        }
        /**
        * If show post metas dyanmically by AJAX
        */
        public function load_post_metas_by_ajax( $enable ) {
            return alpaca_module_enabled( 'alpaca_load_post_metas_dynamically' );
        }
        /**
        * Post List args
        */
        public function post_list_args( $args ) {
            $params = array( 'layout' => 'layout-', 'columns' => 'column-' );
            foreach ( $params as $param => $rid ) {
                if ( isset( $args[ $param ] ) ) {
                    $args[ $param ] = str_replace( $rid, '', $args[ $param ] );
                }
            }

            return $args;
        }
        /**
        * Alter editor block name
        */
        public function editor_block_name( $names = array() ) {
            if ( is_array( $names ) ) {
                $names['postsBlock'] = esc_html__( 'Alpaca Blog Posts', 'alpaca' );
            } else {
                $names = array( 'postsBlock' => esc_html__( 'Alpaca Blog Posts', 'alpaca' ) );
            }
            return $names;
        }
        /**
        * Image loading attributes action callback function
        */
        public function image_loading_attributes() {
            add_filter( 'loftocean_disable_media_preload', array( $this, 'disable_image_preload' ), 10 );
            add_filter( 'loftocean_enable_media_lazy_load', array( $this, 'enable_lazy_load' ), 10 );
        }
        /**
        * Get reading time
        */
        public function get_post_reading_time( $html, $pid ) {
            ob_start();
            alpaca_the_post_reading_time( $pid );
            return ob_get_clean();
        }
    }
    new Alpaca_Extension_Filters();
}
