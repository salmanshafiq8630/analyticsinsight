<?php

if ( ! class_exists( 'Alpaca_Customize_Configuration_Base' ) ) {
	/**
	* Theme customize configuration base class
	*	Each config class will extend this class
	*		1. Action to register customize setting, panel, section and control
	*		2. Filter to add javascript variables for cutomize.php
	*
	* @author Loft.Ocean
	* @since 1.0.0
	*/
	class Alpaca_Customize_Configuration_Base {
		/**
		* Construct function to hook required actions/filters
		*/
		public function __construct() {
			add_action( 'customize_register', array( $this, 'register_controls' ) );
		}
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) { }
		/**
		* Customize control active callback function to test whether display current control.
		*    Dependency settings could be more than one, treat as logical AND.
		*    Each dependency setting value is array, so testing will be based on in/not in.
		* @param object WP_Csutomize_Control to test on
		* @return boolean if depenency test not enable return true, otherwise test if current value is in the list given.
		*/
		public function customize_control_active_cb( $control ) {
			if ( $control instanceof WP_Customize_Control ) {
				$manager  = $control->manager;
				$settings = $control->settings;
				$setting =  false;
				if ( $control instanceof WP_Customize_Background_Position_Control ) {
					$setting = $settings['x'];
				} else if ( ! empty( $settings['default'] ) ) {
					$setting = $settings['default'];
				}

				if ( $setting instanceof Alpaca_Customize_Setting ) {
					$dependency = $setting->dependency;
					if ( ! empty( $dependency ) ) {
						return $this->check_dependency( $dependency, $manager );
					}
					return true;
				}
			}
			return false;
		}
		/**
		* Helper function to determine whether show customize control
		*/
		protected function check_dependency( $deps, $wp_customize ) {
			if ( is_array( $deps ) ) {
				if ( isset( $deps['query'] ) && ( count( $deps['query'] ) > 0 ) ) {
					$isRelationAnd = $deps['relation'] && ( 'or' === strtolower( $deps['relation'] ) ) ? false : true;
					$result = false;
					foreach ( $deps['query'] as $list ) {
						$result = $this->check_dependency( $list, $wp_customize );
						if ( $isRelationAnd && ( ! $result ) ) {
							return false;
						} else if ( ( ! $isRelationAnd ) && $result ) {
							return false;
						}
					}
					return true;
				} else {
					foreach ( $deps as $id => $attrs ) {
						if ( empty( $attrs['value'] ) ) { // If not provide the test value list, return false
							return false;
						}
						if ( $wp_customize->get_setting( $id ) instanceof WP_Customize_Setting ) {
							// Test operator, potential value: in/not in. The default is in.
							$not = ! empty( $attrs['operator'] ) && ( strtolower($attrs['operator'] ) == 'not in' );
							$value = $wp_customize->get_setting( $id )->value();
							$values = $attrs['value'];
							if ( ( $not && in_array( $value, $values ) ) || ( ! $not && ! in_array( $value, $values ) ) ) {
								return false;
							}
						}
					}
				}
			}
			return true;
		}
		/**
		* Settings for list pages
		* @param object wp customizer manager
		* @param string list page
		* @param string section id
		*/
		protected function register_list_settings( $wp_customize, $page, $section_id ) {
			global $alpaca_default_settings;

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_layout', array(
				'default'			=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_layout'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency' 		=> array(
					'alpaca_archive_page_' . $page . '_post_layout' => array( 'value' => array( 'layout-masonry_column-2_first-side-overlay', 'layout-zigzag__first-side-overlay' ), 'operator' => 'not in' )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_post_layout', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_post_layout'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_image_ratio', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_image_ratio'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_archive_page_' . $page . '_post_layout' => array( 'value' => array(
						'layout-grid_column-2_',
						'layout-grid_column-3_',
						'layout-grid_column-2_first-full-overlay',
						'layout-grid_column-3_first-full-overlay',
						'layout-grid-overlay_column-2_',
						'layout-grid-overlay_column-3_',
						'layout-grid-overlay_column-4_',
						'layout-list__'
					) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_grid_style', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_grid_style'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_archive_page_' . $page . '_post_layout' => array( 'value' => array(
						'layout-grid_column-2_',
						'layout-grid_column-3_',
						'layout-grid_column-2_first-full-overlay',
						'layout-grid_column-3_first-full-overlay'
					) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_grid_overlay_opacity', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_grid_overlay_opacity'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_archive_page_' . $page . '_post_layout' => array( 'value' => array(
						'layout-grid-overlay_column-2_',
						'layout-grid-overlay_column-3_',
						'layout-grid-overlay_column-4_'
					) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_grid_overlay_large_title', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_grid_overlay_large_title'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
				'dependency'		=> array(
					'alpaca_archive_page_' . $page . '_post_layout' => array( 'value' => array(
						'layout-grid-overlay_column-2_',
						'layout-grid-overlay_column-3_',
						'layout-grid-overlay_column-4_'
					) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_post_meta_group', array(
				'default'   		=> '',
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_' . $page . '_posts_per_page', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_' . $page . '_posts_per_page'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_layout', array(
				'type' 				=> 'radio',
				'label' 			=> esc_html__( 'Sidebar Layout', 'alpaca' ),
				'section' 			=> $section_id,
				'settings' 			=> 'alpaca_archive_page_' . $page . '_layout',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'choices' 			=> array(
					'' 						=> esc_html__( 'No Sidebar', 'alpaca' ),
					'with-sidebar-left' 	=> esc_html__( 'Left Sidebar', 'alpaca' ),
					'with-sidebar-right' 	=> esc_html__( 'Right Sidebar', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_post_layout', array(
				'type'		=> 'select',
				'label'		=> esc_html__( 'Posts Layout', 'alpaca' ),
				'settings'	=> 'alpaca_archive_page_' . $page . '_post_layout',
				'section'	=> $section_id,
				'choices'	=> array(
					'layout-standard__' => esc_html__( 'Standard', 'alpaca' ),
					'layout-full-overlay__' => esc_html__( 'Full Overlay', 'alpaca' ),
					'layout-zigzag__' => esc_html__( 'Zigzag', 'alpaca' ),
					'layout-list__' => esc_html__( 'List', 'alpaca' ),
					'layout-masonry_column-2_'	=> esc_html__( 'Masonry 2 Columns', 'alpaca' ),
					'layout-masonry_column-3_'	=> esc_html__( 'Masonry 3 Columns', 'alpaca' ),
					'layout-grid_column-2_' => esc_html__( 'Grid 2 Columns', 'alpaca' ),
					'layout-grid_column-3_' => esc_html__( 'Grid 3 Columns', 'alpaca' ),
					'layout-masonry_column-2_first-side-overlay' => esc_html__( 'First Side Overlay + Masonry 2 Columns', 'alpaca' ),
					'layout-zigzag__first-side-overlay' => esc_html__( 'First Side Overlay + Zigzag', 'alpaca' ),
					'layout-grid-overlay_column-2_' => esc_html__( 'Grid Overlay 2 Columns', 'alpaca' ),
					'layout-grid-overlay_column-3_' => esc_html__( 'Grid Overlay 3 Columns', 'alpaca' ),
					'layout-grid-overlay_column-4_' => esc_html__( 'Grid Overlay 4 Columns', 'alpaca' ),
					'layout-masonry_column-2_first-full-overlay' => esc_html__( 'First Full Overlay + Masonry 2 Columns', 'alpaca' ),
					'layout-masonry_column-3_first-full-overlay' => esc_html__( 'First Full Overlay + Masonry 3 Columns', 'alpaca' ),
					'layout-grid_column-2_first-full-overlay' => esc_html__( 'First Full Overlay + Grid 2 Columns', 'alpaca' ),
					'layout-grid_column-3_first-full-overlay' => esc_html__( 'First Full Overlay + Grid 3 Columns', 'alpaca' ),
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_image_ratio', array(
				'type'				=> 'select',
				'label'				=> esc_html__( 'Image Ratio', 'alpaca' ),
				'settings'			=> 'alpaca_archive_page_' . $page . '_image_ratio',
				'section'			=> $section_id,
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'choices'			=> array(
					'img-ratio-3-2' => esc_html__( '3:2', 'alpaca' ),
					'img-ratio-1-1' => esc_html__( '1:1', 'alpaca' ),
					'img-ratio-2-3' => esc_html__( '2:3', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_grid_style', array(
				'type'				=> 'select',
				'label'				=> esc_html__( 'Grid Style', 'alpaca' ),
				'settings'			=> 'alpaca_archive_page_' . $page . '_grid_style',
				'section'			=> $section_id,
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'choices'			=> array(
					'grid-style-1' => esc_html__( 'Style 1', 'alpaca' ),
					'grid-style-2' => esc_html__( 'Style 2', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_grid_overlay_opacity', array(
				'type'				=> 'select',
				'label'				=> esc_html__( 'Overlay Opacity', 'alpaca' ),
				'settings'			=> 'alpaca_archive_page_' . $page . '_grid_overlay_opacity',
				'section'			=> $section_id,
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'choices'			=> array(
					'no-overlay' => esc_html__( 'No Overlay', 'alpaca' ),
					'slight-overlay' => esc_html__( 'Slight Overlay', 'alpaca' ),
					'' => esc_html__( 'Normal Overlay', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_grid_overlay_large_title', array(
				'type'				=> 'checkbox',
				'label_first' 		=> true,
				'label'				=> esc_html__( 'Large Title', 'alpaca' ),
				'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
				'section'			=> $section_id,
				'settings'			=> 'alpaca_archive_page_' . $page . '_grid_overlay_large_title'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_post_meta_group', array(
				'type' 		=> 'multiple_checkbox',
				'label' 	=> esc_html__( 'Meta Visibility', 'alpaca' ),
				'section' 	=> $section_id,
				'settings' 	=> 'alpaca_archive_page_' . $page . '_post_meta_group',
				'choices' 	=> $this->register_post_meta_settings( $wp_customize, $page )
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_' . $page . '_posts_per_page', array(
				'type' 			=> 'number',
				'label' 		=> esc_html__( 'Number of Posts Displayed Per Page', 'alpaca' ),
				'input_attrs' 	=> array( 'min' => 1 ),
				'section' 		=> $section_id,
				'settings' 		=> 'alpaca_archive_page_' . $page . '_posts_per_page'
			) ) );
		}
		/**
		* Register post meta settings
		* @param object
		* @param string page
		* @return array
		*/
		protected function register_post_meta_settings( $wp_customize, $page ) {
			global $alpaca_default_settings;
			$list = array();
			$metas = array(
				'category' 			=> esc_html__( 'Category', 'alpaca' ),
				'author'			=> esc_html__( 'Author', 'alpaca' ),
				'date'				=> esc_html__( 'Publish Date', 'alpaca' ),
				'update_date'		=> esc_html__( 'Update Date', 'alpaca' ),
				'reading_time'		=> esc_html__( 'Reading Time', 'alpaca' ),
				'excerpt'			=> esc_html__( 'Excerpt', 'alpaca' ),
				'read_more_button'	=> esc_html__( 'Read More Button', 'alpaca' ),
			);
			foreach ( $metas as $mid => $title ) {
				$meta_id = 'alpaca_archive_page_' . $page . '_show_' . $mid;
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, $meta_id, array(
					'default'   		=> $alpaca_default_settings[ $meta_id ],
					'transport'			=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
				) ) );

				$list[ $mid ] = array( 'value' => 'on', 'label' => $title, 'setting' => $meta_id );
			}
			return $list;
		}
	}
}
