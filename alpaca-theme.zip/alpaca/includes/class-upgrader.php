<?php
/**
* Theme upgrader class
*	To update the settings for update between versions
*/
if ( ! class_exists( 'Alpaca_Upgrader' ) ) {
	class Alpaca_Upgrader {
		/**
		* Object current class instance to make sure only once instance in running
		*/
		public static $instance = false;
		/**
		* String current theme version
		*/
		private $version = '';
		/**
		* If the previous verion if older than current version,
		*	do the upgrade and update theme version
		*/
		public function __construct() {
			$this->version = ALPACA_THEME_VERSION;

			$old_version = get_theme_mod( 'theme-version', '0.1' );
			if ( version_compare( $old_version, $this->version, '<' ) ) {
				if ( version_compare( $old_version, '1.0.0', '<' ) ) {
					$this->initial_settings();
				}
				if ( version_compare( $old_version, '1.3.0', '<' ) ) {
					$this->update_reading_spped();
				}
				$this->update_version();
			}
			$this->auto_update_extension();
		}
		/**
		* Initial settings
		*/
		protected function initial_settings() { }
		/**
		* Reading speed update
		*/
		protected function update_reading_spped() {
			$reading_speed = get_theme_mod( 'alpaca_read_words_per_minute' );
			if ( ! empty( $reading_speed ) ) {
				set_theme_mod( 'alpaca_reading_speed_per_minute', $reading_speed );
			}
		}
		/**
		* Update version number to db
		*/
		protected function update_version(){
			set_theme_mod( 'theme-version', $this->version );
		}
		/**
		* Check extension version
		*/
		protected function auto_update_extension() {
			if ( $this->check_auto_update_extension_permission() ) {
				set_theme_mod( 'last-time-try-extension-update', time() );
				$update_url = add_query_arg(
					array(
						'page' => 'tgmpa-install-plugins',
						'plugin' => urlencode( 'alpaca-extension' ),
						'tgmpa-update' => 'update-plugin',
						'tgmpa-nonce' => wp_create_nonce( 'tgmpa-update' )
					),
					admin_url( 'themes.php' )
				);
				wp_safe_redirect( $update_url );
			}
		}
		/**
		* Conditional function if current user has the right persimission to auto update extension
		*/
		protected function check_auto_update_extension_permission() {
			if ( 'on' == get_option( 'alpaca_auto_update_required_plugin' ) ) {
				$is_admin = is_admin() && ! wp_doing_ajax() && current_user_can( 'update_plugins' );
				// Disabled on tgmpa plugin page
				$valid_location = empty( $_GET[ 'page'] ) || ( $_GET[ 'page'] != 'tgmpa-install-plugins' );
				// Check the time of last try
				$last_try = get_theme_mod( 'last-time-try-extension-update' );
				$valid_retry = empty( $last_try ) || ( time() > ( $last_try + ( 24 * 3600 ) ) );
				// Check if extension exists
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
				}
				$all_plugins = get_plugins();
				$extension = 'alpaca-extension/alpaca-extension.php';
				$has_low_extension = ! empty( $all_plugins[ $extension ] ) && version_compare( $all_plugins[ $extension ]['Version'], ALPACA_EXTENSION_VERSION, '<' );

				return $has_low_extension && $is_admin && $valid_location && $valid_retry;
			}
			return false;
		}
		/**
		* Instance Loader class
		*	there can only be one instance of loader
		* @return class Loader
		*/
		public static function _instance() {
			if ( false === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
	}
	Alpaca_Upgrader::_instance();
}
