<?php
if ( ! class_exists( 'Alpaca_Gutenberg' ) ) {
    class Alpaca_Gutenberg {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'loftocean_get_post_gutenberg_metas', array( $this, 'post_metas' ) );
            add_filter( 'loftocean_get_page_gutenberg_metas', array( $this, 'page_metas' ) );
			add_filter( 'loftocean_hide_page_settings', array( $this, 'hide_page_metabox' ), 10, 2 );
        }
		/**
		* Add post meta to gutenberg for post
		*/
		public function post_metas( $metas ) {
			return array_merge( $metas, array(
                'alpaca_post_content_reading_setting' => 'string',
                'alpaca_reading_speed_per_minute' => 'number',
                'alpaca_reading_speed_unit' => 'string',
                'alpaca_single_post_template_layout' => 'string'
			) );
		}
		/**
		* Add page meta to gutenberg for post
		*/
		public function page_metas( $metas ) {
			return array_merge( $metas, array(
                'alpaca_page_layout' => 'string',
				'alpaca_hide_before_page_content_ad' => 'string',
				'alpaca_hide_after_page_content_ad' => 'string',
                'alpaca_hide_page_header' => 'string',
                'alpaca_page_sub_title' => 'string',
                'alpaca_advanced_classname' => 'string'
			) );
		}
		/**
		* Condition function whether to show page metabox
		* @param boolean
		* @return boolean
		*/
		public function hide_page_metabox( $show, $p = false ) {
			if ( empty( $p ) ) {
				global $post;
				$p = $post;
			}
			if ( $p && in_array( $p->post_type, array( 'page' ) ) ) {
				$pid = $p->ID;
				$pages = array();
				$front_page_id 	= get_option( 'page_on_front' );

				if ( 'page' == get_option( 'show_on_front', 'posts' ) ) {
					array_push( $pages, get_option( 'page_for_posts' ) );

    				if ( alpaca_is_item_exists( $front_page_id ) && ( 'builder' == get_option( 'loftocean_homepage_content', 'page' ) ) ) {
    					array_push( $pages, $front_page_id );
    				}
                }
				$pages = apply_filters( 'alpaca_static_pages', $pages );

				return in_array( $pid, $pages );
			}
			return false;
		}
    }
    new Alpaca_Gutenberg();
}
