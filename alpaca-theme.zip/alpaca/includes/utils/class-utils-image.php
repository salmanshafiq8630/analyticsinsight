<?php
if ( ! class_exists( 'Alpaca_Utils_Image' ) ) {
	class Alpaca_Utils_Image {
		/**
		* Boolean if is mobile device
		*/
		public static $is_mobile = false;
		/**
		* String default image size, for image tag or static source requested
		*/
		public static $default_size = 'full';
		/**
		* Array default image sizes
		*	1. First element for normal device
		* 	2. Second element for retina device
		*/
		public static $default_sizes = array( 'full', 'full' );
		/**
		* Construct function
		*/
		public static function init() {
			add_filter( 'loftocean_modify_image_attributes', 'Alpaca_Utils_Image::change_image_attrs', 10, 2 );
			add_filter( 'loftocean_placeholder_size', 'Alpaca_Utils_Image::placeholder_size' );
			add_filter( 'loftocean_lazy_load_image_size', 'Alpaca_Utils_Image::lazy_load_image_size' );
			add_action( 'init', 'Alpaca_Utils_Image::set_settings' );
		}
		/**
		* Setup settings
		*/
		public static function set_settings() {
			self::$is_mobile = apply_filters( 'loftocean_is_mobile', false );
		}
		/**
		* Placeholder image size
		*/
		public static function placeholder_size( $size ) {
			return 'alpaca_255w';
		}
		/**
		* Lazy load image size
		*/
		public static function lazy_load_image_size( $size ) {
			return '255px';
		}
		/**
		* Calculate image size for each situation
		* @param array
		*	1. String: module
		*	2. String: sub_module
		* @return array image size for normal and retina screen [ normal screen, retina screen ]
		*/
		protected static function get_image_sizes_array( $args ) {
			if ( alpaca_module_enabled( 'alpaca_general_enable_full_image_size' ) ) {
				return alpaca_module_enabled( 'alpaca_general_enable_lazy_load' ) || alpaca_module_enabled( 'alpaca_general_enable_progressive_image_loading' )
					? self::$default_sizes : array( self::$default_size );
			}

			if ( ! empty( $args['module'] ) ) {
				$sub_module = empty( $args['sub_module'] ) ? false : $args['sub_module'];

				if ( self::$is_mobile ) {
					switch ( $args['module'] ) {
						case 'instagram':
							return array( 'alpaca_600w_600h' );
						case 'archive':
							$post_list_args = array( 'layout' => 'standard', 'columns' => '' );
							if ( ! empty( $args['args'] ) && is_array( $args['args'] ) ) {
								$post_list_args = array_merge( $post_list_args, $args['args'] );
							}
							$post_layout = $post_list_args['layout'] . $post_list_args['columns'];
							if ( in_array( $post_layout, array( 'masonry2', 'masonry3', 'grid2', 'grid3', 'standard' ) ) ) {
								return array( 'alpaca_550w' );
							}
							break;
						case 'widget':
							switch ( $sub_module ) {
								case 'home-category-background':
									return array( 'alpaca_600w' );
								case 'home-cta-image':
								case 'profile-image':
								case 'category-banner':
									return array( 'alpaca_370w' );
								case 'category-background':
									return array( 'alpaca_600w' );
							}
							break;
						case 'site':
							if ( 'popup-background' == $sub_module ) {
								return array( 'alpaca_1920w' );
							}
							break;
						case 'block':
							switch( $sub_module ) {
								case 'inline-post':
									return array( 'alpaca_550w' );
							}
							break;
					}
					return array( 'alpaca_1200w' );
				}

				switch ( $args['module'] ) {
					case 'instagram':
						$instagram_args = array( 'location' => 'footer', 'column' => 6 );
						if ( ! empty( $args['args'] ) && is_array( $args['args'] ) ) {
							$instagram_args = array_merge( $instagram_args, $args['args'] );
						}
						switch( $instagram_args['location'] ) {
							case 'footer':
								switch( $instagram_args['column'] ) {
									case '8':
										return array( 'alpaca_255w', 'alpaca_550w' );
									case '7':
										return array( 'alpaca_370w', 'alpaca_550w' );
									case '6':
										return array( 'alpaca_370w', 'alpaca_780w' );
									case '5':
										return array( 'alpaca_550w', 'alpaca_780w' );
									default:
										return array( 'alpaca_550w', 'alpaca_1200w' );
								}
							default:
								return array( 'alpaca_255w', 'alpaca_255w' );
						}
					case 'menu':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'mega-menu-1':
									return array( 'alpaca_1920w', 'alpaca_1920w' );
								case 'mega-menu-2':
									return array( 'alpaca_1200w', 'alpaca_1920w' );
								case 'mega-menu-3':
									return array( 'alpaca_780w', 'alpaca_1440w' );
								default:
								 	return array( 'alpaca_550w', 'alpaca_1200w' );
							}
						}
						break;
					case 'widget':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'home-widget-background':
									return array( 'alpaca_1920w', 'alpaca_1920w' );
								case 'home-promo-block-background':
									return array( 'alpaca_600w', 'alpaca_1200w' );
								case 'home-cta-image':
									return array( 'alpaca_780w', 'alpaca_1440w' );
								case 'home-category-background':
								case 'category-background':
								case 'category-banner':
									return array( 'alpaca_370w', 'alpaca_600w' );
								case 'profile-image':
								 	return array( 'medium', 'alpaca_600w' );
								case 'list-thumbnail':
									return array( 'thumbnail', 'thumbnail' );
								case 'list-background':
									return array( 'alpaca_600w', 'alpaca_600w' );
							}
						}
						break;
					case 'singular':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'pagination': // Have both previous and next links
									return array( 'alpaca_780w', 'alpaca_1200w' );
								case 'single-pagination': // Only have previous or next link
									return array( 'alpaca_1920w', 'alpaca_1920w' );
								case 'content': // Images inside post content
								 	return array( 'alpaca_1920w', 'alpaca_1920w' );
								case 'gallery': // Gallery inside post content
									return array( 'alpaca_1200w', 'alpaca_1440w' );
								case 'related-posts': // Related posts after post main content
								 	return array( 'alpaca_600w', 'alpaca_600w' );
								case 'popup-slider': // Popup sliders
									return array( 'alpaca_1920w', 'alpaca_1920w' );
								case 'signup-form': // Signup form background image after post main content
									return array( 'alpaca_1920w', 'alpaca_1920w' );
							}
						}
						break;
					case 'archive':
						$post_list_args = array( 'layout' => 'standard', 'columns' => '', 'first_style' => '', 'page_layout' => '', 'grid_style' => 'grid-style-1', 'grid_image_ratio' => 'img-ratio-3-2' );
						if ( ! empty( $args['args'] ) && is_array( $args['args'] ) ) {
							$post_list_args = array_merge( $post_list_args, $args['args'] );
						}
						$is_fullwidth = empty( $post_list_args['page_layout'] );
						$is_first_side = ( 'first-side-overlay' == $post_list_args['first_style'] );
						$post_layout = $post_list_args['layout'] . $post_list_args['columns'];

						switch ( $post_layout ) {
							case 'standard':
								return $is_fullwidth ? array( 'alpaca_1200w', 'alpaca_1920w' ) : array( 'alpaca_780w', 'alpaca_1440w' );
							case 'full-overlay':
							case 'first-full-overlay':
								return $is_fullwidth ? array( 'alpaca_1920w', 'alpaca_1920w' ) : array( 'alpaca_1200w', 'alpaca_1920w' );
							case 'first-side-overlay':
								return array( 'alpaca_1440w', 'alpaca_1920w' );
							case 'zigzag':
								return $is_first_side ? array( 'alpaca_550w', 'alpaca_1200w' ) : array( 'alpaca_780w', 'alpaca_1440w' );
							case 'list':
								return array( 'alpaca_780w', 'alpaca_1440w' );
							case 'masonry2':
								return $is_first_side ? array( 'alpaca_550w', 'alpaca_780w' ) : ( $is_fullwidth ? array( 'alpaca_1200w', 'alpaca_1920w' ) : array( 'alpaca_780w', 'alpaca_1440w' ) );
							case 'masonry3':
								return $is_fullwidth ? array( 'alpaca_780w', 'alpaca_1440w' ) : array( 'alpaca_550w', 'alpaca_1200w' );
							case 'grid2':
								$is_grid_style1 = ( 'grid-style-1' == $post_list_args['grid_style'] );
								if ( $is_fullwidth ) {
									return $is_grid_style1 ? array( 'alpaca_1200w', 'alpaca_1920w' ) : array( 'alpaca_780w', 'alpaca_1440w' );
								} else {
									return array( 'alpaca_550w', 'alpaca_1200w' );
								}
							case 'grid3':
								$is_grid_style1 = ( 'grid-style-1' == $post_list_args['grid_style'] );
								if ( $is_fullwidth ) {
									return $is_grid_style1 ? array( 'alpaca_780px', 'alpaca_1200w' ) : array( 'alpaca_550w', 'alpaca_780w' );
								} else {
									return array( 'alpaca_480w', 'alpaca_1200w' );
								}
							case 'grid-overlay2':
							case 'grid-overlay3':
								$is_grid_image_ratio32 = ( 'img-ratio-3-2' == $post_list_args['grid_image_ratio'] );
								if ( $is_fullwidth ) {
									return $is_grid_image_ratio32 ? array( 'alpaca_1200w', 'alpaca_1920w' ) : array( 'alpaca_1920w', 'alpaca_1920w' );
								} else {
									return $is_grid_image_ratio32 ? array( 'alpaca_550w', 'alpaca_1200w' ) : array( 'alpaca_780w', 'alpaca_1440w' );
								}
							case 'grid-overlay4':
								return $is_fullwidth ? array( 'alpaca_550w', 'alpaca_1200w' ) : array( 'alpaca_370w', 'alpaca_780w' );
							case 'carousel1':
							case 'widget_slider':
								return array( 'alpaca_1920w', 'alpaca_1920w' );
							case 'carousel2':
							case 'carousel3':
							case 'carousel4':
								return array( 'alpaca_1440w', 'alpaca_1920w' );
						}
						break;
					case 'site':
						if ( $sub_module ) {
							switch ( $sub_module ) {
								case 'popup-form-background':
									return array( 'alpaca_370w', 'alpaca_780w' );
								case 'fullscreen-menu-background-with-widgets':
								case 'fullscreen-menu-background':
									return array( 'alpaca_1440w', 'alpaca_1920w' );
								case 'page-header':
								case '404-background':
								case 'footer-background-image':
									return array( 'alpaca_1920w', 'alpaca_1920w' );
								case 'split-page-header':
									return array( 'alpaca_1440w', 'alpaca_1920w' );
							}
						}
						break;
					case 'block':
						switch( $sub_module ) {
							case 'inline-post':
								return array( 'alpaca_255w', 'alpaca_370w' );
						}
						break;
				}
			}
			return self::$default_sizes;
		}
		/**
		* Get image sizes for given situation
		* @param array
		* @return array
		*/
		public static function get_image_sizes( $args ) {
			$sizes = self::get_image_sizes_array( $args );
			return apply_filters( 'alpaca_image_sizes', $sizes, $args );
		}
		/**
		* Get image size for given situation
		* @param array
		* @return string
		*/
		public static function get_image_size( $args ) {
			$sizes = self::get_image_sizes( $args );
			return isset( $sizes[0] ) ? $sizes[0] : self::$default_size;
		}
		/**
		* Change image attribute
		*/
		public static function change_image_attrs( $attr, $original_attrs ) {
			$attribute_sizes = Alpaca_Utils_Image::get_attribute_sizes();
			$layout = alpaca_get_post_list_prop( 'layout' );
			$col = alpaca_get_post_list_prop( 'columns' );
			$newAttr = array();
			if ( ! empty( $attribute_sizes ) ) {
				$newAttr = array( 'sizes' => $attribute_sizes );
			}
			if ( ! empty( $layout ) && ! empty( $col ) ) {
				if ( empty( $original_attrs['class'] ) ) {
					$newAttr['class'] = ' image-layout-' . $layout . '-column-' . $col;
				} else {
					$newAttr['class'] = $original_attrs['class'] . ' image-layout-' . $layout . '-column-' . $col;
				}
			}
			if ( 0 === count( $newAttr ) ) {
				return $attr;
			} else if ( empty( $attr ) ) {
				return $newAttr;
			} else {
				return array_merge( (array)$attr, $newAttr );
			}
		}
		/**
		* Get image sizes
		*/
		public static function get_attribute_sizes() {
			$layout = alpaca_get_post_list_prop( 'layout' );
			if ( ( ! alpaca_module_enabled( 'alpaca_general_enable_full_image_size' ) ) && ( ! empty( $layout ) ) ) {
				$page_layout = alpaca_get_post_list_prop( 'page_layout' );
				$fullwidth = empty( $page_layout );

				switch( $layout ) {
					case 'masonry':
					case 'grid':
						if ( self::$is_mobile ) {
							return '420px';
						} else {
							$column = alpaca_get_post_list_prop( 'columns' );
							if ( 3 == $column ) {
								return $fullwidth ? '(max-width: 1366px) 460px, 680px' : '(max-width: 1366px) 350px, 480px';
							} else {
								return $fullwidth ? '(max-width: 1366px) 685px, 960px' : '(max-width: 1366px) 460px, 640px';
							}
						}
						break;
					case 'standard':
						if ( self::$is_mobile ) {
							return '420px';
						} else {
							return $fullwidth ? '(max-width: 1366px) 1140px, 1380px' : '(max-width: 1366px) 780px, 1020px';
						}
						break;
				}
			}
			return false;
		}
	}
	Alpaca_Utils_Image::init();
}
