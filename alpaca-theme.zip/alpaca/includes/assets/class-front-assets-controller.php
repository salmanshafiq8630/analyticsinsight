<?php
/**
* Theme front end assets manager class
*/

if ( ! class_exists( 'Alpaca_Front_Assets_Controller' ) ) {
	class Alpaca_Front_Assets_Controller {
		/**
		* String main style.css id
		*/
		public $main_style_id = '';
		/**
		* String custom styles from customizer
		*/
		protected $custom_styles = false;
		/**
		* Construct function
		*/
		public function __construct() {
			$this->load_files();
			$this->main_style_id = 'alpaca-theme-style';

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 1 );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_custom_styles' ), 1000 );
			add_action( 'wp_footer', array( $this, 'enqueue_scripts' ) );

			add_filter( 'alpaca_front_json', array( $this, 'frontend_json' ) );
		}
		/**
		* Import required files
		*/
		protected function load_files() {
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-ajax.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-general.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-site-header.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-fullscreen-menu.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-footer.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-typography.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
		/**
		* Generate the css variable related custom style
		*/
		public function generate_custom_style_variables() {
			$vars = array_filter( apply_filters( 'alpaca_custom_style_vars', array() ) );
			if ( alpaca_is_valid_array( $vars ) ) {
				$items = array();
				foreach ( $vars as $var => $val ) {
					if ( ! empty( $var ) && ! empty( $val ) ) {
						$items[] = sprintf( '%s: %s;', $var, $val );
					}
				}
				return sprintf( ':root { %s } ', implode( ' ', $items ) );
			}
			return '';
		}
		/**
		* Generate custom styles based on each customize sections
		*/
		protected function generate_custom_styles() {
			$styles = apply_filters( 'alpaca_custom_styles', array() );
			if ( alpaca_is_valid_array( $styles ) ) {
				$styles = array_filter( $styles );
				return implode( ' ', $styles );
			} else {
				return '';
			}
		}
		/**
		* Generate custom styles to be imported by frontend
		*/
		protected function custom_styles() {
			if ( false === $this->custom_styles ) {
				$vars = $this->generate_custom_style_variables();
				$styles = $this->generate_custom_styles();
				$custom_styles = $vars . $styles;
				$this->custom_styles = trim( $custom_styles );
			}
			return $this->custom_styles;
		}
		/**
		* Add objects to frontend json
		* @param array
		* @return array
		*/
		public function frontend_json( $json = array() ) {
			$json['errorText'] = array( 'noMediaFound'	=> esc_js( esc_html__( 'No image found', 'alpaca' ) ) );
			$json['colorSchemeSwitcherSessionName'] = apply_filters( 'alpaca_color_scheme_switcher_session_name', 'alpacaReverseColorScheme' );
			return $json;
		}
		/**
		* Enqueue styles generated from customization
		*/
		public function enqueue_custom_styles() {
			$custom_styles = $this->custom_styles();
			if ( ! empty( $custom_styles ) ) {
 				wp_add_inline_style( apply_filters( 'alpaca_front_inline_styles_handler', $this->main_style_id ), $custom_styles );
			}
		}
		/**
		* Enqueue assets in head
		*/
		public function enqueue_assets() {
			$asset_uri = ALPACA_ASSETS_URI;
			$asset_version = ALPACA_ASSETS_VERSION;
			$theme_js_deps = array( 'jquery', 'alpaca-helper', 'slick' );
			$asset_suffix = alpaca_get_assets_suffix();

			$theme_style_deps = alpaca_is_gutenberg_enabled() ? array( 'wp-block-library' ) : array();
			$theme_style_deps = apply_filters( 'alpaca_front_get_main_theme_style_dependency', $theme_style_deps );
			do_action( 'alpaca_enqueue_google_fonts' ); // Load google fonts
			wp_enqueue_style( 'slick', $asset_uri . 'libs/slick/slick.min.css', array(), '1.8.1' );
			wp_enqueue_style( 'font-awesome-all', $asset_uri . 'fonts/font-awesome/css/all.min.css' );
			wp_enqueue_style( 'elegant-font', $asset_uri . 'fonts/elegant-font/font.min.css' );
			wp_enqueue_style( $this->main_style_id, $asset_uri . 'styles/front/main' . $asset_suffix . '.css', $theme_style_deps, $asset_version );
			is_rtl() ? wp_enqueue_style( 'alpaca-rtl', $asset_uri . 'styles/front/rtl' . $asset_suffix . '.css', array( $this->main_style_id ), $asset_version ) : '';

			wp_enqueue_script( 'modernizr', $asset_uri . 'scripts/libs/modernizr.min.js', array(), '3.3.1' );
			wp_enqueue_script( 'html5shiv', $asset_uri . 'scripts/libs/html5shiv.min.js', array(), '3.7.3' );
			wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9');
		}
		/**
		* Enqueue javascripts in footer
		*/
		public function enqueue_scripts() {
			$asset_uri = ALPACA_ASSETS_URI;
			$asset_version = ALPACA_ASSETS_VERSION;
			$theme_js_deps = array( 'jquery', 'alpaca-helper', 'slick', 'alpaca-animations' );
			$asset_suffix = alpaca_get_assets_suffix();

			if ( alpaca_is_extension_activated() ) {
				array_push( $theme_js_deps, 'loftocean-video-player' );
			}

			if ( alpaca_is_popup_signup_form_enabled() && ! is_customize_preview() ) {
				wp_enqueue_script( 'alpaca-popup-form', $asset_uri . 'scripts/front/popup-form' . $asset_suffix . '.js', array( 'jquery' ), $asset_version, true );
				wp_localize_script( 'alpaca-popup-form', 'alpacaPopupForm', array(
					'autoDisplay' => alpaca_module_enabled( 'alpaca_popup_signup_form_auto_display' ),
					'oncePerSession' => alpaca_module_enabled( 'alpaca_popup_signup_form_auto_display_once_per_session' ),
					'timer' => esc_js( alpaca_get_theme_mod( 'alpaca_popup_signup_form_display_delay' ) ),
					'ajaxURL' => admin_url( 'admin-ajax.php' ),
					'action' => 'alpaca-popup-form'
				) );
			}

			wp_enqueue_script( 'slick', $asset_uri . 'libs/slick/slick.min.js', array( 'jquery' ), '1.8.1', true );

			if ( alpaca_module_enabled( 'alpaca_sidebar_enable_sticky' ) ) {
				array_push( $theme_js_deps, 'alpaca-sticky-sidebar' );
				wp_enqueue_script( 'alpaca-sticky-sidebar', $asset_uri . 'scripts/front/sticky-sidebar' . $asset_suffix . '.js', array( 'alpaca-helper' ), $asset_version, true );
			}

			if ( is_singular() ) {
				array_push( $theme_js_deps, 'justified-gallery' );
				array_push( $theme_js_deps, 'jquery-fitvids' );
				wp_enqueue_script( 'jquery-fitvids', $asset_uri . 'scripts/libs/jquery.fitvids.min.js', array( 'jquery' ), '1.1', true );
				wp_enqueue_script( 'justified-gallery', $asset_uri . 'libs/justified-gallery/jquery.justifiedGallery.min.js', array( 'jquery' ), '3.6.5', true );
				wp_enqueue_style( 'justified-gallery', $asset_uri . 'libs/justified-gallery/justifiedGallery.min.css', array(), '3.6.3' );
				if ( comments_open() ) {
					wp_enqueue_script( 'comment-reply' );
				}
				if ( is_singular( 'post' ) ) {
					array_push( $theme_js_deps, 'alpaca-post' );
					wp_enqueue_script( 'alpaca-post', $asset_uri . 'scripts/front/single-post' . $asset_suffix . '.js', array( 'alpaca-helper' ), $asset_version, true );
				}
			}

			wp_enqueue_script( 'alpaca-helper', $asset_uri . 'scripts/front/helper' . $asset_suffix . '.js', array( 'jquery' ), $asset_version, true );
			wp_localize_script( 'alpaca-helper', 'alpacaHelper', array( 'siteURL' => home_url( '/' ) ) );
			wp_enqueue_script( 'alpaca-animations', $asset_uri . 'scripts/front/animations' . $asset_suffix . '.js', array( 'alpaca-helper' ), $asset_version, true );
			wp_enqueue_script( 'alpaca-theme-script', $asset_uri . 'scripts/front/main' . $asset_suffix . '.js', $theme_js_deps, $asset_version, true );
			wp_localize_script( 'alpaca-theme-script', 'alpaca', apply_filters( 'alpaca_front_json', array() ) );
		}
	}
	new Alpaca_Front_Assets_Controller();
}
