<?php
if ( ! class_exists( 'Alpaca_Custom_Ajax' ) ) {
    class Alpaca_Custom_Ajax {
        /**
        * Construct function
        */
        public function __construct() {
            add_filter( 'alpaca_ajax_load_more_json', array( $this, 'ajax_json' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets'), 1 );
        }
        /**
        * Enqueue ajax related JaveScript
        */
        public function enqueue_assets() {
			if ( $this->is_ajax_archive_page() ) {
                wp_enqueue_script(
                    'alpaca-ajax-load-more',
                    ALPACA_ASSETS_URI . 'scripts/front/ajax-load-more' . alpaca_get_assets_suffix() . '.js',
                    array( 'jquery', 'alpaca-theme-script' ),
                    ALPACA_ASSETS_VERSION,
                    true
                );
				wp_localize_script(
					'alpaca-ajax-load-more',
					'alpacaAjaxLoadMore',
					apply_filters( 'alpaca_ajax_load_more_json', array(
						'noMoreText' => esc_js( __( 'No More Posts', 'alpaca' ) )
					) )
				);
			}
		}
		/**
		* Condition function if load ajax related javascript
		*/
		protected function is_ajax_archive_page() {
			$archive_page = apply_filters( 'alpaca_achive_page_queried', '' );
			if ( ! empty( $archive_page ) ) {
				$pagination_style = alpaca_get_theme_mod( 'alpaca_list_pagination_style' );
				return in_array( $pagination_style, array( 'ajax-manual', 'ajax-auto' ) );
			}
			return false;
		}
		/**
		* Generate ajax json
		* @param array
		* @return array
		*/
		public function ajax_json( $json ) {
			$vars = $this->get_query_vars();
			return array_merge( $json, array(
				'url' => esc_js( admin_url( 'admin-ajax.php' ) ),
				'data' => apply_filters( 'loftocean_ajax_load_more_parameters', array(
					'query'	=> $vars['query'],
					'action' => 'alpaca_load_more',
					'settings' => $vars['settings']
				) )
			) );
		}
		/**
		* Get query vars for each archive page
		*/
		protected function get_query_vars() {
			$vars = array(
				'settings' => array(
					'archive_page' => '',
					'layout' => 'other',
                    'columns' => '',
					'grid_style' => '',
					'grid_image_ratio' => '',
					'page_layout' => apply_filters( 'alpaca_page_layout', '' )
				),
				'query' => array(
					'paged' => 2,
					'post_type' => maybe_serialize( get_query_var( 'post_type' ) ),
					'ignore_sticky_posts' => true,
					'post_status' => is_user_logged_in() ? maybe_serialize( array( 'publish', 'private' ) ) : 'publish',
				)
			);
			if ( alpaca_is_extension_activated() && alpaca_is_builder_homepage() ) {
				$vars['settings']['archive_page'] = 'builder-homepage';
				$vars['settings']['layout'] = $this->get_layout( 'home' );
                $vars['settings']['columns'] = $this->get_columns( 'home' );
                $vars['settings']['grid_style'] = $this->get_grid_style( 'home' );
                $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( 'home' );
				$metas = alpaca_get_list_post_meta( 'home' );
				$vars['settings']['metas'] = alpaca_is_valid_array( $metas ) ? maybe_serialize( $metas ) : '';

				$vars['query']['post_type'] = 'post';
				$vars['query']['ignore_sticky_posts'] = false;
				$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_home_posts_per_page' );
				$vars['query'] = apply_filters( 'alpaca_frontend_homepage_query_posts_args', $vars['query'], true );
			} else if ( is_home() ) {
                $home_page_type = '';
                if ( alpaca_is_static_blog_page() ) {
                    $vars['settings']['static_blog_page'] = true;
                    $home_page_type = 'blog';
                } else {
                    $home_page_type = 'home';
                    $vars['query'] = apply_filters( 'alpaca_frontend_blog_query_posts_args', $vars['query'], true );
                }
				$vars['settings']['archive_page'] = 'home';
				$vars['settings']['layout'] = $this->get_layout( $home_page_type );
                $vars['settings']['columns'] = $this->get_columns( $home_page_type );
                $vars['settings']['grid_style'] = $this->get_grid_style( $home_page_type );
                $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( $home_page_type );
				$metas = alpaca_get_list_post_meta( $home_page_type );
				$vars['settings']['metas'] = alpaca_is_valid_array( $metas ) ? maybe_serialize( $metas ) : '';

				$vars['query']['post_type'] = 'post';
				$vars['query']['ignore_sticky_posts'] = false;
				$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_' . $home_page_type . '_posts_per_page' );
			} else if ( is_search() ) {
				$vars['settings']['archive_page'] = 'search';
				$vars['settings']['layout'] = $this->get_layout( 'search' );
                $vars['settings']['columns'] = $this->get_columns( 'search' );
                $vars['settings']['grid_style'] = $this->get_grid_style( 'search' );
                $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( 'search' );

				$post_types = array( 'post' );
				$vars['query']['post_type'] = maybe_serialize( $post_types );
				$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_search_posts_per_page' );
				$vars['query']['s'] = esc_js( get_search_query() );
			} else if ( is_date() ) {
				global $wp_query;
				if ( is_day() ) {
					$vars['query']['year'] = get_query_var( 'year' );
					$vars['query']['monthnum'] = get_query_var( 'monthnum');
					$vars['query']['day'] = get_query_var( 'day' );
				} else if ( is_month() ) {
					$vars['query']['year'] = get_query_var( 'year' );
					$vars['query']['monthnum'] = get_query_var( 'monthnum');
				}  else if ( is_year() ) {
					$vars['query']['year'] = get_query_var( 'year' );
				}
				$vars['query']['post_type'] = 'post';
				$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_date_posts_per_page' );

				$vars['settings']['archive_page'] = 'date';
				$vars['settings']['layout'] = $this->get_layout( 'date' );
                $vars['settings']['columns'] = $this->get_columns( 'date');
                $vars['settings']['grid_style'] = $this->get_grid_style( 'date' );
                $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( 'date' );
			} else if ( is_archive() ) {
				if ( is_category() ) {
					$vars['query']['post_type'] = 'post';
					$vars['query']['cat'] = get_queried_object_id();
					$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_category_posts_per_page' );

					$vars['settings']['archive_page'] = 'category';
					$vars['settings']['layout'] = $this->get_layout( 'category' );
                    $vars['settings']['columns'] = $this->get_columns( 'category' );
                    $vars['settings']['grid_style'] = $this->get_grid_style( 'category' );
                    $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( 'category' );
				} else if ( is_author() ) {
					$vars['query']['post_type'] = 'post';
					$vars['query']['author'] = get_queried_object_id();
					$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_author_posts_per_page' );

					$vars['settings']['archive_page'] = 'author';
					$vars['settings']['layout'] = $this->get_layout( 'author' );
                    $vars['settings']['columns'] = $this->get_columns( 'author' );
                    $vars['settings']['grid_style'] = $this->get_grid_style( 'author' );
                    $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( 'author' );
				} else if ( is_tag() ) {
					$vars['query']['post_type'] = 'post';
					$vars['query']['tag_id'] = get_queried_object_id();
					$vars['query']['posts_per_page'] = alpaca_get_theme_mod( 'alpaca_archive_page_tag_posts_per_page' );

					$vars['settings']['archive_page'] = 'tag';
					$vars['settings']['layout'] = $this->get_layout( 'tag' );
                    $vars['settings']['columns'] = $this->get_columns( 'tag' );
                    $vars['settings']['grid_style'] = $this->get_grid_style( 'tag' );
                    $vars['settings']['grid_image_ratio'] = $this->get_grid_image_ratio( 'tag' );
				} else if ( in_array( 'post', (array)get_query_var( 'post_type' ) ) ) {
					global $wp_query;
					$vars['settings']['archive_page'] = 'post-archive';
					$vars['settings']['layout']	= 'standard';
                    $vars['settings']['columns'] = $this->get_columns( 'post-archive' );
					$vars['settings']['metas'] = maybe_serialize( array( 'excerpt', 'read-more', 'social-icon', 'category', 'date', 'view', 'like', 'comment' ) );

					$vars['query']['posts_per_page'] = get_option( 'posts_per_page', 10 );
					foreach ( (array)$wp_query->query as $name => $value ) {
						$vars['query'][ $name ] = is_array( $value ) ? maybe_serialize( $value ) : $value;
					}
				}
			}
			return apply_filters( 'alpaca_ajax_get_query_vars', $vars );
		}
		/**
		* Get list layout
		* @param string
		* @return string
		*/
		protected function get_layout( $page ) {
			$list = alpaca_get_archive_list();
			if ( in_array( $page, $list ) ) {
				$sets = alpaca_get_post_list_layout_settings( $page );
				return str_replace( 'layout-', '', $sets[0] );
			}
			return 'standard';
		}
		/**
		* Get list column
		* @param string
		* @return string
		*/
		protected function get_columns( $page ) {
			$list = alpaca_get_archive_list();
			if ( in_array( $page, $list ) ) {
				$sets = alpaca_get_post_list_layout_settings( $page );
				return str_replace( 'column-', '', $sets[1] );
			}
			return '';
		}
        /**
        * Get grid layout style
		* @param string
		* @return string
        */
        function get_grid_style( $page ) {
        	$list = alpaca_get_archive_list();
        	if ( ! empty( $page ) && in_array( $page, $list ) ) {
        		return alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_grid_style' );
        	}
        	return '';
        }
        /**
        * Get grid layout image ratio
		* @param string
		* @return string
        */
        function get_grid_image_ratio( $page ) {
        	$list = alpaca_get_archive_list();
        	if ( ! empty( $page ) && in_array( $page, $list ) ) {
        		return alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_image_ratio' );
        	}
        	return '';
        }
    }
    new Alpaca_Custom_Ajax();
}
