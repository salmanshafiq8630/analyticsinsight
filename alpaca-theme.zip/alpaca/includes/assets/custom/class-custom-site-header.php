<?php
if ( ! class_exists( 'Alpaca_Custom_Site_Header' ) ) {
    class Alpaca_Custom_Site_Header {
        /**
        * Construct function
        */
        public function __construct() {
			add_filter( 'alpaca_custom_styles', array( $this, 'custom_styles' ) );
        }
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
			global $alpaca_default_settings;

            $color_scheme = get_theme_mod( 'alpaca_site_header_color_scheme', $alpaca_default_settings[ 'alpaca_site_header_color_scheme' ] );

            // Site header background image
            $background_image = $this->get_site_header_image();
            if ( ! empty( $background_image ) ) {
                $styles[ 'alpaca-site-header-background-image' ] = sprintf(
                    '.site-header.light-color, .site-header.dark-color { background-image: url(%s); }',
                    esc_url( $background_image )
                );
            }

            // Site header background color
            $background_colors = array( 'light_color' => array( 'light', 'dark' ), 'dark_color' => array( 'dark', 'light' ) );
            foreach ( $background_colors as $bg_color_scheme => $schemes ) {
                $background_color = alpaca_get_theme_mod( 'alpaca_site_header_' . $bg_color_scheme . '_background_color' );
                if ( ! empty( $background_color ) ) {
                    $styles[ 'alpaca-site-header' . $bg_color_scheme . '-background-color' ] = sprintf(
                        '.site-header.%1$s-color, .change-to-color-scheme-%1$s .site-header.%2$s-color { background-color: %3$s; }',
                        $schemes[0],
                        $schemes[1],
                        $background_color
                    );
                }
            }
            // Site header text color
            $text_color = get_theme_mod( 'header_textcolor' );
            if ( ! empty( $text_color ) && ( '#' == substr( $text_color, 0, 1 ) ) && ( '#blank' != $text_color ) ) {
                $styles[ 'alpaca-site-header-text-color' ] = sprintf(
                    /** translators: %1$s: site header color scheme.  %2$s: site header background color **/
                    '.site-header.%1$s { color: #%2$s; }',
                    esc_attr( $color_scheme ),
                    $text_color
                );
            }

			return $styles;
        }
        /**
        * Get site header image
        */
        protected function get_site_header_image() {
            $header_image_mod = get_theme_mod( 'header_image' );
            if ( ! empty( $header_image_mod ) ) {
                $header_image = '';
                switch ( $header_image_mod ) {
                    case 'random-uploaded-image':
                        $header_image = get_random_header_image();
                        break;
                    case 'remove-header':
                        $header_image = '';
                        break;
                    default:
                        $header_image = $header_image_mod;
                }
                return $header_image;
            }
            return '';
        }
    }
    new Alpaca_Custom_Site_Header();
}
