<?php
if ( ! class_exists( 'Alpaca_Custom_Footer' ) ) {
    class Alpaca_Custom_Footer {
        /**
        * Construct function
        */
        public function __construct() {
			add_filter( 'alpaca_custom_styles', array( $this, 'custom_styles' ) );
        }
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
            $footer_colors = array(
                'signup_form' => array(
                    'style_prefix' => '.site-footer > .site-footer-signup.%1$s-color, .change-to-color-scheme-%1$s .site-footer > .site-footer-signup.%2$s-color ',
                    'colors' => array(
                        'alpaca_site_footer_signup_form_light_color_background_color' => array( 'light', 'dark' ),
                        'alpaca_site_footer_signup_form_dark_color_background_color' => array( 'dark', 'light' )
                    )
                ),
                'instagram' =>array(
                    'style_prefix' => '.site-footer > .alpaca-widget_instagram.%1$s-color, .change-to-color-scheme-%1$s .site-footer > .alpaca-widget_instagram.%2$s-color',
                    'colors' => array(
                        'alpaca_site_footer_instagram_light_color_background_color' => array( 'light', 'dark' ),
                        'alpaca_site_footer_instagram_dark_color_background_color' => array( 'dark', 'light' )
                    )
                ),
                'bottom' => array(
                    'style_prefix' => '.site-footer > .footer-bottom.%1$s-color, .change-to-color-scheme-%1$s .site-footer > .footer-bottom.%2$s-color',
                    'colors' => array(
                        'alpaca_site_footer_bottom_light_color_background_color' => array( 'light', 'dark' ),
                        'alpaca_site_footer_bottom_dark_color_background_color' => array( 'dark', 'light' )
                    )
                )
            );
            foreach ( $footer_colors as $id => $attrs ) {
                foreach ( $attrs['colors'] as $option => $schemes ) {
                    $background_color = alpaca_get_theme_mod( $option );
                    if ( ! empty( $background_color ) ) {
                        $styles[ 'alpaca-site-footer-' . $id . '-' . $schemes[0] . '-color-background-color' ] = sprintf(
                            '%1$s { --footer-bg: %2$s; }',
                            sprintf( $attrs['style_prefix'], $schemes[0], $schemes[1] ),
                            $background_color
                        );
                    }
                }
            }
			return $styles;
        }
    }
    new Alpaca_Custom_Footer();
}
