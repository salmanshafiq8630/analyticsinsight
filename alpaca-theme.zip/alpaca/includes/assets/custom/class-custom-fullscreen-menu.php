<?php
if ( ! class_exists( 'Alpaca_Custom_Fullscreen_Menu' ) ) {
    class Alpaca_Custom_Fullscreen_Menu {
        /**
        * Construct function
        */
        public function __construct() {
			add_filter( 'alpaca_custom_styles', array( $this, 'custom_styles' ) );
        }
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
			global $alpaca_default_settings;

            // Fullscreen Menu background color
            $fullscreen_background_color = alpaca_get_theme_mod( 'alpaca_fullscreen_menu_background_color' );
            if ( ! empty( $fullscreen_background_color ) ) {
                $styles[ 'alpaca-fullscreen-menu-background-color' ] = sprintf(
                    // translators: 1: style selectors, 2: dynamic background color
                    ' .alpaca-fullmenu .menu-wrapper:before { background-color: %s; }',
                    $fullscreen_background_color
                );
            }
            // Fullscreen menu text color
            $fullscreen_text_color = alpaca_get_theme_mod( 'alpaca_fullscreen_menu_text_color' );
            if ( ! empty( $fullscreen_text_color ) ) {
                $styles[ 'alpaca-fullscreen-menu-text-color' ] = sprintf(
                    // translators: 1: style selectors, 2: dynamic background color
                    ' .alpaca-fullmenu  .menu-wrapper { color: %s; }',
                    $fullscreen_text_color
                );
            }

            $selectors = '.alpaca-fullmenu .widgets-wrapper.dark-color, .alpaca-fullmenu .widgets-wrapper.light-color';
            // Fullscreen menu widget area background color
            $widgets_background_color = alpaca_get_theme_mod( 'alpaca_fullscreen_menu_widgets_background_color' );
            if ( ! empty( $widgets_background_color ) ) {
                $styles[ 'alpaca-fullscreen-menu-widgets-background-color' ] = sprintf(
                    // translators: 1: style selectors, 2: dynamic background color
                    ' .alpaca-fullmenu .widgets-wrapper:before { background-color: %s; }',
                    $widgets_background_color
                );
            }
            // Fullscreen menu widget area text color
            $widgets_text_color = alpaca_get_theme_mod( 'alpaca_fullscreen_menu_widgets_text_color' );
            if ( ! empty( $widgets_text_color ) ) {
                $styles[ 'alpaca-fullscreen-menu-widgets-text-color' ] = sprintf(
                    // translators: 1: style selectors, 2: dynamic background color
                    ' .alpaca-fullmenu .widgets-wrapper .container { color: %s; }',
                    $widgets_text_color
                );
            }
			return $styles;
        }
    }
    new Alpaca_Custom_Fullscreen_Menu();
}
