<?php
if ( ! class_exists( 'Alpaca_Custom_General' ) ) {
    class Alpaca_Custom_General {
        /**
        * Construct function
        */
        public function __construct() {
			add_filter( 'alpaca_custom_styles', array( $this, 'custom_styles' ) );
            add_filter( 'alpaca_custom_style_vars', array( $this, 'custom_style_vars' ) );
        }
		/**
		* Generate custom style variables
		*/
		public function custom_style_vars( $vars ) {
			global $alpaca_default_settings;
			$css_vars = array(
				'--primary-color' => 'alpaca_custom_accent_color',
				'--light-bg-color' => 'alpaca_light_scheme_custom_bg_color',
                '--light-text-color' => 'alpaca_light_scheme_custom_text_color',
                '--light-content-color' => 'alpaca_light_scheme_custom_content_color',
                '--dark-bg-color' => 'alpaca_dark_scheme_custom_bg_color',
                '--dark-text-color' => 'alpaca_dark_scheme_custom_text_color',
                '--dark-content-color' => 'alpaca_dark_scheme_custom_content_color',
			);
			foreach( $css_vars as $var => $id ) {
				$custom_value = alpaca_get_theme_mod( $id );
				if ( $custom_value != $alpaca_default_settings[ $id ] ) {
					$vars[ $var ] = sprintf( '%s', $custom_value );
                    if ( '--primary-color' == $var ) {
                        $vars[ '--primary-color-semi' ] = alpaca_hex2rgba( $custom_value, '0.3' );
                    }
				}
			}
			return $vars;
		}
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
			global $alpaca_default_settings;

            // Mobile Menu background color
            $mm_bg_color = alpaca_get_theme_mod( 'alpaca_mobile_menu_bg_color' );
            if ( ! empty( $mm_bg_color ) && ( $alpaca_default_settings[ 'alpaca_mobile_menu_bg_color' ] != $mm_bg_color ) ) {
                $styles[ 'alpaca_mobile_menu_bg_color' ] = sprintf(
                    '.sidemenu .container { background-color: %s; }',
                    $mm_bg_color
                );
            }
            // Mobile menu text color
            $mm_text_color = alpaca_get_theme_mod( 'alpaca_mobile_menu_text_color' );
            if ( ! empty( $mm_text_color ) && ( $alpaca_default_settings[ 'alpaca_mobile_menu_text_color' ] != $mm_text_color ) ) {
                $styles[ 'alpaca_mobile_menu_text_color' ] = sprintf(
                    '.sidemenu .container { color: %s; }',
                    $mm_text_color
                );
            }
            // Popup signup form background color
            $colors = array( 'light_color' => array( 'light', 'dark' ), 'dark_color' => array( 'dark', 'light' ) );
            foreach( $colors as $id => $schemes ) {
                $bg_color = alpaca_get_theme_mod( 'alpaca_popup_signup_form_' . $id . '_background_color' );
                if ( ! empty( $bg_color ) ) {
                    $styles[ 'alpaca_popup_signup_form_' . $id . '_background_color' ] = sprintf(
                        '.popup-signup.%1$s-color .container-inner, .change-to-color-scheme-%1$s .popup-signup.%2$s-color .container-inner { --bg-color: %3$s; }',
                        $schemes[0],
                        $schemes[1],
                        $bg_color
                    );
                }
            }

            if ( alpaca_module_enabled( 'alpaca_sidebar_enable_sticky' ) ) {
                $styles[ 'alpaca_sticky_sidebar_height' ] = '#secondary.sidebar.widget-area { height: 100%; }';
            }

			return $styles;
        }
    }
    new Alpaca_Custom_General();
}
