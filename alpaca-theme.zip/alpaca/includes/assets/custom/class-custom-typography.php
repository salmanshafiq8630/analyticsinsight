<?php
if ( ! class_exists( 'Alpaca_Custom_Typography' ) ) {
    class Alpaca_Custom_Typography {
        /**
        * Construct function
        */
        public function __construct() {
			add_filter( 'alpaca_custom_styles', array( $this, 'custom_styles' ) );
			add_filter( 'alpaca_custom_style_vars', array( $this, 'custom_style_vars' ) );

			add_action( 'alpaca_enqueue_google_fonts', array( $this, 'enqueue_google_fonts' ) );
        }
		/**
		* Generate custom style variables
		*/
		public function custom_style_vars( $vars ) {
			global $alpaca_default_settings;
			$css_vars = array(
				'--heading-font'    => 'alpaca_typography_heading_',
				'--body-font'       => 'alpaca_typography_text_'
			);
			foreach ( $css_vars as $var => $prefix ) {
                if ( 'google_font' == alpaca_get_theme_mod( $prefix . 'font_family_source' ) ) {
                    $id = $prefix . 'font-family';
    				$custom_value = alpaca_get_theme_mod( $id );
    				$vars[ $var ] = sprintf( '"%s"', $custom_value );
                } else if ( 'alpaca_typography_heading_' == $prefix ) {
                    $vars[ $var ] = 'var(--system-font)';
                }
			}
			return $vars;
		}
		/**
		* Generate custom styles
		*/
		public function custom_styles( $styles ) {
			global $alpaca_default_settings;
			$this->setting_keys = array_keys( $alpaca_default_settings );

			$styles['alpaca-typography-post-title'] = $this->get_typography_styles(
				'.entry-title',
				'alpaca_typography_post_title',
				array( 'font-weight', 'text-transform', 'font-style' )
			);

            $styles['alpaca-typography-page-title'] = $this->get_typography_styles(
				'.page-header .header-text .entry-title, .archive-title, .no-results .entry-title, .page-404 .entry-title',
				'alpaca_typography_page_title',
				array( 'font-weight', 'text-transform', 'font-style' )
			);

			$styles['alpaca-typography-content'] = $this->get_typography_styles(
				'.entry-content',
				'alpaca_typography_content',
				array( 'font-size', 'line-height' )
			);

			$styles['alpaca-typography-post-excerpt'] = $this->get_typography_styles(
				'.posts .entry-excerpt',
				'alpaca_typography_post_excerpt',
				array( 'font-size' )
			);
            $overlay_font_size = alpaca_get_theme_mod( 'alpaca_typography_post_excerpt_overlay_font-size' );
            if ( $alpaca_default_settings['alpaca_typography_post_excerpt_overlay_font-size'] != $overlay_font_size ) {
                $styles['alpaca-typography-post-excerpt-overlay-font-size'] = sprintf(
    				'.posts .post.post-overlay .entry-excerpt, .posts.layout-full-overlay .post .entry-excerpt { font-size: %spx; }',
    				$overlay_font_size
    			);
            }

            $styles['alpaca-typography-homepage-section-title'] = $this->get_typography_styles(
				'h5.section-title',
				'alpaca_typography_homepage_section_title',
				array( 'font-size', 'font-weight', 'letter-spacing', 'text-transform' )
			);
			$styles['alpaca-typography-homepage-section-sub-title'] = $this->get_typography_styles(
				'.section-sub-title',
				'alpaca_typography_homepage_section_title_sub',
				array( 'font-size' )
			);

			$font_family = array(
                'alpaca_typography_content_font_family' => '.entry-content',
                'alpaca_typography_post_excerpt_font_family' => '.posts .entry-excerpt',
                'alpaca_typography_homepage_section_title_font_family' => 'h5.section-title',
                'alpaca_typography_homepage_section_title_sub_font_family' => '.section-sub-title'
            );

            $fonts = array( 'heading_font' => 'var(--heading-font)', 'text_font' => 'var(--body-font)' );
            foreach ( $font_family as $ff => $selector ) {
                $setting = alpaca_get_theme_mod( $ff );
                if ( $setting != $alpaca_default_settings[ $ff ] ) {
                    $styles[ $ff ] = sprintf( '%1$s { font-family: %2$s; }', $selector, $fonts[ $setting ] );
                }
            }

			return $styles;
		}
        /**
        * Generate typography styles
        */
		private function get_typography_styles( $element, $prefix, $attrs, $no_check = false ) {
			global $alpaca_default_settings;
			if ( ! empty( $element ) && ! empty( $prefix ) && ! empty( $attrs ) && is_array( $attrs ) ) {
				$styles = '';
				foreach ( $attrs as $attr ) {
					$name = $prefix . '_' . $attr;
					if ( in_array( $name, $this->setting_keys ) ) {
						$value = esc_attr( alpaca_get_theme_mod( $name ) );
						if ( $no_check || ( $alpaca_default_settings[ $name ] != $value ) ) {
							$unit = ( $attr == 'font-size' ) ? 'px' : '';
							$styles .= "\n\t" . $attr . ': ' . $value . $unit . ';';
						}
					}
				}
				return empty( $styles ) ? '' : sprintf( "\n%s {%s\n}\n", $element, $styles );
			}
			return '';
		}
		/**
		* Enqueue google fonts
		*/
		public function enqueue_google_fonts() {
			$google_fonts = array();
            if ( 'google_font' == alpaca_get_theme_mod( 'alpaca_typography_heading_font_family_source' ) ) {
				array_push( $google_fonts, alpaca_get_theme_mod( 'alpaca_typography_heading_font-family' ) 	. ':100,200,300,400,500,600,700,800' );
            }
            if ( 'google_font' == alpaca_get_theme_mod( 'alpaca_typography_text_font_family_source' ) ) {
				array_push( $google_fonts, alpaca_get_theme_mod( 'alpaca_typography_text_font-family' ) . ':100,200,300,400,500,600,700,800' );
			}

			$google_fonts = array_unique( $google_fonts );
			// Add Google font in safe way. Refer to https://gist.github.com/richtabor/b85d317518b6273b4a88448a11ed20d3
			if ( ! empty( $google_fonts ) ) {
				wp_enqueue_style(
					'alpaca-theme-google-fonts',
					add_query_arg( array( 'family' => urlencode( implode( '|', $google_fonts ) ), 'display' => 'swap' ), 'https://fonts.googleapis.com/css' ),
					array(),
					ALPACA_ASSETS_VERSION
				);
			}
		}
    }
    new Alpaca_Custom_Typography();
}
