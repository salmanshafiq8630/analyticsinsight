<?php
/**
* Theme assets manager class for editor
*/

if ( ! class_exists( 'Alpaca_Assets_Controller_Editor' ) ) {
	class Alpaca_Assets_Controller_Editor {
		/**
		* Construct function
		*/
		public function __construct() {
			$this->load_files();
			add_filter( 'alpaca_get_gutenberg_custom_styles', array( $this, 'custom_css_for_gutenberg' ) );
			add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ) );
		}
		/**
		* Import required files
		*/
		protected function load_files() {
			require_once ALPACA_THEME_INC . 'assets/custom/class-custom-typography.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
		/**
		* Enqueue assets for gutenberg editor
		*/
		public function enqueue_editor_assets() {
			do_action( 'alpaca_enqueue_google_fonts' );
			$custom_css = apply_filters( 'alpaca_get_gutenberg_custom_styles', '' );
			$custom_css = trim( $custom_css );
			$style_handler = 'alpaca-block-style';

			wp_enqueue_style( 'font-awesome-all', ALPACA_ASSETS_URI . 'fonts/font-awesome/css/all.min.css' );

			wp_enqueue_style(
				$style_handler,
				ALPACA_ASSETS_URI . 'styles/editor/editor-style' . alpaca_get_assets_suffix() . '.css',
				array( 'wp-block-library' ),
				ALPACA_ASSETS_VERSION
			);

			if ( ! empty( $custom_css ) ) {
				wp_add_inline_style( $style_handler, $custom_css );
			}
			do_action( 'alpaca_enqueue_google_fonts' );
		}
		/**
		* Custom CSS for gutenberg editor
		*/
		public function custom_css_for_gutenberg( $style ) {
			// Primary color
			$primary_color = alpaca_get_theme_mod( 'alpaca_custom_accent_color' );
			$rgba = alpaca_hex2rgba( $primary_color, '0.5' );

			$style .= sprintf(
				' %1$s { color: %2$s; box-shadow: 0 1px 0 %2$s; }',
				'.editor-rich-text__tinymce a, .editor-rich-text__editable a',
				$primary_color
			);

			$style .= sprintf(
				' %1$s { box-shadow: inset 0 -6px 0 %2$s, 0 1px 0 %2$s; }',
				'.editor-rich-text__tinymce a:hover, .editor-rich-text__editable a:hover',
				alpaca_hex2rgba( $primary_color, '0.3' )
			);

			$style .= sprintf(
				' .wp-block .editor-rich-text .highlight { background: %s; }',
				$rgba
			);

			$vars = array( '--primary-color: ' . $primary_color );
			$css_vars = array(
				'--heading-font'    => 'alpaca_typography_heading_',
				'--body-font'       => 'alpaca_typography_text_'
			);
			foreach ( $css_vars as $var => $prefix ) {
				if ( 'google_font' == alpaca_get_theme_mod( $prefix . 'font_family_source' ) ) {
					$id = $prefix . 'font-family';
					$custom_value = alpaca_get_theme_mod( $id );
					array_push( $vars, $var . ': ' . sprintf( '"%s"', $custom_value ) );
				} else {
					array_push( $vars, $var . ': var(--system-font)' );
				}
			}
			$style .= sprintf( ':root { %s; }', implode( '; ', $vars ) );

			return $style;
		}
	}
	new Alpaca_Assets_Controller_Editor();
}
