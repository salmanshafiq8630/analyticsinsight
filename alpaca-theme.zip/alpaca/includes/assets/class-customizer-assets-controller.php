<?php
/**
* Theme front end assets manager class
*/

if ( ! class_exists( 'Alpaca_Assets_Controller_Customizer' ) ) {
	class Alpaca_Assets_Controller_Customizer{
		/**
		* String main style.css id
		*/
		public $main_style_id = '';
		/**
		* Construct function
		*/
		public function __construct() {
            if ( ! empty( $_REQUEST['customize_changeset_uuid'] ) ) {
				add_filter( 'alpaca_json_customizer_preview', array( $this, 'customize_perview_json' ) );
                add_action( 'customize_preview_init', array( $this, 'enqueue_preview_scripts' ) );
            } else {
                add_filter( 'alpaca_json_customizer', array( $this, 'get_customizer_json' ) );
                add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_customize_scripts' ) );
                add_action( 'customize_controls_print_footer_scripts', array( $this, 'print_footer_scripts' ), 9999 );
            }
		}
		/**
		* Enqueue script for customizer.php
		*/
		public function enqueue_customize_scripts() {
			$assets_version = ALPACA_ASSETS_VERSION;
			$js_root_uri 	= ALPACA_ASSETS_URI . 'scripts/';
			$css_root_uri 	= ALPACA_ASSETS_URI . 'styles/';
			$font_root_uri	= ALPACA_ASSETS_URI . 'fonts/';
			$customize_deps = array( 'jquery-ui-slider', 'customize-controls', 'jquery', 'alpaca-function-lib' );
            $suffix = alpaca_get_assets_suffix();

			wp_enqueue_script( 'alpaca-function-lib', $js_root_uri . 'admin/functions' . $suffix . '.js', array( 'jquery' ), $assets_version, true );
			wp_enqueue_script( 'alpaca-customizer', $js_root_uri . 'customize/customize' . $suffix . '.js', $customize_deps, $assets_version, true );
			wp_localize_script( 'alpaca-customizer', 'alpacaCustomizer', apply_filters( 'alpaca_json_customizer', array() ) );

			wp_enqueue_style( 'awsomefont', $font_root_uri . 'font-awesome/css/fontawesome.min.css' );
			wp_enqueue_style( 'jquery-ui', $css_root_uri . 'jquery-ui/jquery-ui.min.css' );
			wp_enqueue_style( 'alpaca-customizer-style', $css_root_uri . 'customize/customizer' . $suffix . '.css', array(), $assets_version );
		}
		/**
		* Enqueue scirpts for customize previewer
		*/
		public function enqueue_preview_scripts() {
			$assets_version = ALPACA_ASSETS_VERSION;
			$js_root_uri 	= ALPACA_ASSETS_URI . 'scripts/';
            $js_dependency  = array( 'jquery', 'customize-selective-refresh' );
            $suffix = alpaca_get_assets_suffix();

			wp_enqueue_script( 'alpaca-customizer-preview', $js_root_uri . 'customize/preview' . $suffix . '.js', $js_dependency, $assets_version, true );
			wp_localize_script( 'alpaca-customizer-preview', 'alpacaCustomizerPreview', apply_filters( 'alpaca_json_customizer_preview', array() ) );
		}
        /**
        * Enqueue admin scripts
        */
		public function print_footer_scripts() {
			do_action( 'admin_print_footer_scripts' );
		}
        /**
        * Get customizer json
        * @param array
        * @return array
        */
        public function get_customizer_json( $json = array() ) {
            $editor_ids = isset( $json['editor_ids'] ) ? $json['editor_ids'] : array();
			$permalink_structure = get_option( 'permalink_structure', '' );
			array_push( $editor_ids, 'alpaca_home_custom_content_editor' );
			$json['editor_ids'] = $editor_ids;

            return array_merge( $json, array(
                'header_description' => '',
                'header_label' => esc_html__( 'Header Image', 'alpaca' ),
				'homeURL' => home_url( '/' ),
				'errorURL' => empty( $permalink_structure ) ? home_url( '/index.php/?error=404' ) : home_url( '/index.php/error-404' )
			) );
        }
		/**
		* Customize preview json
		*/
		public function customize_perview_json( $json ) {
			return array_merge( $json, array(
				'alpaca_fullscreen_menu_background_color' => array(
					'dark' => alpaca_get_theme_mod( 'alpaca_dark_scheme_custom_bg_color' ),
					'light' => alpaca_get_theme_mod( 'alpaca_light_scheme_custom_bg_color' )
				),
				'alpaca_fullscreen_menu_text_color' => array(
					'dark' => alpaca_get_theme_mod( 'alpaca_dark_scheme_custom_text_color' ),
					'light' => alpaca_get_theme_mod( 'alpaca_light_scheme_custom_text_color' )
				),
				'alpaca_fullscreen_menu_widgets_background_color' => array(
					'dark' => alpaca_get_theme_mod( 'alpaca_dark_scheme_custom_bg_color' ),
					'light' => alpaca_get_theme_mod( 'alpaca_light_scheme_custom_bg_color' )
				),
				'alpaca_fullscreen_menu_widgets_text_color' => array(
					'dark' => alpaca_get_theme_mod( 'alpaca_dark_scheme_custom_text_color' ),
					'light' => alpaca_get_theme_mod( 'alpaca_light_scheme_custom_text_color' )
				),
				'alpaca_popup_signup_form_light_color_background_color' => alpaca_get_theme_mod( 'alpaca_light_scheme_custom_bg_color' ),
				'alpaca_popup_signup_form_dark_color_background_color' => alpaca_get_theme_mod( 'alpaca_dark_scheme_custom_bg_color' )
			) );
		}
	}
	new Alpaca_Assets_Controller_Customizer();
}
