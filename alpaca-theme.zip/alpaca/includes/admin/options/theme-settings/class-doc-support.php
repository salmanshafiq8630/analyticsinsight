<?php
if ( ! class_exists( 'Alpaca_Theme_Settings_Panel_Doc_Support' ) ) {
	class Alpaca_Theme_Settings_Panel_Doc_Support extends Alpaca_Theme_Option_Section {
		/**
		* Setup environment
		*/
		protected function setup_env() {
			$this->title = esc_html__( 'Docs & Support', 'alpaca' );
			$this->id = 'support-panel';
		}
		/**
		* Render section content
		*/
		public function render_section_content() { ?>
			<div class="alpaca-panel-column">
				<h3><?php esc_html_e( 'Documentation', 'alpaca' ); ?></h3>
				<p>
					<?php esc_html_e( 'If you have any problems or questions while using this theme, please check our online documentation first. Your question may have been answered in the documentation.', 'alpaca' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Click the button below to read the documentation.', 'alpaca' ); ?>
				</p>
				<a class="button button-primary button-hero" href="<?php echo esc_url( 'https://loftocean.com/alpaca-doc/documentation.html' ); ?>" target="_blank">
					<?php esc_html_e( 'Online Documentation', 'alpaca' ); ?>
				</a>
			</div>
			<div class="alpaca-panel-column">
				<h3><?php esc_html_e( 'FAQs', 'alpaca' ); ?></h3>
				<ul>
					<li>
						<a href="<?php echo esc_url( 'https://www.loftocean.com/alpaca-doc/documentation.html#social-menu' ); ?>" target="blank">
							<?php esc_html_e( 'How to display social media icons on your website', 'alpaca' ); ?>
						</a>
					</li>
					<li>
						<a href="<?php echo esc_url( 'https://www.loftocean.com/alpaca-doc/documentation.html#theme-update' ); ?>" target="blank">
							<?php esc_html_e( 'How to update the theme', 'alpaca' ); ?>
						</a>
					</li>
					<li>
						<a href="<?php echo esc_url( 'https://www.loftocean.com/alpaca-doc/documentation.html#translation' ); ?>" target="_blank">
							<?php esc_html_e( 'How to translate the theme', 'alpaca' ); ?>
						</a>
					</li>
					<li>
						<a href="<?php echo esc_url( 'https://www.loftocean.com/alpaca-doc/documentation.html#mega-menu' ); ?>" target="_blank">
							<?php esc_html_e( 'How to display posts of a category in menu (mega menu)', 'alpaca' ); ?>
						</a>
					</li>
				</ul>
			</div>
			<div class="alpaca-panel-column">
				<h3><?php esc_html_e( 'Get Support', 'alpaca' ); ?></h3>
				<p><?php esc_html_e( 'If you cannot find answers to your questions in the documentation and the FAQs, please submit a support request.', 'alpaca' ); ?></p>

				<p>
					<?php printf(
						/* translators: 1: html link tag start. 2: html link tag end */
						esc_html__( 'Please open a support ticket at %1$sLoft.Ocean Help Center%2$s.', 'alpaca' ),
						'<a target="_blank" href="https://www.loftocean.com/help-center/">',
						'</a>'
					); ?>
				</p>

				<p>
					<?php printf(
						/* translators: %1$s: html tag start. %2$s: html tag end */
						esc_html__( 'When submitting your support request, please %1$sfollow this guide%2$s.', 'alpaca' ),
						sprintf( '<a href="%s" target="_blank">', 'https://www.loftocean.com/alpaca-doc/documentation.html#need-support' ),
						'</a>'
					); ?>
				</p>
			</div> <?php
		}
	}
	new Alpaca_Theme_Settings_Panel_Doc_Support();
}
