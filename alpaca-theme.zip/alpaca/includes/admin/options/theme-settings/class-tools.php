<?php
if ( ! class_exists( 'Alpaca_Theme_Settings_Panel_Tools' ) && alpaca_is_extension_activated() ) {
    class Alpaca_Theme_Settings_Panel_Tools extends Alpaca_Theme_Option_Section {
        /**
        * Setup environment
        */
        protected function setup_env() {
            $this->title = esc_html__( 'Theme tools', 'alpaca' );
            $this->id = 'tools-panel';

            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        }
        /**
        * Render section content
        */
        public function render_section_content() { ?>
            <div class="alpaca-panel-column theme-tools">
                <p><?php esc_html_e( 'If you have imported the demo data many times, you may find that you cannot save the changed content when using the Gutenberg editor. If this happens, you can try to fix the problem by clicking the button below. If the problem has not been fixed after clicking this button, please do not hesitate to contact our support team.', 'alpaca' ); ?></p>
                <a href="#" class="button button-primary button-hero clear-gutenberg-issue"><?php esc_html_e( 'Fix Gutenberg Editor Issue', 'alpaca' ); ?></a>
                <p class="notification"></p>
            </div><?php
        }
        public function enqueue_assets() {
            wp_enqueue_script( 'alpaca-theme-tools', ALPACA_ASSETS_URI . 'scripts/admin/theme-tools' . alpaca_get_assets_suffix() . '.js', array( 'jquery' ), ALPACA_ASSETS_VERSION, true );
            wp_localize_script( 'alpaca-theme-tools', 'alpacaThemeTools', array(
                'sendingRequest' => esc_js( 'Sending Request ...', 'alpaca' ),
                'done' => esc_js( 'Done', 'alpaca' ),
                'failed' => esc_js( 'Failed. Please try again later.', 'alpaca' ),
                'apiRoot' => esc_url_raw( get_rest_url() )
            ) );
        }
    }
    new Alpaca_Theme_Settings_Panel_Tools();
}
