<?php
if ( ! class_exists( 'Alpaca_Theme_Option_Panel_Required_Plugin' ) ) {
	class Alpaca_Theme_Option_Panel_Required_Plugin extends Alpaca_Theme_Option_Section {
		/**
		* Setup environment
		*/
		protected function setup_env() {
			$this->id = 'plugin-panel';
			$this->title = esc_html__( 'The Required Plugin', 'alpaca' );
			$this->defaults = array(
				'alpaca_auto_update_required_plugin' => '',
				'alpaca_auto_activate_required_plugin' => ''
			);

			add_filter( 'alpaca_enable_required_plugin_auto_update', array( $this, 'is_auto_update_enabled' ) );
			add_filter( 'alpaca_enable_required_plugin_auto_activate', array( $this, 'is_auto_active_enabled' ) );
			add_filter( 'auto_update_plugin', array( $this, 'set_plugin_auto_update' ), 999, 2 );
		}
		/**
		* Render section content
		*/
		public function render_section_content() {
			$auto_update_status = $this->get_value( 'alpaca_auto_update_required_plugin' );
			$auto_activate_status = $this->get_value( 'alpaca_auto_activate_required_plugin' ); ?>
			<div class="alpaca-panel-column">
				<h3><?php esc_html_e( 'Alpaca Extension', 'alpaca' ); ?></h3>
				<p>
					<?php printf(
						/* translators: %1$s: html tag start. %2$s: html tag end */
						esc_html__( 'Please make sure you have installed and activated the required plugin %1$s"Alpaca Extension"%2$s to get the full functionalities of the theme.', 'alpaca' ),
						'<strong>',
						'</strong>'
					); ?>
				</p>
				<?php if ( $this->is_tgmpa_exists() ) : ?>
				<a class="button button-primary button-hero" href="<?php echo esc_url( admin_url( 'themes.php?page=tgmpa-install-plugins' ) ); ?>">
					<?php esc_html_e( 'Install Plugins', 'alpaca' ); ?>
				</a>
				<?php endif; ?>
			</div>
			<div class="alpaca-panel-column">
				<h3><?php esc_html_e( 'Auto Options', 'alpaca' ); ?></h3>
				<ul>
					<li>
						<label for="alpaca_auto_update_required_plugin">
							<input type="checkbox" id="alpaca_auto_update_required_plugin" name="alpaca_auto_update_required_plugin" value="on" <?php checked( 'on', $auto_update_status ); ?>>
							<?php esc_html_e( 'Auto update the plugin when updating the theme', 'alpaca' ); ?>
						</label>
					</li>
					<li>
						<label for="alpaca_auto_activate_required_plugin">
							<input type="checkbox" id="alpaca_auto_activate_required_plugin" name="alpaca_auto_activate_required_plugin" value="on" <?php checked( 'on', $auto_activate_status ); ?>>
							<?php esc_html_e( 'Auto activate the plugin when activating the theme', 'alpaca' ); ?>
						</label>
					</li>
					<li>
						<a href="<?php echo esc_url( 'https://loftocean.com/alpaca-doc/documentation.html#basic-settings' ); ?>" target="_blank">
							<?php esc_html_e( 'When should I enable the auto options above?', 'alpaca' ) ;?>
						</a>
					</li>
				</ul>
			</div>
			<div class="alpaca-panel-column">
				<h3><?php esc_html_e( 'About', 'alpaca' ); ?></h3>
				<p>
					<?php esc_html_e( 'Because of WordPress code standards and ThemeForest requirements: "Themes execute the presentation and styling of content, while plugins handle content creation and functionality." Therefore, some features must be included in the required plugin but not included in the theme itself.', 'alpaca' ); ?>
				</p>
			</div> <?php
		}
		/**
		* Register options
		*/
		protected function register_options() {
			$this->options = array(
				'alpaca_auto_update_required_plugin' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
				'alpaca_auto_activate_required_plugin' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			);
		}
		/**
		* Set required plugin auto update
		* @param boolean
		* @param object
		* @return boolean
		*/
		public function set_plugin_auto_update( $should_update, $plugin ) {
			if ( ! isset( $plugin->plugin ) || ( 'alpaca-extension/alpaca-extension.php' !== $plugin->plugin ) ) {
				return $should_update;
			} else {
				return apply_filters( 'alpaca_enable_required_plugin_auto_update', false );
			}
		}
		/**
		* If enable required plugin auto update
		* @param boolean
		* @return boolean
		*/
		public function is_auto_update_enabled( $enabled ) {
			return 'on' == $this->get_value( 'alpaca_auto_update_required_plugin' );
		}
		/**
		* If enable required plugin auto activate setting value
		* @param boolean
		* @return boolean
		*/
		public function is_auto_active_enabled( $enabled ) {
			return 'on' == $this->get_value( 'alpaca_auto_activate_required_plugin' );
		}
		/**
		* Help function to test tgmpa-install-plugins admin menu exists
		* @return boolean
		*/
		protected function is_tgmpa_exists() {
			global $submenu;
			return in_array( 'tgmpa-install-plugins', wp_list_pluck( $submenu['themes.php'], 2 ) );
		}
	}
	new Alpaca_Theme_Option_Panel_Required_Plugin();
}
