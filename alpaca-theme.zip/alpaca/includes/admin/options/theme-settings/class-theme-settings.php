<?php
if ( ! class_exists( 'Alpaca_Theme_Settings' ) ) {
	class Alpaca_Theme_Settings {
		/**
		* Object current class instance to make sure only once instance in running
		*/
		public static $instance = false;
		/**
		* Construct function
		*/
		public function __construct() {
			$this->includes();
			$this->save_changes();
			add_action( 'admin_menu', array( $this, 'add_theme_settings_page' ), 99 );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'alpaca_admin_theme_settings_the_panels', array( $this, 'render_theme_settings_panel' ) );
			add_action( 'alpaca_admin_theme_settings_the_widgets', array( $this, 'render_theme_settings_widget' ) );
			add_action( 'alpaca_admin_theme_settings_the_hidden_input', array( $this, 'hidden_inputs' ) );
		}
		/**
		* Include the files needed
		*/
		protected function includes() {
			$inc_dir = ALPACA_THEME_INC . 'admin/options/theme-settings/';
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'utils/class-utils-sanitize.php';
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'abstracts/class-abstract-theme-option-section.php';
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $inc_dir . 'class-require-plugin.php';
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $inc_dir . 'class-doc-support.php';
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $inc_dir . 'class-tools.php';
			// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $inc_dir . 'class-mc4wp.php';
		}
		/**
		* Save changes and redirect
		*/
		protected function save_changes() {
			if ( current_user_can( 'manage_options' ) && isset( $_REQUEST['alpaca_theme_settings_nonce'] )
				&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['alpaca_theme_settings_nonce'] ) ), 'alpaca-theme-settings-nonce' ) ) {
				// Save changes
				do_action( 'alpaca_admin_theme_settings_save' );
				update_option( 'loftocean_flush_rewrite', '' );
				// Redirect, avoid resubmission
				wp_safe_redirect( admin_url( 'themes.php?page=alpaca-theme-settings&alpaca-updated=1' ) );
				exit;
			}
		}
		/**
		* Add theme options page
		*/
		public function add_theme_settings_page() {
			$title = esc_html__( 'Alpaca Basic Settings', 'alpaca' );
			add_theme_page( $title, $title, 'manage_options', 'alpaca-theme-settings', array( $this, 'render_theme_settings_page' ) );
		}
		/**
		* Render theme option page content
		*/
		public function render_theme_settings_page() { ?>
			<div class="wrap">
				<h1 class="wp-heading-inline"><?php esc_html_e( 'Alpaca Theme Basic Settings', 'alpaca' ); ?></h1>
				<form action="<?php echo esc_url( admin_url( 'themes.php?page=alpaca-theme-settings' ) ); ?>" method="POST">
					<?php do_action( 'alpaca_admin_theme_settings_the_panels' ); ?>
					<?php do_action( 'alpaca_admin_theme_settings_the_widgets' ); ?>
					<?php do_action( 'alpaca_admin_theme_settings_the_hidden_input' ); ?>
					<input type="submit" name="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Changes', 'alpaca' ); ?>" />
				</form>
			</div> <?php
		}
		/**
		* Render panels for theme option
		*/
		public function render_theme_settings_panel() {
			$panels = apply_filters( 'alpaca_admin_theme_settings_get_panels', array() );
			if ( alpaca_is_valid_array( $panels ) ) {
				foreach( $panels as $id => $panel ) :
					if ( alpaca_is_callback_valid( $panel['callback_func'] ) ) : ?>
						<div id="<?php echo esc_attr( $id ); ?>" class="alpaca-panel">
							<div class="alpaca-panel-content">
								<?php if ( ! empty( $panel['title'] ) ) : ?>
								<h2><?php echo esc_html( $panel['title'] ); ?></h2><hr>
								<?php endif; ?>
								<div class="alpaca-panel-column-container">
									<?php call_user_func( $panel['callback_func'], $panel ); ?>
								</div>
							</div>
						</div> <?php
					endif;
				endforeach;
			}
		}
		/**
		* Render widgets for theme option
		*/
		public function render_theme_settings_widget() {
			$widgets = apply_filters( 'alpaca_admin_theme_settings_get_widgets', array() );
			if ( alpaca_is_valid_array( $widgets ) ) { ?>
				<div id="dashboard-widgets-wrap">
					<div id="dashboard-widgets" class="metabox-holder"> <?php
					foreach( $widgets as $id => $widget ) :
						if ( alpaca_is_callback_valid( $widget['callback_func'] ) ) :
							$title = empty( $widget['title'] ) ? '' : $widget['title']; ?>
							<div id="<?php echo esc_attr( $id ); ?>" class="postbox-container">
								<div class="meta-box-sortables">
									<div id="dashboard_right_now" class="postbox">
										<button type="button" class="handlediv" aria-expanded="true">
											<span class="screen-reader-text"><?php esc_html_e( 'Toggle panel:', 'alpaca' ); ?> <?php echo esc_html( $title ); ?></span>
										</button>
										<h2 class="hndle ui-sortable-handle">
											<span><?php echo esc_html( $title ); ?></span>
										</h2>
										<div class="inside">
											<div class="main">
												<?php call_user_func( $widget['callback_func'], $widget ); ?>
											</div>
										</div>
									</div>
								</div>
							</div> <?php
						endif;
					endforeach; ?>
					</div>
				</div> <?php
			}
		}
		/**
		* Output hidden inputs
		*/
		public function hidden_inputs() { ?>
			<input type="hidden" name="alpaca_theme_settings_nonce" value="<?php echo esc_attr( wp_create_nonce( 'alpaca-theme-settings-nonce' ) ); ?>" />
			<input type="hidden" name="alpaca_create_timestamp" value="<?php echo esc_attr( time() ); ?>" /><?php
		}
        /**
        * Enqueue assets
        */
        public function enqueue_assets() {
			if ( current_user_can( 'manage_options' ) && isset( $_GET['page'] ) && ( 'alpaca-theme-settings' == sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) ) {
				$suffix = alpaca_get_assets_suffix();
				wp_enqueue_style( 'alpaca-welcome', ALPACA_ASSETS_URI . 'styles/admin/welcome' . $suffix . '.css', array(), ALPACA_ASSETS_VERSION );
			}
		}
	}
	new Alpaca_Theme_Settings();
}
