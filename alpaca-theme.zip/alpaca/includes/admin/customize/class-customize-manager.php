<?php
/**
* Theme customize manager class
*	and theme own customize section/controls/sanitize;
*/

if ( ! class_exists( 'Alpaca_Customize_Manager' ) ) {
	class Alpaca_Customize_Manager {
		/**
		* Object current class instance to make sure only once instance in running
		*/
		public static $instance = false;
		/**
		* Construct function
		*/
		public function __construct() {
			$this->includes(); // Import theme customize option configs
		}
		/**
		* Load customize related classes
		*/
		public function load_dependency() {
			// Include the abstract class
			require_once ALPACA_THEME_INC . 'abstracts/class-abstract-customize-configuration-base.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'admin/customize/class-customize-control.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'admin/customize/class-customize-setting.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

			if ( ! empty( $_REQUEST['customize_changeset_uuid'] ) ) {
				require_once ALPACA_THEME_INC . 'utils/class-utils-sanitize.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			}
		}
		/**
		* Import the required files
		*/
		private function includes() {
			$configs_dir = ALPACA_THEME_INC . 'admin/customize/configs/';

			$this->load_dependency();

			require_once $configs_dir . 'site-identity.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'general.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'site-header.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'fullscreen-menu.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'site-footer.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'site-sidebar.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'home-page.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'archive-pages.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'single-post.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'typography.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'advertisement.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . '404-page.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'popup-signup-form.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once $configs_dir . 'woocommerce.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
		/**
		* Instance Loader class
		*	there can only be one instance of loader
		* @return class Loader
		*/
		public static function _instance() {
			if ( false === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
	}
	add_action( 'init', 'Alpaca_Customize_Manager::_instance' );
}
