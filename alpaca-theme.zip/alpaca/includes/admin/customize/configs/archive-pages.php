<?php
/**
* Customize section archive_pages configuration files.
*/


if ( ! class_exists( 'Alpaca_Customize_Archive_Pages' ) ) {
	class Alpaca_Customize_Archive_Pages extends Alpaca_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$sections = array(
				'category' => array(
					'title' => esc_html__( 'Category', 'alpaca' ),
					'description' => esc_html__( 'For instant previews while customizing, please go to a category archive page.', 'alpaca' )
				),
				'tag' => array(
					'title' => esc_html__( 'Tag', 'alpaca' ),
					'description' => esc_html__( 'For instant previews while customizing, please go to a tag archive page.', 'alpaca' )
				),
				'author' => array(
					'title' => esc_html__( 'Author', 'alpaca' ),
					'description' => esc_html__( 'For instant previews while customizing, please go to an author\'s archive page.', 'alpaca' )
				),
				'search' => array(
					'title' => esc_html__( 'Search', 'alpaca' ),
					'description' => esc_html__( 'For instant previews while customizing, please go to search result page.', 'alpaca' )
				),
				'date' => array(
					'title' => esc_html__( 'Date Based', 'alpaca' ),
					'description' => esc_html__( 'For instant previews while customizing, please go to a date-based archive page.', 'alpaca' )
				)
			);
			if ( alpaca_is_static_blog_page() ) {
				$sections = array_merge(
					array_slice( $sections, 0, 1 ),
					array( 'blog' => array(
						'title' => esc_html__( 'Blog', 'alpaca' ),
						'description' => esc_html__( 'For instant previews while customizing, please go to blog page.', 'alpaca' )
					) ),
					array_slice( $sections, 1 )
				);
			}

			$wp_customize->add_panel( new WP_Customize_Panel( $wp_customize, 'alpaca_panel_archive_pages', array(
				'title' 	=> esc_html__( 'Archive Pages', 'alpaca' ),
				'priority' 	=> 40
			) ) );

			foreach ( $sections as $id => $attrs ) {
				$section_id = 'alpaca_archive_pages_section_' . $id;
				$wp_customize->add_section( $section_id, array(
					'title' 		=> $attrs['title'],
					'panel' 		=> 'alpaca_panel_archive_pages',
					'description'	=> $attrs['description']
				) );
				$this->register_list_settings( $wp_customize, $id, $section_id );
			}
		}
	}
	new Alpaca_Customize_Archive_Pages();
}
