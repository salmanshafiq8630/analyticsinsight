<?php
/**
* Customize section home page configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Homepage' ) ) {
	class Alpaca_Customize_Homepage extends Alpaca_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_homepage';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Boolean if theme extension exists
		*/
		public $is_extension_exists = false;
		/**
		* Test if currently on builder homepage
		* @return boolean
		*/
		public function is_builder_homepage() {
			$front_page_id 		= get_option( 'page_on_front' );
			$posts_page_id 		= get_option( 'page_for_posts' );
			$is_static_page 	= ( 'page' == get_option( 'show_on_front' ) );
			$is_static_front   	= $is_static_page && ! empty( $front_page_id );
			$is_static_blog 	= $is_static_page && empty( $front_page_id ) && ! empty( $posts_page_id );
			$is_from_customize 	= apply_filters( 'loftocean_homepage_builder_is_content_from_builder', false );
			return ( $is_static_front && $is_from_customize ) || ! $is_static_page || $is_static_blog;
		}
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;
			$this->is_extension_exists = alpaca_is_extension_activated();
			$this->is_mc4wp_exists = function_exists( 'mc4wp_show_form' );
			$this->add_panel( $wp_customize );
			$this->home_widgets( $wp_customize );
			$this->main_content( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$panel_description = sprintf(
				/* translators: %1$s: html tag start. %2$s: html tag end */
				esc_html__( 'For static front page, the sections "Fullwidth Featured Area" and "Home Main Content Area" only work when choosing the content from "Customize". You can %1$sclick here%2$s to change the setting.', 'alpaca' ),
				'<a href="#" data-control-id="alpaca_static_homepage_content" class="show-control">',
				'</a>'
			);
			// Panel
			$wp_customize->add_panel( new WP_Customize_Panel( $wp_customize, $this->panel_id, array(
				'title' 		=> esc_html__( 'Home Page', 'alpaca' ),
				'priority' 		=> 35,
				'description' 	=> $panel_description
			) ) );
		}
		/**
		* Modify content settings before main content
		*/
		protected function home_widgets( $wp_customize ){
			if ( $this->is_extension_exists ) {
				$sections = array( 'loftocean_homepage_widget_section1' => 100, 'loftocean_homepage_widget_section2' => 200 );
				foreach ( $sections as $id => $priority ) {
					$section = $wp_customize->get_section( $id );
					if ( ! empty( $section ) && ( $section instanceof WP_Customize_Section ) ) {
						$section->panel = $this->panel_id;
						$section->priority = $priority;
					}
				}
			}
		}
		/**
		* Add main content settings
		*/
		protected function main_content( $wp_customize ) {
			global $alpaca_default_settings;
			$section_id = 'alpaca_homepage_section_main_content';
			$wp_customize->add_section( $section_id, array(
				'title' 			=> esc_html__( 'Latest Posts Area', 'alpaca' ),
				'panel' 			=> $this->panel_id,
				'priority' 			=> 150,
				'active_callback'	=> array( $this, 'is_builder_homepage' )
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_home_section_title', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_home_section_title'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_text_field'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_home_section_sub_title', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_home_section_sub_title'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_text_field'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_home_section_title', array(
				'type' 		=> 'text',
				'label' 	=> esc_html__( 'Section Title', 'alpaca' ),
				'section' 	=> $section_id,
				'settings' 	=> 'alpaca_archive_page_home_section_title'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_home_section_sub_title', array(
				'type' 		=> 'text',
				'label' 	=> esc_html__( 'Sub title / Description', 'alpaca' ),
				'section' 	=> $section_id,
				'settings' 	=> 'alpaca_archive_page_home_section_sub_title'
			) ) );

			$this->register_list_settings( $wp_customize, 'home', $section_id );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_archive_page_home_hide_main_section', array(
				'default'   		=> $alpaca_default_settings['alpaca_archive_page_home_hide_main_section'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_archive_page_home_hide_main_section', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 	=> esc_html__( 'Hide Latest Posts Section', 'alpaca' ),
				'section' 	=> $section_id,
				'settings' 	=> 'alpaca_archive_page_home_hide_main_section'
			) ) );
		}
	}
	new Alpaca_Customize_Homepage();
}
