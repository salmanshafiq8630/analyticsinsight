<?php
/**
* Customize panel sidebar configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Site_Sidebar' ) ) {
	class Alpaca_Customize_Site_Sidebar extends Alpaca_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;

			$wp_customize->add_section( 'alpaca_section_site_sidebar', array(
				'title'    => esc_html__( 'Sidebar', 'alpaca' ),
				'priority' => 30
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_sidebar_enable_sticky', array(
				'default'   		=> $alpaca_default_settings['alpaca_sidebar_enable_sticky'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_sidebar_enable_sticky', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Enable Sticky Sidebar', 'alpaca' ),
				'description' 	=> esc_html__( 'Only works when sidebar is shorter than content area and when screen width is larger than 1120 px.', 'alpaca' ),
				'section' 		=> 'alpaca_section_site_sidebar',
				'settings' 		=> 'alpaca_sidebar_enable_sticky'
			) ) );
		}
	}
	new Alpaca_Customize_Site_Sidebar();
}
