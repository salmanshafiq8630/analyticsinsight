<?php
/**
* Customize section single post configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Posts' ) ) {
	class Alpaca_Customize_Posts extends Alpaca_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_single_post';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Boolean if theme extension exists
		*/
		public $is_extension_exists = false;
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;
			$this->is_extension_exists = alpaca_is_extension_activated();

			$this->add_panel( $wp_customize );
			$this->add_section_post( $wp_customize );
			$this->add_section_after_post( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'    => esc_html__( 'Single Post', 'alpaca' ),
				'priority' => 45
			) );
		}
		/**
		* Register section post
		*/
		protected function add_section_post( $wp_customize ) {
			$defaults = $this->defaults;
			$is_extension_exists = $this->is_extension_exists;

			$wp_customize->add_section( 'alpaca_single_post_section_post', array(
				'title' => esc_html__( 'Post', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_single_post_default_template', array(
				'default'   		=> $defaults['alpaca_single_post_default_template'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_default_page_layout', array(
				'default'   		=> $defaults['alpaca_single_post_default_page_layout'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_single_post_default_template' => array( 'value' => array( 'post-template-split' ), 'operator' => 'not in' )
				)
			) ) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_header_meta_group', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_footer_meta_group', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_mobile_enable_large_post_header', array(
				'default'   		=> $defaults['alpaca_single_post_mobile_enable_large_post_header'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			if ( $is_extension_exists ) {
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_social_bar', array(
					'default'   		=> $defaults['alpaca_single_post_show_social_bar'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_sticky_social_bar', array(
					'default'   		=> $defaults['alpaca_single_post_show_sticky_social_bar'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
				) ) );
			}

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_reading_progress_bar', array(
				'default'   		=> $defaults['alpaca_single_post_show_reading_progress_bar'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_default_template', array(
				'type' 		=> 'radio',
				'label' 	=> esc_html__( 'Default Post Template', 'alpaca' ),
				'settings'	=> 'alpaca_single_post_default_template',
				'section'	=> 'alpaca_single_post_section_post',
				'choices' 	=> array(
					'post-template-split' 				=> esc_html__( 'Split Template', 'alpaca' ),
					'post-template-wide-header-img' 	=> esc_html__( 'Wide Header Image', 'alpaca' ),
					'post-template-wide-overlay-header' => esc_html__( 'Overlay Header', 'alpaca' ),
					'post-template-normal' 				=> esc_html__( 'Normal Template', 'alpaca' ),
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_default_page_layout', array(
				'type' 				=> 'radio',
				'label' 			=> esc_html__( 'Default Sidebar Layout', 'alpaca' ),
				'settings'			=> 'alpaca_single_post_default_page_layout',
				'section'			=> 'alpaca_single_post_section_post',
				'active_callback'	=> array( $this, 'customize_control_active_cb' ),
				'choices' 			=> array(
					'' 						=> esc_html__( 'No sidebar', 'alpaca' ),
					'with-sidebar-left' 	=> esc_html__( 'Left sidebar', 'alpaca' ),
					'with-sidebar-right'	=> esc_html__( 'Right sidebar', 'alpaca' )
				)
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_header_meta_group', array(
				'type' 			=> 'multiple_checkbox',
				'label' 		=> esc_html__( 'Header Meta', 'alpaca' ),
				'description' 	=> esc_html__( 'Display selected meta in post header', 'alpaca' ),
				'section'		=> 'alpaca_single_post_section_post',
				'settings' 		=> 'alpaca_single_post_header_meta_group',
				'choices'		=> $this->get_header_meta_settings( $wp_customize )
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_footer_meta_group', array(
				'type' 		=> 'multiple_checkbox',
				'label' 	=> esc_html__( 'Footer Meta', 'alpaca' ),
				'section' 	=> 'alpaca_single_post_section_post',
				'settings' 	=> 'alpaca_single_post_footer_meta_group',
				'choices'	=> $this->get_footer_meta_settings( $wp_customize )
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_mobile_enable_large_post_header', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Enable "Large Post Header" for "Split Template" on Mobile Devices', 'alpaca' ),
				'section' 		=> 'alpaca_single_post_section_post',
				'settings' 		=> 'alpaca_single_post_mobile_enable_large_post_header'
			) ) );

			if ( $is_extension_exists ) {
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_social_bar', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Show Social Media Sharing Buttons after Post Content', 'alpaca' ),
					'section' 		=> 'alpaca_single_post_section_post',
					'settings' 		=> 'alpaca_single_post_show_social_bar'
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_sticky_social_bar', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Show Sticky Social Media Sharing Bar', 'alpaca' ),
					'section' 		=> 'alpaca_single_post_section_post',
					'settings' 		=> 'alpaca_single_post_show_sticky_social_bar'
				) ) );
			}

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_reading_progress_bar', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Show Reading Progress Bar', 'alpaca' ),
				'section' 		=> 'alpaca_single_post_section_post',
				'settings' 		=> 'alpaca_single_post_show_reading_progress_bar'
			) ) );
		}
		/**
		* Register section after post
		*/
		protected function add_section_after_post( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_single_post_section_after_post', array(
				'title' => esc_html__( 'After the Post', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			if ( alpaca_is_mc4wp_activated() ) {
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_signup_form_group', array(
					'default'   		=> '',
					'transport' 		=> 'postMessage',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_signup_form', array(
					'default'   		=> $defaults['alpaca_single_post_show_signup_form'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_signup_form_id', array(
					'default'   		=> $defaults['alpaca_single_post_signup_form_id'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint',
					'dependency'		=> array(
						'alpaca_single_post_show_signup_form' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_signup_form_color_scheme', array(
					'default'   		=> $defaults['alpaca_single_post_signup_form_color_scheme'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
					'dependency'		=> array(
						'alpaca_single_post_show_signup_form' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_signup_form_bg_image', array(
					'default'   		=> $defaults['alpaca_single_post_signup_form_bg_image'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint',
					'dependency'		=> array(
						'alpaca_single_post_show_signup_form' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_signup_form_enable_color_overlay', array(
					'default'   		=> $defaults['alpaca_single_post_signup_form_enable_color_overlay'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
					'dependency'		=> array(
						'alpaca_single_post_show_signup_form' => array( 'value' => array( 'on' ) )
					)
				) ) );
			}

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_author_info_box', array(
				'default'   		=> $defaults['alpaca_single_post_show_author_info_box'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_pagination', array(
				'default'   		=> $defaults['alpaca_single_post_show_pagination'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_related_post_group', array(
				'default'   		=> '',
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_show_related_posts', array(
				'default'   		=> $defaults['alpaca_single_post_show_related_posts'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_related_post_section_title', array(
				'default'   		=> $defaults['alpaca_single_post_related_post_section_title'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_text_field',
				'dependency'		=> array(
					'alpaca_single_post_show_related_posts' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_related_post_filter', array(
				'default'   		=> $defaults['alpaca_single_post_related_post_filter'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_single_post_show_related_posts' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_related_post_number', array(
				'default'   		=> $defaults['alpaca_single_post_related_post_number'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_single_post_show_related_posts' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_single_post_related_post_image_ratio', array(
				'default'   		=> $defaults['alpaca_single_post_related_post_image_ratio'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_single_post_show_related_posts' => array( 'value' => array( 'on' ) )
				)
			) ) );

			if ( alpaca_is_mc4wp_activated() ) {
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_signup_form_group', array(
					'type' 		=> 'group',
					'label' 	=> esc_html__( 'Signup Form', 'alpaca' ),
					'section' 	=> 'alpaca_single_post_section_after_post',
					'settings'	=> 'alpaca_single_post_signup_form_group',
					'children'	=> array(
						new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_signup_form', array(
							'type' 			=> 'checkbox',
							'label_first'	=> true,
							'label' 		=> esc_html__( 'Display Newsletter Signup Form', 'alpaca' ),
							'section' 		=> 'alpaca_single_post_section_after_post',
							'settings'		=> 'alpaca_single_post_show_signup_form'
						) ),
						new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_signup_form_id', array(
							'type' 				=> 'select',
							'label' 			=> esc_html__( 'Choose Form', 'alpaca' ),
							'section' 			=> 'alpaca_single_post_section_after_post',
							'settings' 			=> 'alpaca_single_post_signup_form_id',
							'choices'			=> alpaca_mc4wp_forms(),
							'active_callback' 	=> array( $this, 'customize_control_active_cb' )
						) ),
						new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_signup_form_color_scheme', array(
							'type' 				=> 'select',
							'label' 			=> esc_html__( 'Color Scheme', 'alpaca' ),
							'section' 			=> 'alpaca_single_post_section_after_post',
							'settings' 			=> 'alpaca_single_post_signup_form_color_scheme',
							'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
							'choices' 			=> array(
								'light-color' 	=> esc_html__( 'Light', 'alpaca' ),
								'dark-color'	=> esc_html__( 'Dark', 'alpaca' )
							)
						) ),
						new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_signup_form_bg_image', array(
							'type' 				=> 'image_id',
							'label' 			=> esc_html__( 'Background Image', 'alpaca' ),
							'section' 			=> 'alpaca_single_post_section_after_post',
							'settings' 			=> 'alpaca_single_post_signup_form_bg_image',
							'active_callback' 	=> array( $this, 'customize_control_active_cb' )
						) ),
						new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_signup_form_enable_color_overlay', array(
							'type' 				=> 'checkbox',
							'label_first'		=> true,
							'label' 			=> esc_html__( 'Enable color overlay', 'alpaca' ),
							'description'		=> esc_html__( 'Please note: Color overlay appears after you upload background image.', 'alpaca' ),
							'section' 			=> 'alpaca_single_post_section_after_post',
							'settings'			=> 'alpaca_single_post_signup_form_enable_color_overlay',
							'active_callback' 	=> array( $this, 'customize_control_active_cb' )
						) ),
					)
				) ) );
			}
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_author_info_box', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Display Author Info Box', 'alpaca' ),
				'description'	=> esc_html__( 'Please note: the author\'s biographical info need to have some content, or the author info box will not show.', 'alpaca' ),
				'section' 		=> 'alpaca_single_post_section_after_post',
				'settings' 		=> 'alpaca_single_post_show_author_info_box'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_pagination', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Display Post Pagination', 'alpaca' ),
				'section' 		=> 'alpaca_single_post_section_after_post',
				'settings' 		=> 'alpaca_single_post_show_pagination'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_related_post_group', array(
				'type' 		=> 'group',
				'label' 	=> esc_html__( 'Related Posts', 'alpaca' ),
				'section' 	=> 'alpaca_single_post_section_after_post',
				'settings'	=> 'alpaca_single_post_related_post_group',
				'children'	=> array(
					new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_show_related_posts', array(
						'type' 			=> 'checkbox',
						'label_first'	=> true,
						'label' 		=> esc_html__( 'Display Related Posts', 'alpaca' ),
						'section' 		=> 'alpaca_single_post_section_after_post',
						'settings'		=> 'alpaca_single_post_show_related_posts'
					) ),
					new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_related_post_section_title', array(
						'type' 				=> 'text',
						'label' 			=> esc_html__( 'Related Posts Title', 'alpaca' ),
						'input_attrs' 		=> array( 'placeholder' => esc_html__( 'e.g. Other Posts You May Enjoy', 'alpaca' ) ),
						'section' 			=> 'alpaca_single_post_section_after_post',
						'settings' 			=> 'alpaca_single_post_related_post_section_title',
						'active_callback' 	=> array( $this, 'customize_control_active_cb' )
					) ),
					new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_related_post_filter', array(
						'type' 				=> 'select',
						'label' 			=> esc_html__( 'Pick Posts by', 'alpaca' ),
						'section' 			=> 'alpaca_single_post_section_after_post',
						'settings' 			=> 'alpaca_single_post_related_post_filter',
						'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
						'choices' 			=> array(
							'category' 	=> esc_html__( 'Category', 'alpaca' ),
							'tag'	 	=> esc_html__( 'Tag', 'alpaca' ),
							'author' 	=> esc_html__( 'Author', 'alpaca' )
						)
					) ),
					new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_related_post_number', array(
						'type' 				=> 'select',
						'label' 			=> esc_html__( 'Maximum number of related posts', 'alpaca' ),
						'section' 			=> 'alpaca_single_post_section_after_post',
						'settings' 			=> 'alpaca_single_post_related_post_number',
						'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
						'choices'			=> array(
							'4'		=> esc_html__( '4', 'alpaca' ),
							'8'		=> esc_html__( '8', 'alpaca' ),
							'12'	=> esc_html__( '12', 'alpaca' )
						)
					) ),
					new Alpaca_Customize_Control( $wp_customize, 'alpaca_single_post_related_post_image_ratio', array(
						'type'				=> 'select',
						'label'				=> esc_html__( 'Image Ratio', 'alpaca' ),
						'settings'			=> 'alpaca_single_post_related_post_image_ratio',
						'section'			=> 'alpaca_single_post_section_after_post',
						'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
						'choices'			=> array(
							'img-ratio-3-2' => esc_html__( '3:2', 'alpaca' ),
							'img-ratio-1-1' => esc_html__( '1:1', 'alpaca' ),
							'img-ratio-2-3' => esc_html__( '2:3', 'alpaca' )
						)
					) )
				)
			) ) );
		}
		/**
		* Get header meta settings
		* @param object
		* @return array
		*/
		protected function get_header_meta_settings( $wp_customize ) {
			$settings = array();
			$metas = array(
				'category' 			=> esc_html__( 'Categories', 'alpaca' ),
				'author' 			=> esc_html__( 'Author', 'alpaca' ),
				'date' 				=> esc_html__( 'Publish Date', 'alpaca' ),
				'update_date'		=> esc_html__( 'Update Date', 'alpaca' ),
				'reading_time' 		=> esc_html__( 'Reading Time', 'alpaca' ),
				'manual_excerpt'	=> esc_html__( 'Manual Excerpt', 'alpaca' )
			);
			foreach ( $metas as $id => $title ) {
				$meta_id = 'alpaca_single_post_header_meta_show_' . $id;
				$settings[ $id ] = $this->register_meta_setting( $wp_customize, $meta_id, $id, $title );
			}
			return $settings;
		}
		/**
		* Get footer meta settings
		* @param object
		* @return array
		*/
		protected function get_footer_meta_settings( $wp_customize ) {
			$settings = array();
			$is_extension_exists = $this->is_extension_exists;
			$from_extension = array( 'view_counts', 'like_counts' );
			$metas = array(
				'view_counts' 		=> esc_html__( 'View Counts', 'alpaca' ),
				'like_counts' 		=> esc_html__( 'Like Counts', 'alpaca' ),
				'comment_counts' 	=> esc_html__( 'Comment Counts', 'alpaca' )
			);
			foreach ( $metas as $id => $title ) {
				$meta_id = 'alpaca_single_post_footer_meta_show_' . $id;
				if ( ! in_array( $id, $from_extension ) || $is_extension_exists ) {
					$settings[ $id] = $this->register_meta_setting( $wp_customize, $meta_id, $id, $title );
				}
			}
			return $settings;
		}
		/**
		* Register meta customize setting and return customize control
		* @param object
		* @param string meta id
		* @param string control id
		* @return object
		*/
		protected function register_meta_setting( $wp_customize, $meta_id, $control_id, $title ) {
			$defaults = $this->defaults;
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, $meta_id, array(
				'default'			=> $defaults[ $meta_id ],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			return array( 'value' => 'on', 'label' => $title, 'setting' => $meta_id );
		}
	}
	new Alpaca_Customize_Posts();
}
