<?php
/**
* Customize section header configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Popup_Signup_Form' ) ) {
	class Alpaca_Customize_Popup_Signup_Form extends Alpaca_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
            if ( alpaca_is_mc4wp_activated() ) {
                global $alpaca_default_settings;

    			$wp_customize->add_section( 'alpaca_section_popup_signup_form', array(
    				'title'    => esc_html__( 'Popup Signup Form', 'alpaca' ),
    				'priority' => 60
    			) );

				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_auto_display', array(
    				'default'   		=> $alpaca_default_settings['alpaca_popup_signup_form_auto_display'],
    				'transport' 		=> 'postMessage',
    				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
    			) ) );
                $wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_auto_display_once_per_session', array(
                    'default'           => $alpaca_default_settings['alpaca_popup_signup_form_auto_display_once_per_session'],
                    'transport'         => 'postMessage',
                    'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
                    'dependency'        => array(
                        'alpaca_popup_signup_form_auto_display' => array( 'value' => array( 'on' ) )
                    )
                ) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_display_delay', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_display_delay'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'absint',
                    'dependency'        => array(
						'alpaca_popup_signup_form_auto_display' => array( 'value' => array( 'on' ) )
                    )
    			) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_id', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_id'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'absint'
    			) ) );
				$wp_customize->selective_refresh->add_partial( 'alpaca_popup_signup_form_id', array(
					'settings' 				=> array( 'alpaca_popup_signup_form_id', 'alpaca_popup_signup_form_not_distrub_text', 'alpaca_popup_signup_form_exit_message_after_signed' ),
					'selector' 				=> '.popup-signup .widget.widget_mc4wp_form_widget',
					'render_callback' 		=> array( $this, 'show_form' ),
					'container_inclusive' 	=> true,
				) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_not_distrub_text', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_not_distrub_text'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'sanitize_text_field',
                    'dependency'        => array(
						'alpaca_popup_signup_form_auto_display' => array( 'value' => array( 'on' ) )
                    )
    			) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_exit_message_after_signed', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_exit_message_after_signed'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'sanitize_text_field'
    			) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_color_scheme', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_color_scheme'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
    			) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_light_color_background_color', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_light_color_background_color'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'sanitize_hex_color'
    			) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_dark_color_background_color', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_dark_color_background_color'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'sanitize_hex_color'
    			) ) );
    			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_popup_signup_form_image', array(
    				'default'			=> $alpaca_default_settings['alpaca_popup_signup_form_image'],
    				'transport'			=> 'postMessage',
    				'sanitize_callback' => 'absint'
    			) ) );

				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_auto_display', array(
    				'type'			=> 'checkbox',
    				'label_first' 	=> true,
    				'label'			=> esc_html__( 'Enable Auto Display', 'alpaca' ),
    				'section'		=> 'alpaca_section_popup_signup_form',
    				'settings'		=> 'alpaca_popup_signup_form_auto_display'
    			) ) );
                $wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_auto_display_once_per_session', array(
                    'type'              => 'checkbox',
                    'label_first'       => true,
                    'label'             => esc_html__( 'Show Auto Display Popup Signup Form Once Per Session', 'alpaca' ),
                    'section'           => 'alpaca_section_popup_signup_form',
                    'settings'          => 'alpaca_popup_signup_form_auto_display_once_per_session',
                    'active_callback'   => array( $this, 'customize_control_active_cb' )
                ) ) );
    			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_display_delay', array(
    				'type'              => 'select',
    				'label'             => esc_html__( 'Display', 'alpaca' ),
    				'section'           => 'alpaca_section_popup_signup_form',
    				'settings' 	        => 'alpaca_popup_signup_form_display_delay',
    				'active_callback'	=> array( $this, 'customize_control_active_cb' ),
    				'choices'           => array(
                        '0'		=> esc_html__( 'Immediately', 'alpaca' ),
                        '5'     => esc_html__( 'After 5 seconds', 'alpaca' ),
                        '10'    => esc_html__( 'After 10 seconds', 'alpaca' ),
                        '15'    => esc_html__( 'After 15 seconds', 'alpaca' ),
                        '20'    => esc_html__( 'After 20 seconds', 'alpaca' )
                    )
    			) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_id', array(
    				'type'		=> 'select',
    				'label'		=> esc_html__( 'Choose Form', 'alpaca' ),
    				'section'	=> 'alpaca_section_popup_signup_form',
    				'settings'	=> 'alpaca_popup_signup_form_id',
    				'choices'	=> alpaca_mc4wp_forms()
    			) ) );
    			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_not_distrub_text', array(
    				'type'				=> 'text',
    				'label'				=> esc_html__( 'Close & Prevent the Popup Text', 'alpaca' ),
    				'section'			=> 'alpaca_section_popup_signup_form',
    				'settings'			=> 'alpaca_popup_signup_form_not_distrub_text',
    				'active_callback'	=> array( $this, 'customize_control_active_cb' )
    			) ) );
    			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_exit_message_after_signed', array(
    				'type'		=> 'text',
    				'label' 	=> esc_html__( 'Exit message after reader signed up', 'alpaca' ),
    				'section'  	=> 'alpaca_section_popup_signup_form',
    				'settings'	=> 'alpaca_popup_signup_form_exit_message_after_signed'
    			) ) );
    			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_color_scheme', array(
    				'type'		=> 'select',
    				'label'		=> esc_html__( 'Color Scheme', 'alpaca' ),
    				'section'	=> 'alpaca_section_popup_signup_form',
    				'settings'	=> 'alpaca_popup_signup_form_color_scheme',
    				'choices'	=> array(
                        'light-color' => esc_html__( 'Light', 'alpaca' ),
                        'dark-color'  => esc_html__( 'Dark', 'alpaca' )
                    )
    			) ) );
    			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_popup_signup_form_light_color_background_color', array(
    				'label'		=> esc_html__( 'Light Scheme Background Color', 'alpaca' ),
    				'section'	=> 'alpaca_section_popup_signup_form',
    				'settings'	=> 'alpaca_popup_signup_form_light_color_background_color'
    			) ) );
    			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_popup_signup_form_dark_color_background_color', array(
    				'label'		=> esc_html__( 'Dark Scheme Background Color', 'alpaca' ),
    				'section'	=> 'alpaca_section_popup_signup_form',
    				'settings'	=> 'alpaca_popup_signup_form_dark_color_background_color'
    			) ) );
    			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_popup_signup_form_image', array(
    				'type'		=> 'image_id',
    				'label'		=> esc_html__( 'Image', 'alpaca' ),
    				'section'	=> 'alpaca_section_popup_signup_form',
    				'settings' 	=> 'alpaca_popup_signup_form_image'
    			) ) );
            }
        }
		/**
		* Sanitize function for popup signup form additional text
		*/
		public function sanitize_page_message( $text ) {
			if ( empty( $text ) ) {
				return '';
			} else {
				return wp_kses( $text, array(
					'b' => array(),
					'i' => array(),
					'br' => array(),
					'a' => array( 'href' => array(), 'class' => array(), 'id' => array(), 'target' => array(), 'title' => array() )
				) );
			}
		}
		/**
		* Show popup signup form
		*/
		public function show_form() {
			$form_id = alpaca_get_theme_mod( 'alpaca_popup_signup_form_id' );
			$form_exists = alpaca_is_item_exists( $form_id );
			$form = $form_exists ? get_post( $form_id ) : '';
			$form_title = $form_exists ? $form->post_title : ''; ?>

			<div class="widget widget_mc4wp_form_widget"><?php
				if ( ! empty( $form_title ) ) : ?>
					<h5 class="widget-title"><?php echo esc_html( $form_title ); ?></h5><?php
				endif;
				if ( $form_exists ) {
					mc4wp_show_form( $form_id );
				} ?>
			</div><?php
		}
	}
	new Alpaca_Customize_Popup_Signup_Form();
}
