<?php
/**
* Customize panel fullscreen menu configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Fullscreen_Menu' ) ) {
	class Alpaca_Customize_Fullscreen_Menu extends Alpaca_Customize_Configuration_Base {
		protected $panel_id = 'alpaca_panel_fullscreen_menu';
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			$this->add_panel( $wp_customize );
			$this->add_section_main_area( $wp_customize );
			$this->add_section_widget_area( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'		=> esc_html__( 'Fullscreen Menu', 'alpaca' ),
				'priority' 	=> 15
			) );
		}
		/**
		* Register section main area
		*/
		protected function add_section_main_area( $wp_customize ) {
			global $alpaca_default_settings;
			$section_id = 'alpaca_section_fullscreen_menu_menu_area';

			$wp_customize->add_section( $section_id, array(
				'title'	=> esc_html__( 'Menu Area', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_color_scheme', array(
				'default'			=> $alpaca_default_settings['alpaca_fullscreen_menu_color_scheme'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_background_image', array(
				'default'   		=> $alpaca_default_settings['alpaca_fullscreen_menu_background_image'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_enable_overlay', array(
				'default'   		=> $alpaca_default_settings['alpaca_fullscreen_menu_enable_overlay'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
				'dependency'		=> array(
					'alpaca_fullscreen_menu_background_image' => array( 'value' => array( '', 0, '0' ), 'operator' => 'not in' )
				)
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_background_color', array(
				'default'  			=> $alpaca_default_settings['alpaca_fullscreen_menu_background_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_text_color', array(
				'default'  			=> $alpaca_default_settings['alpaca_fullscreen_menu_text_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_show_search_form', array(
				'default'   		=> $alpaca_default_settings['alpaca_fullscreen_menu_show_search_form'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_copyright_text', array(
				'default'   		=> $alpaca_default_settings['alpaca_fullscreen_menu_copyright_text'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_html'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_fullscreen_menu_color_scheme', array(
				'type'		=> 'select',
				'label'		=> esc_html__( 'Color Scheme', 'alpaca' ),
				'section'	=> $section_id,
				'settings'	=> 'alpaca_fullscreen_menu_color_scheme',
				'choices'	=> array(
					'light-color' => esc_html__( 'Light', 'alpaca' ),
					'dark-color'  => esc_html__( 'Dark', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_fullscreen_menu_background_image', array(
				'type' 		=> 'image_id',
				'label' 	=> esc_html__( 'Background Image', 'alpaca' ),
				'section' 	=> $section_id,
				'settings' 	=> 'alpaca_fullscreen_menu_background_image'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_fullscreen_menu_enable_overlay', array(
				'type' 				=> 'checkbox',
				'label_first'		=> true,
				'label' 			=> esc_html__( 'Enable overlay', 'alpaca' ),
				'section' 			=> $section_id,
				'settings' 			=> 'alpaca_fullscreen_menu_enable_overlay',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control(new WP_Customize_Color_Control( $wp_customize, 'alpaca_fullscreen_menu_background_color', array(
				'label' 	=> esc_html__( 'Background Color', 'alpaca' ),
				'section'  	=> $section_id,
				'settings' 	=> 'alpaca_fullscreen_menu_background_color'
			) ) );
			$wp_customize->add_control(new WP_Customize_Color_Control( $wp_customize, 'alpaca_fullscreen_menu_text_color', array(
				'label' 	=> esc_html__( 'Text Color', 'alpaca' ),
				'section'  	=> $section_id,
				'settings' 	=> 'alpaca_fullscreen_menu_text_color'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_fullscreen_menu_show_search_form', array(
				'type'			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Search Form', 'alpaca' ),
				'section'  		=> $section_id,
				'settings' 		=> 'alpaca_fullscreen_menu_show_search_form'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_fullscreen_menu_copyright_text', array(
				'type'		=> 'textarea',
				'label' 	=> esc_html__( 'Copyright Text', 'alpaca' ),
				'section'  	=> $section_id,
				'settings' 	=> 'alpaca_fullscreen_menu_copyright_text'
			) ) );
		}
		/**
		* Register section widget area
		*/
		protected function add_section_widget_area( $wp_customize ) {
			global $alpaca_default_settings;
			$section_id = 'alpaca_section_fullscreen_menu_widget_area';

			$wp_customize->add_section( $section_id, array(
				'title'	=> esc_html__( 'Widget Area', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_widgets_color_scheme', array(
				'default'			=> $alpaca_default_settings['alpaca_fullscreen_menu_widgets_color_scheme'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_widgets_background_color', array(
				'default'  			=> $alpaca_default_settings['alpaca_fullscreen_menu_widgets_background_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting(new WP_Customize_Setting( $wp_customize, 'alpaca_fullscreen_menu_widgets_text_color', array(
				'default'   		=> $alpaca_default_settings['alpaca_fullscreen_menu_widgets_text_color'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_fullscreen_menu_widgets_color_scheme', array(
				'type'		=> 'select',
				'label'		=> esc_html__( 'Widget Area Color Scheme', 'alpaca' ),
				'section'	=> $section_id,
				'settings'	=> 'alpaca_fullscreen_menu_widgets_color_scheme',
				'choices'	=> array(
					'light-color' => esc_html__( 'Light', 'alpaca' ),
					'dark-color'  => esc_html__( 'Dark', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control(new WP_Customize_Color_Control( $wp_customize, 'alpaca_fullscreen_menu_widgets_background_color', array(
				'label' 	=> esc_html__( 'Widget Area Background Color', 'alpaca' ),
				'section'  	=> $section_id,
				'settings' 	=> 'alpaca_fullscreen_menu_widgets_background_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_fullscreen_menu_widgets_text_color', array(
				'label' 	=> esc_html__( 'Widget Area Text Color', 'alpaca' ),
				'section'  	=> $section_id,
				'settings' 	=> 'alpaca_fullscreen_menu_widgets_text_color'
			) ) );
		}
	}
	new Alpaca_Customize_Fullscreen_Menu();
}
