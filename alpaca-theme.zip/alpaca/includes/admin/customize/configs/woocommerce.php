<?php
/**
* Customize section woocommerce configuration file.
*/

if ( ! class_exists( 'Alpaca_Customize_WooCommerce' ) && alpaca_is_woocommerce_activated() ) {
	class Alpaca_Customize_WooCommerce extends Alpaca_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;

            $wp_customize->add_section( 'alpaca_section_woocommerce_sidebar', array(
				'title'	=> esc_html__( 'Sidebar Options', 'alpaca' ),
				'priority' => 999,
                'panel' => 'woocommerce'
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_shop_archive_sidebar', array(
				'default'   		=> $alpaca_default_settings['alpaca_shop_archive_sidebar'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_shop_single_sidebar', array(
				'default'   		=> $alpaca_default_settings['alpaca_shop_single_sidebar'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
			) ) );

            $wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_shop_archive_sidebar', array(
				'type' 		=> 'radio',
				'label' 	=> esc_html__( 'Product Archive Page Sidebar Layout', 'alpaca' ),
				'section'   => 'alpaca_section_woocommerce_sidebar',
				'settings'  => 'alpaca_shop_archive_sidebar',
				'choices'   => array(
					'' 						=> esc_html__( 'No Sidebar', 'alpaca' ),
					'with-sidebar-left' 	=> esc_html__( 'Left Sidebar', 'alpaca' ),
					'with-sidebar-right' 	=> esc_html__( 'Right Sidebar', 'alpaca' )
				)
			) ) );
            $wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_shop_single_sidebar', array(
				'type' 		=> 'radio',
				'label' 	=> esc_html__( 'Single Product Page Sidebar Layout', 'alpaca' ),
				'section' 	=> 'alpaca_section_woocommerce_sidebar',
				'settings' 	=> 'alpaca_shop_single_sidebar',
				'choices' 	=> array(
					'' 						=> esc_html__( 'No Sidebar', 'alpaca' ),
					'with-sidebar-left' 	=> esc_html__( 'Left Sidebar', 'alpaca' ),
					'with-sidebar-right' 	=> esc_html__( 'Right Sidebar', 'alpaca' )
				)
			) ) );
		}
	}
	new Alpaca_Customize_WooCommerce();
}
