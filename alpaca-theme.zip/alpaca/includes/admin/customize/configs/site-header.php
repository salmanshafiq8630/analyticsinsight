<?php
/**
* Customize section header configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Site_Header' ) ) {
	class Alpaca_Customize_Site_Header extends Alpaca_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_site_header';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;

			$this->add_panel( $wp_customize );
			$this->add_section_layout( $wp_customize );
			$this->add_section_logos( $wp_customize );
			$this->add_section_social_menu( $wp_customize );
			$this->add_section_colors( $wp_customize );
			$this->add_section_more( $wp_customize );
			$this->add_section_fullscreen_search( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'    => esc_html__( 'Site Header', 'alpaca' ),
				'priority' => 10
			) );
		}
		/**
		* Register section layouts
		*/
		protected function add_section_layout( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_site_header_section_layout', array(
				'title'	=> esc_html__( 'Header Layout', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_header_layout', array(
				'default'   		=> $defaults['alpaca_site_header_layout'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_layout', array(
				'type' 		=> 'radio',
				'with_bg'	=> true,
				'wrap_id'	=> 'alpaca_header_style',
				'label' 	=> esc_html__( 'Site Header Layout', 'alpaca' ),
				'section' 	=> 'alpaca_site_header_section_layout',
				'settings' 	=> 'alpaca_site_header_layout',
				'choices' 	=> array(
					'vertical-bar' 	=> esc_html__( 'Vertical Bar', 'alpaca' ),
					'vertical-wide' => esc_html__( 'Vertical Wide', 'alpaca' ),
					'horizontal-1' 	=> esc_html__( 'Horizontal 1', 'alpaca' ),
					'horizontal-2' 	=> esc_html__( 'Horizontal 2', 'alpaca' ),
					'horizontal-3' 	=> esc_html__( 'Horizontal 3', 'alpaca' ),
					'horizontal-4' 	=> esc_html__( 'Horizontal 4', 'alpaca' )
				)
			) ) );
		}
		/**
		* Register section logos
		*/
		protected function add_section_logos( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_site_header_section_logos', array(
				'title'	=> esc_html__( 'Logo Image', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_logo_desktop_width', array(
				'default'   		=> $defaults['alpaca_site_header_logo_desktop_width'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_logo_mobile_width', array(
				'default'   		=> $defaults['alpaca_site_header_logo_mobile_width'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_logo_description', array(
				'default'   		=> $defaults['alpaca_site_header_light_desktop_logo'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_light_desktop_logo', array(
				'default'   		=> $defaults['alpaca_site_header_light_desktop_logo'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_dark_desktop_logo', array(
				'default'   		=> $defaults['alpaca_site_header_dark_desktop_logo'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_light_mobile_logo', array(
				'default'   		=> $defaults['alpaca_site_header_light_mobile_logo'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_dark_mobile_logo', array(
				'default'   		=> $defaults['alpaca_site_header_dark_mobile_logo'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );


			if ( ! empty( $wp_customize->selective_refresh ) && ( $wp_customize->selective_refresh instanceof WP_Customize_Selective_Refresh ) ) {
				$wp_customize->get_setting( 'custom_logo' )->transport = 'refresh';
				$wp_customize->selective_refresh->remove_partial( 'custom_logo' );
				$custom_logo = $wp_customize->get_control( 'custom_logo' );
				$custom_logo->section = 'alpaca_site_header_section_logos';
			}
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_logo_desktop_width', array(
				'type' 			=> 'number_with_unit',
				'label' 		=> esc_html__( 'Logo Width - Desktop', 'alpaca' ),
				'after_text' 	=> 'px',
				'section' 		=> 'alpaca_site_header_section_logos',
				'settings' 		=> 'alpaca_site_header_logo_desktop_width'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_logo_mobile_width', array(
				'type' 			=> 'number_with_unit',
				'label' 		=> esc_html__( 'Logo Width - Mobile', 'alpaca' ),
				'after_text' 	=> 'px',
				'section' 		=> 'alpaca_site_header_section_logos',
				'settings' 		=> 'alpaca_site_header_logo_mobile_width'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_logo_description', array(
				'type' 			=> 'notes',
				'description' 	=> esc_html__( 'You can also upload different logo images for light/dark scheme, for desktop and mobile.', 'alpaca' ),
				'section' 		=> 'alpaca_site_header_section_logos',
				'settings' 		=> 'alpaca_site_header_logo_description'
			) ) );

			$custom_logo_args = get_theme_support( 'custom-logo' );
			$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'alpaca_site_header_light_desktop_logo', array(
				'label'         => __( 'Logo for Light Scheme (optional)', 'alpaca' ),
				'section'       => 'alpaca_site_header_section_logos',
				'settings'		=> 'alpaca_site_header_light_desktop_logo',
				'height'        => isset( $custom_logo_args[0]['height'] ) ? $custom_logo_args[0]['height'] : null,
				'width'         => isset( $custom_logo_args[0]['width'] ) ? $custom_logo_args[0]['width'] : null,
				'flex_height'   => isset( $custom_logo_args[0]['flex-height'] ) ? $custom_logo_args[0]['flex-height'] : null,
				'flex_width'    => isset( $custom_logo_args[0]['flex-width'] ) ? $custom_logo_args[0]['flex-width'] : null,
				'button_labels' => array(
					'select'       => esc_html__( 'Select logo', 'alpaca' ),
					'change'       => esc_html__( 'Change logo', 'alpaca' ),
					'remove'       => esc_html__( 'Remove', 'alpaca' ),
					'default'      => esc_html__( 'Default', 'alpaca' ),
					'placeholder'  => esc_html__( 'No logo selected', 'alpaca' ),
					'frame_title'  => esc_html__( 'Select logo', 'alpaca' ),
					'frame_button' => esc_html__( 'Choose logo', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'alpaca_site_header_dark_desktop_logo', array(
				'label'         => __( 'Logo for Dark Scheme (optional)', 'alpaca' ),
				'section'       => 'alpaca_site_header_section_logos',
				'settings'		=> 'alpaca_site_header_dark_desktop_logo',
				'height'        => isset( $custom_logo_args[0]['height'] ) ? $custom_logo_args[0]['height'] : null,
				'width'         => isset( $custom_logo_args[0]['width'] ) ? $custom_logo_args[0]['width'] : null,
				'flex_height'   => isset( $custom_logo_args[0]['flex-height'] ) ? $custom_logo_args[0]['flex-height'] : null,
				'flex_width'    => isset( $custom_logo_args[0]['flex-width'] ) ? $custom_logo_args[0]['flex-width'] : null,
				'button_labels' => array(
					'select'       => esc_html__( 'Select logo', 'alpaca' ),
					'change'       => esc_html__( 'Change logo', 'alpaca' ),
					'remove'       => esc_html__( 'Remove', 'alpaca' ),
					'default'      => esc_html__( 'Default', 'alpaca' ),
					'placeholder'  => esc_html__( 'No logo selected', 'alpaca' ),
					'frame_title'  => esc_html__( 'Select logo', 'alpaca' ),
					'frame_button' => esc_html__( 'Choose logo', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'alpaca_site_header_light_mobile_logo', array(
				'label'         => __( 'Mobile Logo for Light Scheme (optional)', 'alpaca' ),
				'section'       => 'alpaca_site_header_section_logos',
				'settings'		=> 'alpaca_site_header_light_mobile_logo',
				'height'        => isset( $custom_logo_args[0]['height'] ) ? $custom_logo_args[0]['height'] : null,
				'width'         => isset( $custom_logo_args[0]['width'] ) ? $custom_logo_args[0]['width'] : null,
				'flex_height'   => isset( $custom_logo_args[0]['flex-height'] ) ? $custom_logo_args[0]['flex-height'] : null,
				'flex_width'    => isset( $custom_logo_args[0]['flex-width'] ) ? $custom_logo_args[0]['flex-width'] : null,
				'button_labels' => array(
					'select'       => esc_html__( 'Select logo', 'alpaca' ),
					'change'       => esc_html__( 'Change logo', 'alpaca' ),
					'remove'       => esc_html__( 'Remove', 'alpaca' ),
					'default'      => esc_html__( 'Default', 'alpaca' ),
					'placeholder'  => esc_html__( 'No logo selected', 'alpaca' ),
					'frame_title'  => esc_html__( 'Select logo', 'alpaca' ),
					'frame_button' => esc_html__( 'Choose logo', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'alpaca_site_header_dark_mobile_logo', array(
				'label'         => __( 'Mobile Logo for Dark Scheme (optional)', 'alpaca' ),
				'section'       => 'alpaca_site_header_section_logos',
				'settings'		=> 'alpaca_site_header_dark_mobile_logo',
				'height'        => isset( $custom_logo_args[0]['height'] ) ? $custom_logo_args[0]['height'] : null,
				'width'         => isset( $custom_logo_args[0]['width'] ) ? $custom_logo_args[0]['width'] : null,
				'flex_height'   => isset( $custom_logo_args[0]['flex-height'] ) ? $custom_logo_args[0]['flex-height'] : null,
				'flex_width'    => isset( $custom_logo_args[0]['flex-width'] ) ? $custom_logo_args[0]['flex-width'] : null,
				'button_labels' => array(
					'select'       => esc_html__( 'Select logo', 'alpaca' ),
					'change'       => esc_html__( 'Change logo', 'alpaca' ),
					'remove'       => esc_html__( 'Remove', 'alpaca' ),
					'default'      => esc_html__( 'Default', 'alpaca' ),
					'placeholder'  => esc_html__( 'No logo selected', 'alpaca' ),
					'frame_title'  => esc_html__( 'Select logo', 'alpaca' ),
					'frame_button' => esc_html__( 'Choose logo', 'alpaca' )
				)
			) ) );
		}
		/**
		* Register section social menu
		*/
		protected function add_section_social_menu( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_site_header_section_social_menu', array(
				'title'	=> esc_html__( 'Social Menu', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_header_show_social_menu', array(
				'default'   		=> $defaults['alpaca_site_header_show_social_menu'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_show_social_menu', array(
				'type'			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Display Social Menu', 'alpaca' ),
				// translators: 1/2: html tag
				'description' 	=> sprintf( esc_html__( '%1$sClick here%2$s to know how to setup the social menu.', 'alpaca' ), sprintf( '<a href="%s" target="_blank" rel="noopenner noreferrer">', 'https://loftocean.com/alpaca-doc/documentation.html#social-menu' ), '</a>' ),
				'section'  		=> 'alpaca_site_header_section_social_menu',
				'settings' 		=> 'alpaca_site_header_show_social_menu'
			) ) );
		}
		/**
		* Register section colors
		*/
		protected function add_section_colors( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_site_header_section_colors', array(
				'title'	=> esc_html__( 'Header Colors', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_color_scheme', array(
				'default'			=> $defaults['alpaca_site_header_color_scheme'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_light_color_background_color', array(
				'default'			=> $defaults['alpaca_site_header_light_color_background_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_dark_color_background_color', array(
				'default'			=> $defaults['alpaca_site_header_dark_color_background_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_color_scheme', array(
				'type' 		=> 'radio',
				'label' 	=> esc_html__( 'Color Scheme', 'alpaca' ),
				'section' 	=> 'alpaca_site_header_section_colors',
				'priority' 	=> 5,
				'settings' 	=> 'alpaca_site_header_color_scheme',
				'choices' 	=> array(
					'light-color'	=> esc_html__( 'Light', 'alpaca' ),
					'dark-color'	=> esc_html__( 'Dark', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_header_light_color_background_color', array(
				'label'		=> esc_html__( 'Light Scheme Background Color', 'alpaca' ),
				'section' 	=> 'alpaca_site_header_section_colors',
				'settings'	=> 'alpaca_site_header_light_color_background_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_header_dark_color_background_color', array(
				'label'		=> esc_html__( 'Dark Scheme Background Color', 'alpaca' ),
				'section' 	=> 'alpaca_site_header_section_colors',
				'settings'	=> 'alpaca_site_header_dark_color_background_color'
			) ) );

			$header_color = $wp_customize->get_control( 'header_textcolor' );
			if ( ! empty( $header_color ) ) {
				$header_color->section = 'alpaca_site_header_section_colors';
				$header_color->priority = 6;

				$wp_customize->get_setting( 'header_textcolor' )->transport = 'refresh';
			}
			$header = $wp_customize->get_control( 'header_image' );
			if ( ! empty( $header ) && ( $header instanceof WP_Customize_Control ) ) {
				$header->section 	= 'alpaca_site_header_section_colors';
				$header->priority 	= 20;

				$wp_customize->get_setting( 'header_image' )->transport = 'refresh';
				$wp_customize->get_setting( 'header_image_data' )->transport = 'refresh';
			}
		}
		/**
		* Register section more
		*/
		protected function add_section_more( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_site_header_section_more', array(
				'title'	=> esc_html__( 'Misc. (Search/Color Switcher/...)', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_show_search_button', array(
				'default'			=> $defaults['alpaca_site_header_show_search_button'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_header_show_popup_signup_form_button', array(
				'default'   		=> $defaults['alpaca_site_header_show_popup_signup_form_button'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_header_show_color_scheme_switcher', array(
				'default'   		=> $defaults['alpaca_site_header_show_color_scheme_switcher'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_header_hide_more_label', array(
				'default'   		=> $defaults['alpaca_site_header_hide_more_label'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_fold_more_buttons', array(
				'default'   		=> $defaults['alpaca_site_header_fold_more_buttons'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
				'dependency' 		=> array(
					'alpaca_site_header_layout' => array( 'value' => array( 'vertical-bar', 'vertical-wide' ) )
				)
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_show_search_button', array(
				'type'			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Search Button', 'alpaca' ),
				'section'  		=> 'alpaca_site_header_section_more',
				'settings' 		=> 'alpaca_site_header_show_search_button'
			) ) );
			if ( alpaca_is_mc4wp_activated() ) {
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_show_popup_signup_form_button', array(
					'type'			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Popup Signup Form Button', 'alpaca' ),
					'description' 	=> sprintf(
						// translators: 1: html tag start, 2: html tag end
						esc_html__( 'Requires "MC4WP" plugin.%1$sSetup your popup signup form.%2$s', 'alpaca' ),
						' <a href="#" class="show-section" data-section-id="accordion-section-alpaca_section_popup_signup_form">',
						'</a>'
					),
					'section'  		=> 'alpaca_site_header_section_more',
					'settings' 		=> 'alpaca_site_header_show_popup_signup_form_button'
				) ) );
			}
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_show_color_scheme_switcher', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Color Scheme Switcher', 'alpaca' ),
				'section' 		=> 'alpaca_site_header_section_more',
				'settings' 		=> 'alpaca_site_header_show_color_scheme_switcher'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_hide_more_label', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Hide Label Text', 'alpaca' ),
				'section' 		=> 'alpaca_site_header_section_more',
				'settings' 		=> 'alpaca_site_header_hide_more_label'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_fold_more_buttons', array(
				'type' 				=> 'checkbox',
				'label_first'		=> true,
				'label' 			=> esc_html__( 'Fold these options by default', 'alpaca' ),
				'section' 			=> 'alpaca_site_header_section_more',
				'settings' 			=> 'alpaca_site_header_fold_more_buttons',
				'active_callback' 	=> array( $this, 'customize_control_active_cb' )
			) ) );
		}
		/**
		* Register section fullscreen search
		*/
		protected function add_section_fullscreen_search( $wp_customize ) {
			$defaults = $this->defaults;

			$wp_customize->add_section( 'alpaca_site_header_section_fullscreen_search', array(
				'title'	=> esc_html__( 'Fullscreen Search', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_fullscreen_search_style', array(
				'default'			=> $defaults['alpaca_site_header_fullscreen_search_style'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_fullscreen_search_show_category', array(
				'default'			=> $defaults['alpaca_site_header_fullscreen_search_show_category'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_fullscreen_search_show_tag', array(
				'default'			=> $defaults['alpaca_site_header_fullscreen_search_show_tag'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_header_fullscreen_search_show_author', array(
				'default'			=> $defaults['alpaca_site_header_fullscreen_search_show_author'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_fullscreen_search_style', array(
				'type' 		=> 'radio',
				'label' 	=> esc_html__( 'Style', 'alpaca' ),
				'section' 	=> 'alpaca_site_header_section_fullscreen_search',
				'settings' 	=> 'alpaca_site_header_fullscreen_search_style',
				'choices' 	=> array(
					'' => esc_html__( 'Default', 'alpaca' ),
					'minimal' => esc_html__( 'Minimalist', 'alpaca' )
				)
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_fullscreen_search_show_category', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Show Category List', 'alpaca' ),
				'section' 		=> 'alpaca_site_header_section_fullscreen_search',
				'settings' 		=> 'alpaca_site_header_fullscreen_search_show_category'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_fullscreen_search_show_tag', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Show Tag List', 'alpaca' ),
				'section' 		=> 'alpaca_site_header_section_fullscreen_search',
				'settings' 		=> 'alpaca_site_header_fullscreen_search_show_tag'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_header_fullscreen_search_show_author', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Show Author List', 'alpaca' ),
				'section' 		=> 'alpaca_site_header_section_fullscreen_search',
				'settings' 		=> 'alpaca_site_header_fullscreen_search_show_author'
			) ) );
		}
	}
	new Alpaca_Customize_Site_Header();
}
