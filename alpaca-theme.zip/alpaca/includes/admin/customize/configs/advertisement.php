<?php
/**
* Customize section advertisement configuration files.
*/


if ( ! class_exists( 'Alpaca_Customize_Advertisement' ) ) {
	class Alpaca_Customize_Advertisement extends Alpaca_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_advertisement';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;

			$this->add_panel( $wp_customize );
			$this->add_sections( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'    => esc_html__( 'Advertisement', 'alpaca' ),
				'priority' => 55
			) );
		}
		/**
		* Register advertisement sections
		*/
		protected function add_sections( $wp_customize ) {
			$defaults = $this->defaults;
			$sections = array(
				'before_single_post_content' 	=> esc_html__( 'Before Single Post Content', 'alpaca' ),
				'after_single_post_content'		=> esc_html__( 'After Single Post Content', 'alpaca' ),
				'before_single_page_content' 	=> esc_html__( 'Before Single Page Content', 'alpaca' ),
				'after_single_page_content' 	=> esc_html__( 'After Single Page Content', 'alpaca' )
 			);

			foreach ( $sections as $sid => $stitle ) {
				$wp_customize->add_section( 'alpaca_advertisement_section_' . $sid, array(
					'title' => $stitle,
					'panel' => $this->panel_id
				) );

				$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_ads_source_' . $sid, array(
					'default'   		=> $defaults[ 'alpaca_ads_source_' . $sid ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_ads_custom_url_' . $sid, array(
					'default'   		=> $defaults[ 'alpaca_ads_custom_url_' . $sid ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'esc_url_raw',
					'dependency' 		=> array(
						'alpaca_ads_source_' . $sid => array( 'value' => array( 'custom' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_ads_custom_image_' . $sid, array(
					'default'   		=> $defaults[ 'alpaca_ads_custom_image_' . $sid ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint',
					'dependency' 		=> array(
						'alpaca_ads_source_' . $sid => array( 'value' => array( 'custom' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_ads_custom_image_width_' . $sid, array(
					'default'   		=> $defaults[ 'alpaca_ads_custom_image_width_' . $sid ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint',
					'dependency' 		=> array(
						'alpaca_ads_source_' . $sid 			=> array( 'value' => array( 'custom' ) ),
						'alpaca_ads_custom_image_' . $sid 	=> array( 'value' => array( '', '0', 0 ), 'operator' => 'not in' )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_ads_custom_new_tab_' . $sid, array(
					'default'   		=> $defaults[ 'alpaca_ads_custom_new_tab_' . $sid ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
					'dependency' 		=> array(
						'alpaca_ads_source_' . $sid => array( 'value' => array( 'custom' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_ads_embed_code_' . $sid, array(
					'default'   		=> $defaults[ 'alpaca_ads_embed_code_' . $sid ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_html',
					'dependency' 		=> array(
						'alpaca_ads_source_' . $sid => array( 'value' => array( 'embed' ) )
					)
				) ) );

				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_ads_source_' . $sid, array(
					'type' 		=> 'select',
					'label' 	=> esc_html__( 'Ad source', 'alpaca' ),
					'section' 			=> 'alpaca_advertisement_section_' . $sid,
					'settings' 	=> 'alpaca_ads_source_' . $sid,
					'choices' 	=> array(
						'custom' 	=> esc_html__( 'Custom Banner', 'alpaca' ),
						'embed' 	=> esc_html__( 'Embed Code', 'alpaca' )
					)
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_ads_custom_url_' . $sid, array(
					'type' 				=> 'text',
					'label' 			=> esc_html__( 'URL', 'alpaca' ),
					'section' 			=> 'alpaca_advertisement_section_' . $sid,
					'settings' 			=> 'alpaca_ads_custom_url_' . $sid,
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_ads_custom_image_' . $sid, array(
					'type' 				=> 'image_id',
					'label' 			=> esc_html__( 'Ad image', 'alpaca' ),
					'section' 			=> 'alpaca_advertisement_section_' . $sid,
					'settings' 			=> 'alpaca_ads_custom_image_' . $sid,
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_ads_custom_image_width_' . $sid, array(
					'type' 				=> 'number_with_unit',
					'label' 			=> esc_html__( 'Ad image width', 'alpaca' ),
					'section' 			=> 'alpaca_advertisement_section_' . $sid,
					'settings' 			=> 'alpaca_ads_custom_image_width_' . $sid,
					'after_text'		=> 'px',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_ads_custom_new_tab_' . $sid, array(
					'type' 				=> 'checkbox',
					'label' 			=> esc_html__( 'Open link in a new tab', 'alpaca' ),
					'label_first'		=> true,
					'section' 			=> 'alpaca_advertisement_section_' . $sid,
					'settings' 			=> 'alpaca_ads_custom_new_tab_' . $sid,
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_ads_embed_code_' . $sid, array(
					'type' 				=> 'textarea',
					'label' 			=> esc_html__( 'Embed code', 'alpaca' ),
					'section' 			=> 'alpaca_advertisement_section_' . $sid,
					'settings' 			=> 'alpaca_ads_embed_code_' . $sid,
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
			}
		}
	}
	new Alpaca_Customize_Advertisement();
}
