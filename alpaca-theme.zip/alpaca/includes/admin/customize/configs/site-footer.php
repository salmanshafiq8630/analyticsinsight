<?php
/**
* Customize panel site footer configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Site_Footer' ) ) {
	class Alpaca_Customize_Site_Footer extends Alpaca_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_site_footer';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Boolean if theme extension exists
		*/
		public $is_extension_exists = false;
		/**
		* Boolean if mc4wp exists
		*/
		public $is_mc4wp_exists = false;
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;
			$this->is_extension_exists = alpaca_is_extension_activated();
			$this->is_mc4wp_exists = alpaca_is_mc4wp_activated();

			$this->add_panel( $wp_customize );
			$this->add_section_signup_form( $wp_customize );
			$this->add_section_instagram( $wp_customize );
			$this->add_section_bottom( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title'    => esc_html__( 'Site Footer', 'alpaca' ),
				'priority' => 25
			) );
		}
		/**
		* Register section top logo
		*/
		protected function add_section_signup_form( $wp_customize ) {
			if ( ! alpaca_is_mc4wp_activated() ) return;
			$defaults = $this->defaults;
			$section_id = 'alpaca_site_footer_section_signup_form';
			$wp_customize->add_section( $section_id, array(
				'title'	=> esc_html__( 'Newsletter Signup Form', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_show_signup_form', array(
				'default' 			=> $defaults['alpaca_site_footer_show_signup_form'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_signup_form_id', array(
				'default'			=> $defaults['alpaca_site_footer_signup_form_id'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency'		=> array(
					'alpaca_site_footer_show_signup_form' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_signup_form_color_scheme', array(
				'default' 			=> $defaults['alpaca_site_footer_signup_form_color_scheme'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
				'dependency'		=> array(
					'alpaca_site_footer_show_signup_form' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_signup_form_light_color_background_color', array(
				'default'   		=> $defaults['alpaca_site_footer_signup_form_light_color_background_color'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency'		=> array(
					'alpaca_site_footer_show_signup_form' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_signup_form_dark_color_background_color', array(
				'default'   		=> $defaults['alpaca_site_footer_signup_form_dark_color_background_color'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color',
				'dependency'		=> array(
					'alpaca_site_footer_show_signup_form' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_signup_form_background_image', array(
				'default'   		=> $defaults['alpaca_site_footer_signup_form_background_image'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint',
				'dependency'		=> array(
					'alpaca_site_footer_show_signup_form' => array( 'value' => array( 'on' ) )
				)
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_signup_form_enable_color_overlay', array(
				'default' 			=> $defaults['alpaca_site_footer_signup_form_enable_color_overlay'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
				'dependency'		=> array(
					'alpaca_site_footer_show_signup_form' => array( 'value' => array( 'on' ) ),
					'alpaca_site_footer_signup_form_background_image' => array( 'value' => array( '', '0', 0 ), 'operator' => 'not in' )
				)
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_show_signup_form', array(
				'type'			=> 'checkbox',
				'label_first' 	=> true,
				'label'			=> esc_html__( 'Display Signup Form', 'alpaca' ),
				'section'		=> $section_id,
				'settings'		=> 'alpaca_site_footer_show_signup_form'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_signup_form_id', array(
				'type'				=> 'select',
				'label'				=> esc_html__( 'Choose Form', 'alpaca' ),
				'section'			=> $section_id,
				'settings'			=> 'alpaca_site_footer_signup_form_id',
				'choices'			=> alpaca_mc4wp_forms(),
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_signup_form_color_scheme', array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Color Scheme', 'alpaca' ),
				'section' 	=> $section_id,
				'settings' 	=> 'alpaca_site_footer_signup_form_color_scheme',
				'choices'	=> array(
					'light-color' 	=> esc_html__( 'Light', 'alpaca' ),
					'dark-color' 	=> esc_html__( 'Dark', 'alpaca' )
				),
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_footer_signup_form_light_color_background_color', array(
				'label'    			=> esc_html__( 'Light Scheme Background Color', 'alpaca' ),
				'section'  			=> $section_id,
				'settings' 			=> 'alpaca_site_footer_signup_form_light_color_background_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_footer_signup_form_dark_color_background_color', array(
				'label'    			=> esc_html__( 'Dark Scheme Background Color', 'alpaca' ),
				'section'  			=> $section_id,
				'settings' 			=> 'alpaca_site_footer_signup_form_dark_color_background_color',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_signup_form_background_image', array(
				'type' 				=> 'image_id',
				'label' 			=> esc_html__( 'Background Image', 'alpaca' ),
				'section' 			=> $section_id,
				'settings' 			=> 'alpaca_site_footer_signup_form_background_image',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_signup_form_enable_color_overlay', array(
				'type'				=> 'checkbox',
				'label_first' 		=> true,
				'label'				=> esc_html__( 'Enable Color Overlay', 'alpaca' ),
				'description'		=> esc_html__( 'Please note: Color overlay appears after you upload background image.', 'alpaca' ),
				'section'			=> $section_id,
				'settings'			=> 'alpaca_site_footer_signup_form_enable_color_overlay',
				'active_callback'	=> array( $this, 'customize_control_active_cb' )
			) ) );
		}
		/**
		* Register section instagram
		*/
		protected function add_section_instagram( $wp_customize ) {
			if ( $this->is_extension_exists ) {
				$defaults = $this->defaults;
				$wp_customize->add_section( 'alpaca_site_footer_section_instagram', array(
					'title'	=> esc_html__( 'Instagram', 'alpaca' ),
					'panel' => 'alpaca_panel_site_footer'
				) );

				$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_group', array(
					'default' 			=> '',
					'transport'			=> 'postMessage',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
				) ) );
				$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_footer_enable_instagram', array(
					'default'   		=> $defaults['alpaca_site_footer_enable_instagram'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_username', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_username'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'sanitize_text_field',
					'dependency'		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_title', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_title'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'sanitize_text_field',
					'dependency' 		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_columns', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_columns'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint',
					'dependency' 		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_rows', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_rows'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint',
					'dependency' 		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_new_tab', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_new_tab'],
					'transport' 		=> 'postMessage',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox',
					'dependency' 		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_color_scheme', array(
					'default' 			=> $defaults['alpaca_site_footer_instagram_color_scheme'],
					'transport'			=> 'postMessage',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice',
					'dependency'		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_light_color_background_color', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_light_color_background_color'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'sanitize_hex_color',
					'dependency'		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_instagram_dark_color_background_color', array(
					'default'   		=> $defaults['alpaca_site_footer_instagram_dark_color_background_color'],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'sanitize_hex_color',
					'dependency'		=> array(
						'alpaca_site_footer_enable_instagram' => array( 'value' => array( 'on' ) )
					)
				) ) );

				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_enable_instagram', array(
					'type' 			=> 'checkbox',
					'label_first'	=> true,
					'label' 		=> esc_html__( 'Display Instagram Feed', 'alpaca' ),
					'section' 		=> 'alpaca_site_footer_section_instagram',
					'settings' 		=> 'alpaca_site_footer_enable_instagram'
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_instagram_username', array(
					'type' 				=> 'text',
					'label' 			=> esc_html__( 'Instagram Account', 'alpaca' ),
					'description_below' => true,
					'description' 		=> esc_html__( 'Please note: This setting will be ignored if you have entered your Instagram Token. Please check documentation for more information.', 'alpaca' ),
					'section' 			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_username',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
					'input_attrs' 		=> array(
						'placeholder'=> esc_html__( 'Enter your Instagram Account', 'alpaca' )
					)
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_instagram_title', array(
					'type'				=> 'text',
					'label' 			=> esc_html__( 'Title (optional)', 'alpaca' ),
					'section' 			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_title',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
					'input_attrs' 		=> array(
						'placeholder'=> esc_html__( 'Title (optional)', 'alpaca' )
					)
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_instagram_columns', array(
					'type' 				=> 'select',
					'label' 			=> esc_html__( 'Columns', 'alpaca' ),
					'section' 			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_columns',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
					'choices' 			=> array(
						'4' => esc_html__( '4', 'alpaca' ),
						'5' => esc_html__( '5', 'alpaca' ),
						'6' => esc_html__( '6', 'alpaca' ),
						'7' => esc_html__( '7', 'alpaca' ),
						'8' => esc_html__( '8', 'alpaca' ),
					)
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_instagram_rows', array(
					'type' 				=> 'select',
					'label' 			=> esc_html__( 'Rows', 'alpaca' ),
					'section' 			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_rows',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' ),
					'choices' 			=> array(
						'1' => esc_html__( '1', 'alpaca' ),
						'2' => esc_html__( '2', 'alpaca' )
					)
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_instagram_new_tab', array(
					'type' 				=> 'checkbox',
					'label_first'		=> true,
					'label' 			=> esc_html__( 'Open links in new tab', 'alpaca' ),
					'section' 			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_new_tab',
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_instagram_color_scheme', array(
					'type' 		=> 'select',
					'label' 	=> esc_html__( 'Color Scheme', 'alpaca' ),
					'section' 	=> 'alpaca_site_footer_section_instagram',
					'settings' 	=> 'alpaca_site_footer_instagram_color_scheme',
					'choices'	=> array(
						'light-color' 	=> esc_html__( 'Light', 'alpaca' ),
						'dark-color' 	=> esc_html__( 'Dark', 'alpaca' )
					),
					'active_callback'	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_footer_instagram_light_color_background_color', array(
					'label'    			=> esc_html__( 'Light Scheme Background Color', 'alpaca' ),
					'section'  			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_light_color_background_color',
					'active_callback'	=> array( $this, 'customize_control_active_cb' )
				) ) );
				$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_footer_instagram_dark_color_background_color', array(
					'label'    			=> esc_html__( 'Dark Scheme Background Color', 'alpaca' ),
					'section'  			=> 'alpaca_site_footer_section_instagram',
					'settings' 			=> 'alpaca_site_footer_instagram_dark_color_background_color',
					'active_callback'	=> array( $this, 'customize_control_active_cb' )
				) ) );
			}
		}
		/**
		* Register section footer bottom
		*/
		protected function add_section_bottom( $wp_customize ) {
			$defaults = $this->defaults;
			$wp_customize->add_section( 'alpaca_site_footer_section_bottom', array(
				'title'	=> esc_html__( 'Site Footer Bottom', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_copyright_text', array(
				'default'   		=> $defaults['alpaca_site_footer_bottom_copyright_text'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_html'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_light_color_scheme_logo', array(
				'default'   		=> $defaults['alpaca_site_footer_bottom_light_color_scheme_logo'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_dark_color_scheme_logo', array(
				'default'   		=> $defaults['alpaca_site_footer_bottom_dark_color_scheme_logo'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_logo_width', array(
				'default'   		=> $defaults['alpaca_site_footer_bottom_logo_width'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_color_scheme', array(
				'default' 			=> $defaults['alpaca_site_footer_bottom_color_scheme'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_light_color_background_color', array(
				'default'   		=> $defaults['alpaca_site_footer_bottom_light_color_background_color'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_site_footer_bottom_dark_color_background_color', array(
				'default'   		=> $defaults['alpaca_site_footer_bottom_dark_color_background_color'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_bottom_copyright_text', array(
				'type'		=> 'textarea',
				'label' 	=> esc_html__( 'Copyright Text', 'alpaca' ),
				'section'  	=> 'alpaca_site_footer_section_bottom',
				'settings' 	=> 'alpaca_site_footer_bottom_copyright_text'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_bottom_light_color_scheme_logo', array(
				'type'              => 'image_id',
				'label'             => esc_html__( 'Footer Logo for Light Color Scheme', 'alpaca' ),
				'section'           => 'alpaca_site_footer_section_bottom',
				'settings' 	        => 'alpaca_site_footer_bottom_light_color_scheme_logo'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_bottom_dark_color_scheme_logo', array(
				'type'              => 'image_id',
				'label'             => esc_html__( 'Footer Logo for Dark Color Scheme', 'alpaca' ),
				'section'           => 'alpaca_site_footer_section_bottom',
				'settings' 	        => 'alpaca_site_footer_bottom_dark_color_scheme_logo'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_bottom_logo_width', array(
				'type' 			=> 'number_with_unit',
				'label' 		=> esc_html__( 'Logo Width', 'alpaca' ),
				'after_text' 	=> 'px',
				'section' 		=> 'alpaca_site_footer_section_bottom',
				'settings' 		=> 'alpaca_site_footer_bottom_logo_width'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_footer_bottom_color_scheme', array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Color Scheme', 'alpaca' ),
				'section' 	=> 'alpaca_site_footer_section_bottom',
				'settings' 	=> 'alpaca_site_footer_bottom_color_scheme',
				'choices'	=> array(
					'light-color' 	=> esc_html__( 'Light', 'alpaca' ),
					'dark-color' 	=> esc_html__( 'Dark', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_footer_bottom_light_color_background_color', array(
				'label'    			=> esc_html__( 'Light Scheme Background Color', 'alpaca' ),
				'section'  			=> 'alpaca_site_footer_section_bottom',
				'settings' 			=> 'alpaca_site_footer_bottom_light_color_background_color'
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_site_footer_bottom_dark_color_background_color', array(
				'label'    			=> esc_html__( 'Dark Scheme Background Color', 'alpaca' ),
				'section'  			=> 'alpaca_site_footer_section_bottom',
				'settings' 			=> 'alpaca_site_footer_bottom_dark_color_background_color'
			) ) );
		}
	}
	new Alpaca_Customize_Site_Footer();
}
