<?php
/**
* Customize section site-identity configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_Site_Identity' ) ) {
	class Alpaca_Customize_Site_Identity extends Alpaca_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;

			$wp_customize->get_section( 'title_tagline' )->priority 	= 0;
			$wp_customize->get_setting( 'blogname' )->transport 		= 'postMessage';
			$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
		}
	}
	new Alpaca_Customize_Site_Identity();
}
