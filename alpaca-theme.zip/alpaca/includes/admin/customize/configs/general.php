<?php
/**
* Customize section general configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_General' ) ) {
	class Alpaca_Customize_General extends Alpaca_Customize_Configuration_Base {
		/**
		* Social media enabled
		*/
		public $social_enabled = false;
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_general';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;

			$this->add_panel( $wp_customize );
			$this->add_section_site_background( $wp_customize );
			$this->add_section_posts( $wp_customize );
			$this->add_section_colors( $wp_customize );
			$this->add_section_instagram( $wp_customize );
			$this->add_section_social_media( $wp_customize );
			$this->add_section_backtotop( $wp_customize );
			$this->add_section_image_loading( $wp_customize );
			$this->add_section_breadcrumbs( $wp_customize );
			$this->add_section_image_animation( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( $this->panel_id, array(
				'title' 	=> esc_html__( 'General', 'alpaca' ),
				'priority' 	=> 5
			) );
		}
		/**
		* Register section site background
		*/
		protected function add_section_site_background( $wp_customize ) {
			$defaults = $this->defaults;
			$section_id = 'alpaca_general_section_site_background';
			$wp_customize->add_section( $section_id, array(
				'title' => esc_html__( 'Site Background', 'alpaca' ),
				'panel' => $this->panel_id,
				'priority' => 5
			) );

			$bg_settings = array(
				'background_image',
				'background_preset',
				'background_position',
				'background_position_x',
				'background_position_y',
				'background_size',
				'background_repeat',
				'background_attachment',
				'background_color'
			);
			foreach ( $bg_settings as $id ) {
				$control = $wp_customize->get_control( $id );
				if ( ! empty( $control ) && ( $control instanceof WP_Customize_Control ) ) {
					$control->section = $section_id;
					$control->priority = 5;
				}
			}
		}
		/**
		* Register section posts
		*/
		protected function add_section_posts( $wp_customize ) {
			$defaults = $this->defaults;
			$layout_excerpt_length = array();
			$post_list_layouts = array(
				'standard' 	=> esc_html__( 'Standard', 'alpaca' ),
				'zigzag' 	=> esc_html__( 'Zigzag', 'alpaca' ),
				'list' 		=> esc_html__( 'List', 'alpaca' ),
				'grid' 		=> esc_html__( 'Grid', 'alpaca' ),
				'masonry' 	=> esc_html__( 'Masonry', 'alpaca' ),
				'carousel' 	=> esc_html__( 'Carousel', 'alpaca' ),
				'overlay' 	=> esc_html__( 'Overlay', 'alpaca' ),
				'widget_slider' 	=> esc_html__( 'Home Widget Slider', 'alpaca' )
			);

			$wp_customize->add_section( 'alpaca_general_section_posts', array(
				'title' 	=> esc_html__( 'Posts General Options', 'alpaca' ),
				'panel' 	=> $this->panel_id,
				'priority' 	=> 10
			) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_reading_speed_per_minute', array(
				'default'			=> $defaults['alpaca_reading_speed_per_minute'],
				'transport'			=> 'refresh',
				'sanitize_callback'	=> 'absint'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_reading_speed_unit', array(
				'default'			=> $defaults['alpaca_reading_speed_unit'],
				'transport'			=> 'refresh',
				'sanitize_callback'	=> 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_read_more_button_text', array(
				'default'			=> $defaults['alpaca_read_more_button_text'],
				'transport'			=> 'refresh',
				'sanitize_callback'	=> 'sanitize_text_field'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_list_pagination_style', array(
				'default'			=> $defaults['alpaca_list_pagination_style'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_load_post_metas_dynamically', array(
				'default'			=> $defaults['alpaca_load_post_metas_dynamically'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_post_excerpt_length_group', array(
				'default'   		=> '',
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_reading_speed_per_minute', array(
				'type' 			=> 'number',
				'label' 		=> esc_html__( 'Reading Speed ( Per Minute )', 'alpaca'),
				'section' 		=> 'alpaca_general_section_posts',
				'input_attrs'	=> array( 'min' => '50', 'max' => '1000' ),
				'settings' 		=> 'alpaca_reading_speed_per_minute'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_reading_speed_unit', array(
				'type' 		=> 'select',
				'section'	=> 'alpaca_general_section_posts',
				'settings' 	=> 'alpaca_reading_speed_unit',
				'choices' 	=> array(
					'words' 		=> esc_html__( 'Words', 'alpaca' ),
					'characters'	=> esc_html__( 'Characters', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_read_more_button_text', array(
				'type' 		=> 'text',
				'label' 	=> esc_html__( 'Read More Button Text', 'alpaca'),
				'section' 	=> 'alpaca_general_section_posts',
				'settings' 	=> 'alpaca_read_more_button_text'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_list_pagination_style', array(
				'type' 		=> 'select',
				'label'		=> esc_html__( 'Pagination Style', 'alpaca' ),
				'section'	=> 'alpaca_general_section_posts',
				'settings' 	=> 'alpaca_list_pagination_style',
				'choices' 	=> array(
					'classic' 		=> esc_html__( 'Classic Pagination', 'alpaca' ),
					'ajax-manual' 	=> esc_html__( 'Load More Button', 'alpaca' ),
					'ajax-auto'		=> esc_html__( 'Infinite Scroll', 'alpaca' )
				)
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_load_post_metas_dynamically', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Load Post Metas ( like count and view count ) Dynamically with AJAX', 'alpaca' ),
				'description' 	=> esc_html__( 'Recommend enabling this option if any caching plugins are used on your site.', 'alpaca' ),
				'description_below' => true,
				'section'		=> 'alpaca_general_section_posts',
				'settings' 		=> 'alpaca_load_post_metas_dynamically',
			) ) );

			foreach ( $post_list_layouts as $layout => $label ) {
				$layout_id = 'alpaca_post_excerpt_length_for_layout_' . $layout;
				$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, $layout_id, array(
					'default'   		=> $defaults[ $layout_id ],
					'transport' 		=> 'refresh',
					'sanitize_callback' => 'absint'
				) ) );
				array_push( $layout_excerpt_length, new Alpaca_Customize_Control( $wp_customize, $layout_id, array(
						'type'			=> 'number_slider',
						'label' 		=> $label,
						'after_text'	=> esc_html__( 'words', 'alpaca' ),
						'section' 		=> 'alpaca_general_section_posts',
						'settings' 		=> $layout_id,
						'input_attrs'	=> array(
							'data-min'	=> '10',
							'data-max'	=> '60',
							'data-step'	=> '5'
						)
					) )
				);
			}
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_post_excerpt_length_group', array(
				'type' 		=> 'group',
				'label' 	=> esc_html__( 'Post Excerpt Length', 'alpaca' ),
				'section' 	=> 'alpaca_general_section_posts',
				'settings'	=> 'alpaca_post_excerpt_length_group',
				'children'	=> $layout_excerpt_length
			) ) );
		}
		/**
		* Register section colors
		*/
		protected function add_section_colors( $wp_customize ) {
			$defaults = $this->defaults;
			$wp_customize->add_section( 'alpaca_general_section_colors', array(
				'title' 	=> esc_html__( 'General Colors', 'alpaca' ),
				'panel' 	=> $this->panel_id,
				'priority' 	=> 20
			) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_site_color_scheme', array(
				'default'			=> $defaults['alpaca_site_color_scheme'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_custom_accent_color', array(
				'default'			=> $defaults['alpaca_custom_accent_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_group_tweak_colors', array(
				'default'			=> '',
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_light_scheme_custom_bg_color', array(
				'default'			=> $defaults['alpaca_light_scheme_custom_bg_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_light_scheme_custom_text_color', array(
				'default'			=> $defaults['alpaca_light_scheme_custom_text_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_light_scheme_custom_content_color', array(
				'default'			=> $defaults['alpaca_light_scheme_custom_content_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_dark_scheme_custom_bg_color', array(
				'default'			=> $defaults['alpaca_dark_scheme_custom_bg_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_dark_scheme_custom_text_color', array(
				'default'			=> $defaults['alpaca_dark_scheme_custom_text_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_dark_scheme_custom_content_color', array(
				'default'			=> $defaults['alpaca_dark_scheme_custom_content_color'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'sanitize_hex_color'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_site_color_scheme', array(
				'type' 		=> 'radio',
				'label'		=> esc_html__( 'Site Color Scheme', 'alpaca' ),
				'section'	=> 'alpaca_general_section_colors',
				'settings' 	=> 'alpaca_site_color_scheme',
				'choices' 	=> array(
					'light-color'	=> esc_html__( 'Light', 'alpaca' ),
					'dark-color'	=> esc_html__( 'Dark', 'alpaca' )
				)
			) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'alpaca_custom_accent_color', array(
				'label'		=> esc_html__( 'Accent Color', 'alpaca' ),
				'section' 	=> 'alpaca_general_section_colors',
				'settings'	=> 'alpaca_custom_accent_color'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_group_tweak_colors', array(
				'type' 		=> 'group',
				'label' 	=> esc_html__( 'Tweak Colors', 'alpaca' ),
				'section' 	=> 'alpaca_general_section_colors',
				'settings'	=> 'alpaca_group_tweak_colors',
				'children' 	=> array(
					new WP_Customize_Color_Control( $wp_customize, 'alpaca_light_scheme_custom_bg_color', array(
						'label'		=> esc_html__( 'Light Scheme Background Color', 'alpaca' ),
						'section'	=> 'alpaca_general_section_colors',
						'settings'	=> 'alpaca_light_scheme_custom_bg_color'
					) ),
					new WP_Customize_Color_Control( $wp_customize, 'alpaca_light_scheme_custom_text_color', array(
						'label'		=> esc_html__( 'Light Scheme Text Color', 'alpaca' ),
						'section'	=> 'alpaca_general_section_colors',
						'settings'	=> 'alpaca_light_scheme_custom_text_color'
					) ),
					new WP_Customize_Color_Control( $wp_customize, 'alpaca_light_scheme_custom_content_color', array(
						'label'		=> esc_html__( 'Light Scheme Content Text Color', 'alpaca' ),
						'section'	=> 'alpaca_general_section_colors',
						'settings'	=> 'alpaca_light_scheme_custom_content_color'
					) ),
					new WP_Customize_Color_Control( $wp_customize, 'alpaca_dark_scheme_custom_bg_color', array(
						'label'    => esc_html__( 'Dark Scheme Background Color', 'alpaca' ),
						'section'  => 'alpaca_general_section_colors',
						'settings' => 'alpaca_dark_scheme_custom_bg_color'
					) ),
					new WP_Customize_Color_Control( $wp_customize, 'alpaca_dark_scheme_custom_text_color', array(
						'label'    => esc_html__( 'Dark Scheme Text Color', 'alpaca' ),
						'section'  => 'alpaca_general_section_colors',
						'settings' => 'alpaca_dark_scheme_custom_text_color'
					) ),
					new WP_Customize_Color_Control( $wp_customize, 'alpaca_dark_scheme_custom_content_color', array(
						'label'		=> esc_html__( 'Dark Scheme Content Text Color', 'alpaca' ),
						'section'	=> 'alpaca_general_section_colors',
						'settings'	=> 'alpaca_dark_scheme_custom_content_color'
					) ),
				)
			) ) );
		}
		/**
		* Register section instagram
		*/
		protected function add_section_instagram( $wp_customize ) {
			if ( alpaca_is_extension_activated() ) {
				$instagram = $wp_customize->get_section( 'loftocean_section_instagram' );
				if ( ! empty( $instagram ) && ( $instagram instanceof WP_Customize_Section ) ) {
					$instagram->panel = $this->panel_id;
					$instagram->priority = 30;
				}
			}
		}
		/**
		* Register section social media
		*/
		protected function add_section_social_media( $wp_customize ) {
			if ( alpaca_is_extension_activated() ) {
				$defaults = $this->defaults;
				$settings = array();
				$social_media = array(
					'like'		=> esc_html__( 'Like', 'alpaca' ),
					'facebook'	=> esc_html__( 'Facebook', 'alpaca' ),
					'twitter' 	=> esc_html__( 'Twitter', 'alpaca' ),
					'pinterest'	=> esc_html__( 'Pinterest', 'alpaca' ),
					'linkedin'	=> esc_html__( 'LinkedIn', 'alpaca' ),
					'whatsapp' 	=> esc_html__( 'Whats App', 'alpaca' ),
					'reddit'	=> esc_html__( 'Reddit', 'alpaca' ),
					'email'		=> esc_html__( 'Email', 'alpaca' )
				);
				$wp_customize->add_section( 'alpaca_general_section_social_media', array(
					'title' 	=> esc_html__( 'Social Share Buttons', 'alpaca' ),
					'panel' 	=> $this->panel_id,
					'priority' 	=> 40
				) );
				$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_general_social_media_group' ), array(
					'default'   		=> '',
					'transport' 		=> 'postMessage',
					'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_empty'
				) );

				foreach ( $social_media as $id => $title ) {
					$meta_id = 'alpaca_general_social_' . $id;
					$settings[ $id ] = $this->register_meta_setting( $wp_customize, $meta_id, $id, $title );
				}
				$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_general_social_media_group', array(
					'type' 		=> 'multiple_checkbox',
					'label' 	=> esc_html__( 'Social Icons', 'alpaca' ),
					'section' 	=> 'alpaca_general_section_social_media',
					'settings' 	=> 'alpaca_general_social_media_group',
					'choices'	=> $settings
				) ) );
			}
		}
		/**
		* Register section back to top
		*/
		protected function add_section_backtotop( $wp_customize ) {
			$defaults = $this->defaults;
			$wp_customize->add_section( 'alpaca_general_section_back_to_top', array(
				'title'		=> esc_html__( 'Back To Top', 'alpaca' ),
				'panel' 	=> $this->panel_id,
				'priority' 	=> 50
			) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_show_back_to_top_button', array(
				'default'			=> $defaults['alpaca_show_back_to_top_button'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_show_back_to_top_button', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Display the Back To Top button', 'alpaca' ),
				'section'		=> 'alpaca_general_section_back_to_top',
				'settings' 		=> 'alpaca_show_back_to_top_button',
			) ) );
		}
		/**
		* Register section progressive image loading
		*/
		protected function add_section_image_loading( $wp_customize ) {
			if ( ! alpaca_is_extension_activated() ) {
				return false;
			}

			$defaults = $this->defaults;
			$wp_customize->add_section( 'alpaca_general_section_image_loading', array(
				'title'	=> esc_html__( 'Image Loading', 'alpaca' ),
				'panel' => $this->panel_id,
				'priority' => 70
			) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_general_enable_progressive_image_loading', array(
				'default'			=> $defaults['alpaca_general_enable_progressive_image_loading'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_general_enable_lazy_load', array(
				'default'			=> $defaults['alpaca_general_enable_lazy_load'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_general_enable_full_image_size', array(
				'default'			=> $defaults['alpaca_general_enable_full_image_size'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_general_enable_progressive_image_loading', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Enable Progressive Image Loading', 'alpaca' ),
				'section'		=> 'alpaca_general_section_image_loading',
				'settings' 		=> 'alpaca_general_enable_progressive_image_loading'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_general_enable_lazy_load', array(
				'type' 				=> 'checkbox',
				'label_first'		=> true,
				'label'				=> esc_html__( 'Enable Lazy Loading', 'alpaca' ),
				'section'			=> 'alpaca_general_section_image_loading',
				'settings' 			=> 'alpaca_general_enable_lazy_load'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_general_enable_full_image_size', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Use original size images throughout the site', 'alpaca' ),
				'description'	=> esc_html__( 'Please use this feature with caution. Activating this function can ensure that the picture is clearer but at the same time will increase the page file size and loading time. Please optimize all images before uploading them to avoid uploading images that are too large.', 'alpaca' ),
				'section'		=> 'alpaca_general_section_image_loading',
				'settings' 		=> 'alpaca_general_enable_full_image_size'
			) ) );
		}
		/**
		* Register section post like
		*/
		protected function add_section_breadcrumbs( $wp_customize ) {
			if ( ! alpaca_is_yoast_seo_activated() ) {
				return false;
			}

			$defaults = $this->defaults;
			$section_id = 'alpaca_general_section_breadcrumbs';
			$wp_customize->add_section( $section_id, array(
				'title'	=> esc_html__( 'Breadcrumbs', 'alpaca' ),
				'panel' => $this->panel_id,
				'priority' => 90
			) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_post', array(
				'default'			=> $defaults['alpaca_show_yoast_seo_breadcrumbs_on_post'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_page', array(
				'default'			=> $defaults['alpaca_show_yoast_seo_breadcrumbs_on_page'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_archive', array(
				'default'			=> $defaults['alpaca_show_yoast_seo_breadcrumbs_on_archive'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_search', array(
				'default'			=> $defaults['alpaca_show_yoast_seo_breadcrumbs_on_search'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_post', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Show Yoast SEO breadcrumbs on Single Posts', 'alpaca' ),
				'section'		=> $section_id,
				'settings' 		=> 'alpaca_show_yoast_seo_breadcrumbs_on_post'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_page', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Show Yoast SEO breadcrumbs on Single Pages', 'alpaca' ),
				'section'		=> $section_id,
				'settings' 		=> 'alpaca_show_yoast_seo_breadcrumbs_on_page'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_archive', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Show Yoast SEO breadcrumbs on Archive Pages', 'alpaca' ),
				'section'		=> $section_id,
				'settings' 		=> 'alpaca_show_yoast_seo_breadcrumbs_on_archive'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_show_yoast_seo_breadcrumbs_on_search', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Show Yoast SEO breadcrumbs on Search Result Pages', 'alpaca' ),
				'section'		=> $section_id,
				'settings' 		=> 'alpaca_show_yoast_seo_breadcrumbs_on_search'
			) ) );
		}
		/**
		* Register section progressive image loading
		*/
		protected function add_section_image_animation( $wp_customize ) {
			$defaults = $this->defaults;
			$wp_customize->add_section( 'alpaca_general_section_animation', array(
				'title'	=> esc_html__( 'Animation', 'alpaca' ),
				'panel' => $this->panel_id,
				'priority' => 100
			) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_general_enable_posts_entrance_animation', array(
				'default'			=> $defaults['alpaca_general_enable_posts_entrance_animation'],
				'transport'			=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_general_enable_header_entrance_animation', array(
				'default'			=> $defaults['alpaca_general_enable_header_entrance_animation'],
				'transport'			=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_general_enable_posts_entrance_animation', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Posts Entrance Animation', 'alpaca' ),
				'section'		=> 'alpaca_general_section_animation',
				'settings' 		=> 'alpaca_general_enable_posts_entrance_animation'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_general_enable_header_entrance_animation', array(
				'type' 			=> 'checkbox',
				'label_first'	=> true,
				'label'			=> esc_html__( 'Post & Page Header Image Entrance Animation', 'alpaca' ),
				'section'		=> 'alpaca_general_section_animation',
				'settings' 		=> 'alpaca_general_enable_header_entrance_animation'
			) ) );
		}
		/**
		* Register meta customize setting and return customize control
		* @param object
		* @param string meta id
		* @param string control id
		* @return object
		*/
		protected function register_meta_setting( $wp_customize, $meta_id, $control_id, $title ) {
			$defaults = $this->defaults;
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, $meta_id, array(
				'default'			=> $defaults[ $meta_id ],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			return array( 'value' => 'on', 'label' => $title, 'setting' => $meta_id );
		}
	}
	new Alpaca_Customize_General();
}
