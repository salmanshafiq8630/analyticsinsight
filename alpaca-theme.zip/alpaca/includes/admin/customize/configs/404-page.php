<?php
/**
* Customize section header configuration files.
*/

if ( ! class_exists( 'Alpaca_Customize_404_Page' ) ) {
	class Alpaca_Customize_404_Page extends Alpaca_Customize_Configuration_Base {
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;

            $wp_customize->add_section( 'alpaca_section_404_page', array(
				'title'	=> esc_html__( '404 Page', 'alpaca' ),
				'priority' => 55
			) );

			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_404_page_title', array(
				'default'   		=> $alpaca_default_settings['alpaca_404_page_title'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'sanitize_text_field'
			) ) );
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, 'alpaca_404_page_message', array(
				'default'			=> $alpaca_default_settings['alpaca_404_page_message'],
				'transport'			=> 'refresh',
				'sanitize_callback' => array( $this, 'sanitize_page_message' )
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_404_page_show_search_form', array(
				'default'   		=> $alpaca_default_settings['alpaca_404_page_show_search_form'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_checkbox'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_404_page_color_scheme', array(
				'default'   		=> $alpaca_default_settings['alpaca_404_page_color_scheme'],
				'transport' 		=> 'postMessage',
				'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
			) ) );
			$wp_customize->add_setting( new WP_Customize_Setting( $wp_customize, 'alpaca_404_page_bg_image', array(
				'default'   		=> $alpaca_default_settings['alpaca_404_page_bg_image'],
				'transport' 		=> 'refresh',
				'sanitize_callback' => 'absint'
			) ) );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_404_page_title', array(
				'type' 		=> 'text',
				'label' 	=> esc_html__( 'Page Title', 'alpaca' ),
				'section' 	=> 'alpaca_section_404_page',
				'settings' 	=> 'alpaca_404_page_title'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_404_page_message', array(
				'type'          => 'textarea',
				'label'         => esc_html__( 'Message', 'alpaca' ),
				'desctiption'	=> esc_html__( 'Supports the following HTML markups: <a>,<br>,<b>,<i>', 'alpaca' ),
				'section'       => 'alpaca_section_404_page',
				'settings'      => 'alpaca_404_page_message'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_404_page_show_search_form', array(
				'type'					=> 'checkbox',
				'label_first'		 	=> true,
				'label' 				=> esc_html__( 'Display Search Form', 'alpaca' ),
				'section'  				=> 'alpaca_section_404_page',
				'settings' 				=> 'alpaca_404_page_show_search_form'
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_404_page_color_scheme', array(
				'type' 			=> 'select',
				'label_first'	=> true,
				'label' 		=> esc_html__( 'Color Scheme', 'alpaca' ),
				'section' 		=> 'alpaca_section_404_page',
				'settings' 		=> 'alpaca_404_page_color_scheme',
                'choices'       => array(
                    'light-color' => esc_html__( 'Light', 'alpaca' ),
                    'dark-color'  => esc_html__( 'Dark', 'alpaca' )
                )
			) ) );
			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, 'alpaca_404_page_bg_image', array(
				'type' 		=> 'image_id',
				'label' 	=> esc_html__( 'Background Image', 'alpaca' ),
				'section' 	=> 'alpaca_section_404_page',
				'settings' 	=> 'alpaca_404_page_bg_image'
			) ) );
		}
		/**
		* Sanitize function for 404 page message
		*/
		public function sanitize_page_message( $message ) {
			if ( empty( $message ) ) {
				return '';
			} else {
				return wp_kses( $message, array(
					'p' => array( 'class' => 1, 'id' => 1, 'data-*' => 1 ),
					'b' => array(), 'i' => array(), 'br' => array(),
					'em' => array(), 'strong' => array(),
					'a' => array( 'href' => 1, 'class' => 1, 'id' => 1, 'target' => 1, 'title' => 1, 'data-*' => 1, 'rel' => 1 )
				) );
			}
		}
	}
	new Alpaca_Customize_404_Page();
}
