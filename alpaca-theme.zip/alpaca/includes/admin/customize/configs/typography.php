<?php
/**
* Customize panel typography configuration files.
*/


if ( ! class_exists( 'Alpaca_Customize_Typography' ) ) {
	class Alpaca_Customize_Typography extends Alpaca_Customize_Configuration_Base {
		/**
		* String panel id
		*/
		public $panel_id = 'alpaca_panel_typography';
		/**
		* Array default customize option values
		*/
		public $defaults = array();
		/**
		* Boolean if theme extension exists
		*/
		public $is_extension_exists = false;
		/**
		* Boolean if mc4wp exists
		*/
		public $is_mc4wp_exists = false;
		/**
		* Register customize settings/control/panel/sections for current configuration class
		* @param object
		*/
		public function register_controls( $wp_customize ) {
			global $alpaca_default_settings;
			$this->defaults = $alpaca_default_settings;

			$this->add_panel( $wp_customize );
			$this->add_section_font_family( $wp_customize );
			$this->add_section_others( $wp_customize );
		}
		/**
		* Register panel
		*/
		protected function add_panel( $wp_customize ) {
			$wp_customize->add_panel( new WP_Customize_Panel( $wp_customize, $this->panel_id, array(
				'title' 	=> esc_html__( 'Typography', 'alpaca' ),
				'priority' 	=> 50
			) ) );
		}
		/**
		* Register section font family
		*/
		protected function add_section_font_family( $wp_customize ) {
			global $alpaca_google_fonts;
			require_once ALPACA_THEME_INC . 'admin/customize/configs/font-family.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

			$wp_customize->add_section( 'alpaca_typography_section_font_family', array(
				'title' => esc_html__( 'Font Family', 'alpaca' ),
				'panel' => $this->panel_id
			) );

			$settings = array(
				'heading' 	=> esc_html__( 'Heading Font', 'alpaca' ),
				'text' 		=> esc_html__( 'Text Font', 'alpaca' )
			);
			foreach ( $settings as $id => $title ) {
				$font_family_id = 'alpaca_typography_' . $id . '_font-family';
				$font_family_source_id = 'alpaca_typography_' . $id . '_font_family_source';
				$this->register_setting( $wp_customize, $font_family_source_id, 'Alpaca_Utils_Sanitize::sanitize_choice' );
				$this->register_setting( $wp_customize, $font_family_id, 'Alpaca_Utils_Sanitize::sanitize_choice', array(
					'alpaca_typography_' . $id . '_font_family_source' => array( 'value' => array( 'google_font' ) )
				) );

				$wp_customize->add_control( new WP_Customize_Control( $wp_customize, $font_family_source_id, array(
					'type' 		=> 'select',
					'label' 	=> $title,
					'section' 	=> 'alpaca_typography_section_font_family',
					'settings'	=> $font_family_source_id,
					'choices' 	=> array(
						'' 				=> esc_html__( 'Default Font', 'alpaca' ),
						'google_font' 	=> esc_html__( 'Google Font', 'alpaca' )
					)
				) ) );
				$wp_customize->add_control( new WP_Customize_Control( $wp_customize, $font_family_id, array(
					'type' 				=> 'select',
					'label' 			=> '',
					'choices' 			=> $alpaca_google_fonts,
					'section' 			=> 'alpaca_typography_section_font_family',
					'settings'			=> $font_family_id,
					'active_callback' 	=> array( $this, 'customize_control_active_cb' )
				) ) );
			}
		}
		/**
		* Register other sections
		*/
		public function add_section_others( $wp_customize ) {
			$defaults = $this->defaults;
			$sections = array(
				'post_title' => array(
					'title' => esc_html__( 'Post Title', 'alpaca' ),
					'style' => array( 'font-weight', 'text-transform', 'font-style' )
				),
				'content' => array(
					'title' => esc_html__( 'Content Text', 'alpaca' ),
					'style' => array( 'font_family', 'font-size', 'line-height' )
				),
				'post_excerpt' => array(
					'title' => esc_html__( 'Excerpt for Post List / Archive', 'alpaca' ),
					'style' => array( 'font_family', 'font-size', 'overlay_font-size' )
				),
				'page_title' => array(
					'title' => esc_html__( 'Page Title', 'alpaca' ),
					'style' => array( 'font-weight', 'text-transform', 'font-style' )
				),
				'homepage_section_title'	=> array(
					'title' => esc_html__( 'Homepage Section Title', 'alpaca' ),
					'style' => array( 'font_family', 'font-size', 'font-weight', 'letter-spacing', 'text-transform', 'sub_font-size', 'sub_font_family' )
				)
			);

			// Sections
			foreach ( $sections as $id => $attrs ) {
				$section_id = 'alpaca_section_typography_' . $id;
				$wp_customize->add_section( $section_id, array(
					'title' => $attrs['title'],
					'panel' => $this->panel_id
				) );
				$setting_prefix = 'alpaca_typography_' . $id;
				foreach ( $attrs['style'] as $style ) {
					switch ( $style ) {
						case 'font-weight':
							$this->register_font_weight( $wp_customize, $section_id, $setting_prefix );
							break;
						case 'text-transform':
							$this->register_text_transform( $wp_customize, $section_id, $setting_prefix );
							break;
						case 'font-style':
							$this->register_font_style( $wp_customize, $section_id, $setting_prefix );
							break;
						case 'line-height':
							$this->register_line_height( $wp_customize, $section_id, $setting_prefix );
							break;
						case 'letter-spacing':
							$this->register_letter_spacing( $wp_customize, $section_id, $setting_prefix );
							break;
						case 'font-size':
							$this->register_font_size( $wp_customize, $section_id, $setting_prefix );
							break;
						case 'overlay_font-size':
						case 'sub_font-size':
							$setting_id = $setting_prefix . '_' . $style;
							$label = ( 'sub_font-size' == $style ) ? esc_html__( 'Sub Title Font Size', 'alpaca' ) : esc_html__( 'Font Size for "Standard" & "Full Overlay"', 'alpaca' );
							$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, $setting_id, array(
								'default'   		=> $defaults[ $setting_id ],
								'transport' 		=> 'refresh',
								'sanitize_callback' => 'absint'
							) ) );
							$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, $setting_id, array(
								'type' 			=> 'number_with_unit',
								'label' 		=> $label,
								'after_text' 	=> 'px',
								'section' 		=> $section_id,
								'settings' 		=> $setting_id,
								'input_attrs' 	=> array( 'min' => 10, 'max' => 30 )
							) ) );
							break;
						case 'font_family':
						case 'sub_font_family':
							$label = ( 'sub_font_family' == $style ) ? esc_html__( 'Sub Title Font Family', 'alpaca' ) : esc_html__( 'Font Family', 'alpaca' ) ;
							$setting_id = $setting_prefix . '_' . $style;
							$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, $setting_id, array(
								'default'   		=> $defaults[ $setting_id ],
								'transport' 		=> 'refresh',
								'sanitize_callback' => 'Alpaca_Utils_Sanitize::sanitize_choice'
							) ) );
							$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, $setting_id, array(
								'type' 		=> 'select',
								'label' 	=> $label,
								'section' 	=> $section_id,
								'settings' 	=> $setting_id,
								'choices'	=> array(
									'heading_font' 		=> esc_html__( 'Heading Font', 'alpaca' ),
									'text_font' => esc_html__( 'Text Font', 'alpaca' )
								)
							) ) );
							break;
					}
				}
			}
		}
		/**
		* Register customize setting
		* @param object
		* @param string setting id
		* @param string sanitize callback function
		*/
		protected function register_setting( $wp_customize, $setting_id, $sanitize_callback, $deps = false ) {
			$defaults = $this->defaults;
			$wp_customize->add_setting( new Alpaca_Customize_Setting( $wp_customize, $setting_id, array(
				'default'   		=> $defaults[ $setting_id ],
				'transport' 		=> 'refresh',
				'sanitize_callback' => $sanitize_callback,
				'dependency'		=> $deps ? $deps : array()
			) ) );
		}
		/**
		* Register font size settings
		* @param object
		* @param string section id
		* @param string setting id prefix
		* @return array
		*/
		protected function register_font_size( $wp_customize, $section, $setting_id_prefix ) {
			$setting_id = $setting_id_prefix . '_font-size';
			$this->register_setting( $wp_customize, $setting_id, 'absint' );

			$wp_customize->add_control( new Alpaca_Customize_Control( $wp_customize, $setting_id, array(
				'type' 			=> 'number_with_unit',
				'label' 		=> esc_html__( 'Font Size', 'alpaca' ),
				'after_text' 	=> 'px',
				'section' 		=> $section,
				'settings' 		=> $setting_id,
				'input_attrs' 	=> array( 'min' => 10, 'max' => 30 )
			) ) );
		}
		/**
		* Register font weight settings
		* @param object
		* @param string section id
		* @param string setting id prefix
		* @return array
		*/
		protected function register_font_weight( $wp_customize, $section, $setting_id_prefix ) {
			$setting_id = $setting_id_prefix . '_font-weight';
			$this->register_setting( $wp_customize, $setting_id, 'Alpaca_Utils_Sanitize::sanitize_choice' );

			$wp_customize->add_control( new WP_Customize_Control( $wp_customize, $setting_id, array(
				'type'	 		=> 'select',
				'label' 		=> esc_html__( 'Font Weight', 'alpaca' ),
				'description' 	=> esc_html__( 'Please note: not every font supports all the font weight values listed.', 'alpaca' ),
				'section' 		=> $section,
				'settings' 		=> $setting_id,
				'choices' 		=> array(
					'100' => 100,
					'200' => 200,
					'300' => 300,
					'400' => 400,
					'500' => 500,
					'600' => 600,
					'700' => 700,
					'800' => 800,
				)
			) ) );
		}
		/**
		* Register text transform settings
		* @param object
		* @param string section id
		* @param string setting id prefix
		* @return array
		*/
		protected function register_text_transform( $wp_customize, $section, $setting_id_prefix ) {
			$setting_id = $setting_id_prefix . '_text-transform';
			$this->register_setting( $wp_customize, $setting_id, 'Alpaca_Utils_Sanitize::sanitize_choice' );

			$wp_customize->add_control( new WP_Customize_Control( $wp_customize, $setting_id, array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Text Transform', 'alpaca' ),
				'section' 	=> $section,
				'settings' 	=> $setting_id,
				'choices' 	=> array(
					'none' 			=> esc_html__( 'None', 'alpaca' ),
					'uppercase' 	=> esc_html__( 'Uppercase', 'alpaca' ),
					'lowercase' 	=> esc_html__( 'Lowercase', 'alpaca' ),
					'capitalize' 	=> esc_html__( 'Capitalize', 'alpaca' )
				)
			) ) );
		}
		/**
		* Register font style settings
		* @param object
		* @param string section id
		* @param string setting id prefix
		* @return array
		*/
		protected function register_font_style( $wp_customize, $section, $setting_id_prefix ) {
			$setting_id = $setting_id_prefix . '_font-style';
			$this->register_setting( $wp_customize, $setting_id, 'Alpaca_Utils_Sanitize::sanitize_choice' );

			$wp_customize->add_control( new WP_Customize_Control( $wp_customize, $setting_id, array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Font Style', 'alpaca' ),
				'section' 	=> $section,
				'settings' 	=> $setting_id,
				'choices' 	=> array(
					'normal' => esc_html__( 'Normal', 'alpaca' ),
					'italic' => esc_html__( 'Italic', 'alpaca' )
				)
			) ) );
		}
		/**
		* Register line height settings
		* @param object
		* @param string section id
		* @param string setting id prefix
		* @return array
		*/
		protected function register_line_height( $wp_customize, $section, $setting_id_prefix ) {
			$setting_id = $setting_id_prefix . '_line-height';
			$this->register_setting( $wp_customize, $setting_id, 'Alpaca_Utils_Sanitize::sanitize_choice' );

			$wp_customize->add_control( new WP_Customize_Control($wp_customize, $setting_id, array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Line Height', 'alpaca' ),
				'section' 	=> $section,
				'settings' 	=> $setting_id,
				'choices' 	=> array(
					'1.2'	=> '1.2',
					'1.25'	=> '1.25',
					'1.3' 	=> '1.3',
					'1.35' 	=> '1.35',
					'1.4' 	=> '1.4',
					'1.45' 	=> '1.45',
					'1.5' 	=> '1.5',
					'1.55' 	=> '1.55',
					'1.6' 	=> '1.6',
					'1.65' 	=> '1.65',
					'1.7' 	=> '1.7',
					'1.75' 	=> '1.75',
					'1.8' 	=> '1.8',
					'1.85' 	=> '1.85',
					'1.9' 	=> '1.9',
					'1.95' 	=> '1.95',
					'2' 	=> '2',
					'2.05' 	=> '2.05',
					'2.1' 	=> '2.1',
					'2.15' 	=> '2.15',
					'2.2' 	=> '2.2',
					'2.25' 	=> '2.25',
					'2.3' 	=> '2.3',
					'2.35' 	=> '2.35',
					'2.4' 	=> '2.4',
					'2.45' 	=> '2.45',
					'2.5' 	=> '2.5',
					'2.55' 	=> '2.55',
					'2.6' 	=> '2.6',
					'2.65' 	=> '2.65',
					'2.7' 	=> '2.7',
					'2.75' 	=> '2.75',
					'2.8' 	=> '2.8',
					'2.85' 	=> '2.85',
					'2.9' 	=> '2.9',
					'2.95' 	=> '2.95',
					'3' 	=> '3',
				)
			) ) );
		}
		/**
		* Register letter spacing settings
		* @param object
		* @param string section id
		* @param string setting id prefix
		* @return array
		*/
		protected function register_letter_spacing( $wp_customize, $section, $setting_id_prefix ) {
			$setting_id = $setting_id_prefix . '_letter-spacing';
			$this->register_setting( $wp_customize, $setting_id, 'Alpaca_Utils_Sanitize::sanitize_choice' );

			$wp_customize->add_control( new WP_Customize_Control( $wp_customize, $setting_id, array(
				'type' 		=> 'select',
				'label' 	=> esc_html__( 'Letter Spacing', 'alpaca' ),
				'section' 	=> $section,
				'settings' 	=> $setting_id,
				'choices' 	=> array(
					''			=> esc_html__( 'Default', 'alpaca' ),
					'0' 		=> '0em',
					'0.05em' 	=> '0.05em',
					'0.1em' 	=> '0.1em',
					'0.15em' 	=> '0.15em',
					'0.2em' 	=> '0.2em',
					'0.25em' 	=> '0.25em',
					'0.3em' 	=> '0.3em',
					'0.35em' 	=> '0.35em',
					'0.4em' 	=> '0.4em'
				)
			) ) );
		}
	}
	new Alpaca_Customize_Typography();
}
