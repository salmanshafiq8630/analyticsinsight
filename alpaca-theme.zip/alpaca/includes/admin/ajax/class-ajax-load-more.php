<?php
/**
* Load more button ajax class
*/
if ( ! class_exists( 'Alpaca_Ajax_Load_More' ) ) {
 	class Alpaca_Ajax_Load_More {
		/**
		* String ajax action name
		*/
		public $action = 'alpaca_load_more';
		// Construct function
		public function __construct() {
			add_action( 'admin_init', array( $this, 'load_handler' ) );
		}
		/**
		* Load ajax handler if ajax request received
		*/
		public function load_handler() {
			$action = $this->action;
			if ( wp_doing_ajax() ) {
				add_action( 'wp_ajax_' . $action, array( $this, 'ajax_handler' ) );
				add_action( 'wp_ajax_nopriv_' . $action, array( $this, 'ajax_handler' ) );
				add_action( 'alpaca_pre_ajax_handler', array( $this, 'pre_ajax_start' ), 1 );
			}
		}
		/**
		* Pre ajax start
		*/
		public function pre_ajax_start() {
			$this->load_files();
			add_filter( 'alpaca_page_layout', array( $this, 'set_ajax_page_layout' ), 99999 );

            do_action( 'alpaca_image_loading_attributes' );
		}
		/**
		* Set page layout for ajax handler
		*/
		public function set_ajax_page_layout( $layout ) {
			if ( isset( $_REQUEST['args'], $_REQUEST['args']['page_layout'] ) ) {
				$args = array_map( 'sanitize_text_field', wp_unslash( $_REQUEST['args'] ) );
				$layout = $args['page_layout'];
			} else {
				$layout = 'with-sidebar-right';
			}
			return $layout;
		}
		/**
		* Ajax request handler
		*/
		public function ajax_handler() {
			if ( isset( $_REQUEST['settings'], $_REQUEST['query'], $_REQUEST['query']['post_type'], $_REQUEST['query']['paged'], $_REQUEST['settings']['archive_page'] ) ) {
				$settings = array_map( 'sanitize_text_field', wp_unslash( $_REQUEST['settings'] ) );
				$settings = array_map( 'maybe_unserialize', $settings );
				$query = array_map( 'sanitize_text_field', wp_unslash( $_REQUEST['query'] ) );
				$query = array_map( 'maybe_unserialize', $query );

				$paged = max( 1, intval( $query['paged'] ) );
				$archive_page = $settings['archive_page'];
				$layout = isset( $settings['layout'] ) ? $settings['layout'] : 'other';
				do_action( 'alpaca_pre_ajax_handler', $archive_page );
				query_posts( $query );
				global $wp_query;
				$results = array();
				if ( have_posts() ) {
					$is_post_archive = in_array( $archive_page, array( 'builder-homepage', 'home', 'category', 'tag', 'search', 'author', 'date', 'post-archive' ) );
					if ( $is_post_archive ) {
                        $post_list_args = array(
							'layout' => $layout,
							'columns' => isset( $settings['columns'] ) ? $settings['columns'] : '',
							'post_meta'	=> $this->get_metas( $archive_page, $settings ),
                            'grid_style' => isset( $settings['grid_style'] ) ? $settings['grid_style'] : '',
                            'grid_image_ratio' => isset( $settings['grid_image_ratio'] ) ? $settings['grid_image_ratio'] : '',
							'page_layout' => isset( $settings['page_layout'] ) ? $settings['page_layout'] : ''
						);
						do_action( 'alpaca_start_post_list_loop', $post_list_args );
                        alpaca_set_post_list_prop( 'image_sizes', Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'archive', 'args' => $post_list_args ) ) );
					}
					add_filter( 'post_class' ,array( $this, 'add_post_class' ) );
					while( have_posts() ) {
						the_post();
						ob_start();
						if ( $is_post_archive ) {
							get_template_part( 'template-parts/archive/content', $layout );
						} else {
							do_action( 'loftocean_ajax_the_list_content', $settings );
						}
						$results[] = ob_get_clean();
					}
					if ( $is_post_archive ) {
						do_action( 'alpaca_end_post_list_loop' );
					}
					ob_start();
					alpaca_list_pagination();
					$nav = ob_get_clean();
					wp_reset_postdata();
					$more = ( $paged < $wp_query->max_num_pages );
					wp_reset_query();
					wp_send_json_success( array(
						'more' => $more,
						'items' => $results,
						'videos' => apply_filters( 'loftocean_get_videos', false )
					) );
				} else {
					ob_start();
					get_template_part( 'template-parts/archive/content-none', $archive_page );
					$results[] = ob_get_clean();
					wp_send_json_success( array(
						'more' => false,
						'nav' => '',
						'items' => $results
					) );
				}
			}
			wp_send_json_error();
		}
		/**
		* Get posts metas shown
		* @param string archive page type
		* @param array settings
		* @return array metas list
		*/
		protected function get_metas( $archive_page, $settings ) {
			$default_metas = array( 'category', 'author', 'date', 'reading_time', 'excerpt', 'read_more_button' );
			switch ( $archive_page ) {
				case 'builder-homepage':
				case 'home':
					return $settings['metas'];
				case 'category':
				case 'tag':
				case 'author':
				case 'date':
				case 'search':
					return alpaca_get_list_post_meta( $archive_page );
			}
			return $default_metas;
		}
		/**
		* Load required files
		*/
		protected function load_files() {
			require_once ALPACA_THEME_INC . 'utils/class-utils-sanitize.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'front/class-mode-switcher.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'front/functions-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'front/class-front-archive.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
		/**
		* Add classname post to class list
		*/
		public function add_post_class( $class ) {
			array_push( $class, 'post' );
			return $class;
		}
 	}
	new Alpaca_Ajax_Load_More();
}
