<?php
if ( ! class_exists( 'Alpaca_Ajax_Manager' ) ) {
    class Alpaca_Ajax_Manager {
        /**
        * Class instance to make sure only one instance exists
        */
        public static $_instance = false;
        /**
        * Construct function
        */
        public function __construct() {
            $this->process_ajax_request();
        }
        /**
        * Load file for the ajax request
        */
        protected function process_ajax_request() {
            if ( isset( $_REQUEST[ 'action' ] ) ) {
                $action = sanitize_text_field( wp_unslash( $_REQUEST[ 'action' ] ) );
                switch( $action ) {
                    case 'alpaca_load_more':
                        require_once ALPACA_THEME_INC . 'admin/ajax/class-ajax-load-more.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                        break;
                    case 'alpaca-popup-form':
                        require_once ALPACA_THEME_INC . 'admin/ajax/class-ajax-popup-form.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                        break;
                    case 'alpaca-polylang-duplicate-form':
                    case 'alpaca-polylang-update-form':
                        require_once ALPACA_THEME_INC . 'admin/ajax/class-ajax-polylang-forms.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                        break;
                }
            }
        }
		/*
		* Static function to initialize the class
		*/
		public static function instance() {
			if ( false === self::$_instance ) {
				self::$_instance = new self();
			}
		}
	}
	add_action( 'init', 'Alpaca_Ajax_Manager::instance', 1 );
}
