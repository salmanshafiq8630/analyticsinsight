<?php
if ( ! class_exists( 'Alpaca_Ajax_Popup_Form' ) ) {
    class Alpaca_Ajax_Popup_Form {
        /**
        * Construct function
        */
        public function __construct() {
            add_action( 'wp_ajax_nopriv_alpaca-popup-form', array( $this, 'form_process' ) );
            add_action( 'wp_ajax_alpaca-popup-form', array( $this, 'form_process' ) );
        }
        /**
        * Action handler function
        */
        public function form_process() {
            $return_data = array( 'redirect' => false, 'html' => '' );
            if ( alpaca_is_mc4wp_activated() && ! empty( $_POST['alpaca_mc4wp_form_id'] ) ) {
                $form_id = absint( wp_unslash( $_POST['alpaca_mc4wp_form_id'] ) );
                $current_form_id = apply_filters( 'loftocean_translation_mc4wp_form_id', $form_id );

                $return_data['html'] = $this->process_submission( $current_form_id );
                $redirect_url = $this->get_redirect_url( $current_form_id );
                if ( ! empty( $redirect_url ) ) {
                    $return_data['redirect'] = $redirect_url;
                }
            }
            wp_send_json_success( $return_data );
        }
        /**
        * Process form submission
        */
        protected function process_submission( $form_id ) {
            $request_data = array_map( 'sanitize_text_field', wp_unslash( $_POST ) );
            $request_data = stripslashes_deep( $request_data );

            try {
                $form = mc4wp_get_form( $form_id );
            } catch ( Exception $e ) {
                return false;
            }

            // bind request to form & validate
            $form->handle_request( $request_data );
            $form->validate();

            // did form have errors?
            if ( $form->has_errors() ) {
                foreach ( $form->errors as $error_code ) {
                    $form->add_notice( $form->get_message( $error_code ), 'error' );
                }
                $this->get_log()->info( sprintf( 'Form %d > Submitted with errors: %s', $form->ID, join( ', ', $form->errors ) ) );
            } else {
                $this->process_subscribe_form( $form );
            }
            return $form->get_response_html();
        }
        /**
         * Process a subscribe form.
         *
         * @param MC4WP_Form $form
         */
        public function process_subscribe_form( $form ) {
            $result     = false;
            $mailchimp  = new MC4WP_MailChimp();
            $email_type = $form->get_email_type();
            $data       = $form->get_data();
            $ip_address = mc4wp_get_request_ip_address();

            /** @var MC4WP_MailChimp_Subscriber $subscriber */
            $subscriber = null;

            /**
             * @ignore
             * @deprecated 4.0
             */
            $data = apply_filters( 'mc4wp_merge_vars', $data );

            /**
             * @ignore
             * @deprecated 4.0
             */
            $data = (array) apply_filters( 'mc4wp_form_merge_vars', $data, $form );

            // create a map of all lists with list-specific data
            $mapper = new MC4WP_List_Data_Mapper( $data, $form->get_lists() );

            /** @var MC4WP_MailChimp_Subscriber[] $map */
            $map = $mapper->map();

            // loop through lists
            foreach ( $map as $list_id => $subscriber ) {
                $subscriber->status     = $form->settings['double_optin'] ? 'pending' : 'subscribed';
                $subscriber->email_type = $email_type;
                $subscriber->ip_signup  = $ip_address;
                $subscriber->tags       = $form->get_subscriber_tags();

                $subscriber = apply_filters( 'mc4wp_subscriber_data', $subscriber );
                $subscriber = apply_filters( 'mc4wp_form_subscriber_data', $subscriber );

                // send a subscribe request to Mailchimp for each list
                $result = $mailchimp->list_subscribe( $list_id, $subscriber->email_address, $subscriber->to_array(), $form->settings['update_existing'], $form->settings['replace_interests'] );
            }

            $log = $this->get_log();

            // do stuff on failure
            if ( ! is_object( $result ) || empty( $result->id ) ) {
                $error_code    = $mailchimp->get_error_code();
                $error_message = $mailchimp->get_error_message();

                if ( (int) $mailchimp->get_error_code() === 214 ) {
                    $form->add_error( 'already_subscribed' );
                    $form->add_notice( $form->messages['already_subscribed'], 'notice' );
                    $log->warning( sprintf( 'Form %d > %s is already subscribed to the selected list(s)', $form->ID, $data['EMAIL'] ) );
                } else {
                    $form->add_error( $error_code );
                    $form->add_notice( $form->messages['error'], 'error' );
                    $log->error( sprintf( 'Form %d > Mailchimp API error: %s %s', $form->ID, $error_code, $error_message ) );
                    do_action( 'mc4wp_form_api_error', $form, $error_message );
                }

                // bail
                return;
            }

            // Success! Did we update or newly subscribe?
            if ( $result->status === 'subscribed' && $result->was_already_on_list ) {
                $form->last_event = 'updated_subscriber';
                $form->add_notice( $form->messages['updated'], 'success' );
                $log->info( sprintf( 'Form %d > Successfully updated %s', $form->ID, $data['EMAIL'] ) );
                do_action( 'mc4wp_form_updated_subscriber', $form, $subscriber->email_address, $data );
            } else {
                $form->last_event = 'subscribed';
                $form->add_notice( $form->messages['subscribed'], 'success' );
                $log->info( sprintf( 'Form %d > Successfully subscribed %s', $form->ID, $data['EMAIL'] ) );
            }
            do_action( 'mc4wp_form_subscribed', $form, $subscriber->email_address, $data, $map );
        }
        /**
        * Get redirect url
        */
        protected function get_redirect_url( $form_id ) {
            $redirect_url = '';
            try {
                $form = mc4wp_get_form( $form_id );
                $redirect_url = $form->get_redirect_url();
            } catch ( Exception $e ) {
                return '';
            }
            return trim( $redirect_url );
        }   /**
         * @return MC4WP_Debug_Log
         */
        protected function get_log() {
            return mc4wp( 'log' );
        }
    }
    new Alpaca_Ajax_Popup_Form();
}
