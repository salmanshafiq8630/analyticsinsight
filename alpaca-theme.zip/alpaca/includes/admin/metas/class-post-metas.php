<?php
if ( ! class_exists( 'Alpaca_Post_Metas' ) ) {
	class Alpaca_Post_Metas {
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'loftocean_post_metabox_html', 	array( $this, 'post_metabox' ) );
			add_action( 'loftocean_save_post_metabox_settings', array( $this, 'save_post_meta' ), 10, 1 );
			add_filter( 'loftocean_metabox_get_post_title', array( $this, 'change_post_metabox_title' ), 10, 2 );

			if ( alpaca_is_gutenberg_enabled() ) {
				add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ), 5 );
			}
		}
		/**
		* Enqueue gutenberg editor assets
		*/
		public function enqueue_editor_assets() {
			wp_enqueue_script(
				'alpaca-gutenberg-post-script',
				ALPACA_ASSETS_URI . 'scripts/editor/post-settings.js',
				array( 'wp-element', 'wp-i18n', 'wp-editor', 'wp-hooks', 'wp-components' ),
				ALPACA_ASSETS_VERSION,
				true
			);
		}
		/**
		* Change post metabox title
		* @param string
		* @param string
		* @return string
		*/
		public function change_post_metabox_title( $title, $type ) {
			if ( 'post' == $type ) {
				return esc_html__( 'Alpaca Single Post Options', 'alpaca' );
			} else {
				return $title;
			}
		}
		/**
		* Show post meta box html
		* @param object
		*/
		public function post_metabox( $post ) {
			$pid = $post->ID;
			$layout = get_post_meta( $pid, 'alpaca_single_post_template_layout', true );
			$options = array(
				'' => esc_html__( 'Default', 'alpaca' ),
				'post-template-split' => esc_html__( 'Split Template', 'alpaca' ),
				'post-template-wide-header-img_with-sidebar-right' => esc_html__( 'Wide Header Image + Right Sidebar', 'alpaca' ),
				'post-template-wide-header-img_with-sidebar-left' => esc_html__( 'Wide Header Image + Left Sidebar', 'alpaca' ),
				'post-template-wide-header-img' => esc_html__( 'Wide Header Image + No Sidebar', 'alpaca' ),
				'post-template-wide-overlay-header_with-sidebar-right' => esc_html__( 'Overlay Header + Right Sidebar', 'alpaca' ),
				'post-template-wide-overlay-header_with-sidebar-left' => esc_html__( 'Overlay Header + Left Sidebar', 'alpaca' ),
				'post-template-wide-overlay-header' => esc_html__( 'Overlay Header + No Sidebar', 'alpaca' ),
				'post-template-normal_with-sidebar-right' => esc_html__( 'Normal Template + Right Sidebar', 'alpaca' ),
				'post-template-normal_with-sidebar-left' => esc_html__( 'Normal Template + Left Sidebar', 'alpaca' ),
				'post-template-normal' => esc_html__( 'Normal Template + No Sidebar', 'alpaca' )
			); ?>

			<p>
				<label for="alpaca_single_post_template_layout"><?php esc_html_e( 'Template & Layout:', 'alpaca' ); ?></label>
				<select name="alpaca_single_post_template_layout" id="alpaca_single_post_template_layout">
				<?php foreach ( $options as $val => $lbl ) : ?>
					<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $layout ); ?>><?php echo esc_html( $lbl ); ?></option>
				<?php endforeach; ?>
				</select><br />
				<span class="description"><?php esc_html_e( 'When choose "Default", the settings from "Customize > Single Post > Post" will be used.', 'alpaca' ); ?></span>
			</p>
			<p><?php
		}
		/**
		* Save post meta
		* @param int post id
		*/
		public function save_post_meta( $pid ) {
			if ( isset( $_REQUEST['alpaca_single_post_template_layout'] ) ) {
				update_post_meta( $pid, 'alpaca_single_post_template_layout', sanitize_text_field( wp_unslash( $_REQUEST['alpaca_single_post_template_layout'] ) ) );
			}
		}
	}
	new Alpaca_Post_Metas();
}
