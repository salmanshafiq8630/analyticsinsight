<?php
if ( ! class_exists( 'Alpaca_Page_Metas' ) ) {
	class Alpaca_Page_Metas {
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'loftocean_save_page_metabox_settings', array( $this, 'save_page_meta' ), 10, 1 );
			add_filter( 'loftocean_metabox_get_page_title', array( $this, 'change_page_metabox_title' ), 10, 2 );
			add_filter( 'loftocean_the_page_metabox_html', array( $this, 'page_metabox' ) );

			if ( alpaca_is_gutenberg_enabled() ) {
				add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_editor_assets' ), 5 );
			}
		}
		/**
		* Enqueue gutenberg editor assets
		*/
		public function enqueue_editor_assets() {
			if ( ! apply_filters( 'loftocean_hide_page_settings', false ) ) {
				wp_enqueue_script(
					'alpaca-gutenberg-page-script',
					ALPACA_ASSETS_URI . 'scripts/editor/page-settings.js',
					array( 'wp-element', 'wp-i18n', 'wp-editor', 'wp-hooks', 'wp-components' ),
					ALPACA_ASSETS_VERSION,
					true
				);
			}
		}
		/**
		* Change page metabox title
		* @param string
		* @param string
		* @return string
		*/
		public function change_page_metabox_title( $title, $type ) {
			if ( 'page' == $type ) {
				return esc_html__( 'Alpaca Single Page Options', 'alpaca' );
			} else {
				return $title;
			}
		}
		/**
		* Output page meta box html
		* @param object
		*/
		public function page_metabox( $post ) {
			if ( apply_filters( 'loftocean_hide_page_settings', false, $post ) ) {
				return '';
			}

			$postID = $post->ID;
			$layout = get_post_meta( $postID, 'alpaca_page_layout', true );
			$extra_class = get_post_meta( $postID, 'alpaca_advanced_classname', true );
			$hide_page_header = get_post_meta( $postID, 'alpaca_hide_page_header', true );
			$sub_title = get_post_meta( $postID, 'alpaca_page_sub_title', true );
			$before_ads = get_post_meta( $postID, 'alpaca_hide_before_page_content_ad', true );
			$after_ads = get_post_meta( $postID, 'alpaca_hide_after_page_content_ad', true ); ?>

			<p>
				<label><?php esc_html_e( 'Page Layout:', 'alpaca' ); ?></label>
				<select name="alpaca_page_layout">
					<option value="" <?php selected( '', $layout ); ?>><?php esc_html_e( 'No sidebar', 'alpaca' ); ?></option>
					<option value="fullwidth" <?php selected( 'fullwidth', $layout ); ?>><?php esc_html_e( 'Fullwidth', 'alpaca' ); ?></option>
					<option value="with-sidebar-right" <?php selected( 'with-sidebar-right', $layout ); ?>><?php esc_html_e( 'Right Sidebar', 'alpaca' ); ?></option>
					<option value="with-sidebar-left" <?php selected( 'with-sidebar-left', $layout ); ?>><?php esc_html_e( 'Left Sidebar', 'alpaca' ); ?></option>
				</select>
			</p>
			<p>
				<label><?php esc_html_e( 'Hide AD:', 'alpaca' ); ?></label>
				<input type="checkbox" id="alpaca_hide_before_page_content_ad" name="alpaca_hide_before_page_content_ad" value="on" <?php checked( 'on', $before_ads ); ?>>
				<label class="checkbox-label" for="alpaca_hide_before_page_content_ad"><?php esc_html_e( 'Hide advertisement before page content', 'alpaca' ); ?></label>
			</p>
			<p>
				<label><?php esc_html_e( 'Hide AD:', 'alpaca' ); ?></label>
				<input type="checkbox" id="alpaca_hide_after_page_content_ad" name="alpaca_hide_after_page_content_ad" value="on" <?php checked( 'on', $after_ads ); ?>>
				<label class="checkbox-label" for="alpaca_hide_after_page_content_ad"><?php esc_html_e( 'Hide advertisement after page content', 'alpaca' ); ?></label>
			</p>
			<p>
				<label for="alpaca_hide_page_header"><?php esc_html_e( 'Hide Page Header:', 'alpaca' ); ?></label>
				<input type="checkbox" id="alpaca_hide_page_header" name="alpaca_hide_page_header" value="on" <?php checked( 'on', $hide_page_header ); ?>>
			</p>
			<p>
				<label for="alpaca_page_sub_title"><?php esc_html_e( 'Sub Title:', 'alpaca' ); ?></label>
				<textarea name="alpaca_page_sub_title" rows="4" cols="70"><?php echo esc_textarea( $sub_title ); ?></textarea>
			</p>
			<p>
				<label><?php esc_html_e( 'Additional CSS Class(es) to <body>:', 'alpaca' ); ?></label>
				<input type="text" id="alpaca_advanced_classname" name="alpaca_advanced_classname" value="<?php echo esc_attr( $extra_class ); ?>"  class="widefat" >
				<br><span class="description"><?php esc_html_e( 'Separate multiple classes with spaces.', 'alpaca' ); ?></span>
			</p><?php

		}
		/**
		* Save metas from page meta box
		* @param string id
		* @param object
		* @param string
		*/
		public function save_page_meta( $post_id ) {
			if ( isset( $_REQUEST['alpaca_page_sub_title'] ) ) {
				$hide_before_ad = empty( $_REQUEST['alpaca_hide_before_page_content_ad'] ) ? '' : 'on';
				update_post_meta( $post_id, 'alpaca_hide_before_page_content_ad', $hide_before_ad );

				$hide_after_ad = empty( $_REQUEST['alpaca_hide_after_page_content_ad'] ) ? '' : 'on';
				update_post_meta( $post_id, 'alpaca_hide_after_page_content_ad', $hide_after_ad );

				$hide_page_header = empty( $_REQUEST['alpaca_hide_page_header'] ) ? '' : 'on';
				update_post_meta( $post_id, 'alpaca_hide_page_header', $hide_page_header );

				$extra_class = empty( $_REQUEST['alpaca_advanced_classname'] ) ? '' : sanitize_text_field( wp_unslash( $_REQUEST['alpaca_advanced_classname'] ) );
				update_post_meta( $post_id, 'alpaca_advanced_classname', $extra_class );

				$layout = empty( $_REQUEST['alpaca_page_layout'] ) ? '' : sanitize_text_field( wp_unslash( $_REQUEST['alpaca_page_layout'] ) );
				update_post_meta( $post_id, 'alpaca_page_layout', $layout );

				$sub_title = empty( $_REQUEST['alpaca_page_sub_title'] ) ? '' : sanitize_text_field( wp_unslash( $_REQUEST['alpaca_page_sub_title'] ) );
				update_post_meta( $post_id, 'alpaca_page_sub_title', $sub_title );
			}
		}
	}
	new Alpaca_Page_Metas();
}
