<?php
if ( ! class_exists( 'Alpaca_Category_Metas' ) ) {
    class Alpaca_Category_Metas {
        /**
        * Array list of settings
        */
        protected $sets = array();
        /**
        * Construct function
        */
        public function __construct() {
            $this->init_settings();
            add_action( 'loftocean_category_edit_form_fields', array( $this, 'edit_form_fields' ) );
            add_action( 'loftocean_category_save_fields', array( $this, 'save_form_fields' ) );
        }
        /**
        * Edit form fields
        */
        public function edit_form_fields( $term_id ) {
            $this->enqueue_assets();

            $metas = get_term_meta( $term_id ); ?>
            <table class="form-table alpaca-category-settings"><tbody> <?php
                // More posts settings
                $enabled = get_term_meta( $term_id, 'alpaca_category_enable_individual_settings', true ); ?>
                <tr class="form-field category-enable-individual-settings-wrap">
                    <th scope="row" valign="top">
                        <label for="alpaca_category_enable_individual_settings"><?php esc_html_e( 'Category Layout Customization', 'alpaca' ); ?></label>
                    </th>
                    <td>
                        <input type="checkbox" name="alpaca_category_enable_individual_settings" id="alpaca_category_enable_individual_settings" value="on" <?php checked( 'on', $enabled ); ?> />
                    </td>
                </tr> <?php
                foreach( $this->sets as $id => $set ) :
                    if ( isset( $metas[ $id ] ) ) {
                        $set[ 'value' ] = $metas[ $id ][0];
                    } ?>
                    <tr class="form-field category-item-wrap item-<?php echo esc_attr( $id ); ?> item-type-<?php echo esc_attr( $set['type'] ); ?> hidden">
                        <th scope="row" valign="top">
                            <label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $set['label'] ); ?></label>
                        </th>
                        <td><?php $this->the_setting_item( $id, $set ); ?></td>
                    </tr><?php
                endforeach; ?>
            </tbody></table><?php
        }

		/**
		* Output the category setting
		* @param string item id
		* @param array $setting
		*/
		protected function the_setting_item( $id, $set ) {
			switch ( $set[ 'type' ] ) {
				case 'checkbox': ?>
					<input type="checkbox" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" <?php checked( 'on', $set['value' ] ); ?> /><?php
					break;
				case 'select': ?>
					<select name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>">
						<?php foreach ( $set['choices'] as $val => $label ) : ?>
							<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $set['value'], $val ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select> <?php
					break;
				case 'number': ?>
					<input type="number" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" value="<?php echo esc_attr( $set['value'] ); ?>" /> <?php
					break;
				case 'text': ?>
					<input type="text" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" value="<?php echo esc_attr( $set['value'] ); ?>" /> <?php
					break;
                case 'title':
                    break;
			}
		}
        /**
        * Enqueue assets
        */
        protected function enqueue_assets() {
            add_action( 'admin_print_footer_scripts-term.php', array( $this, 'enqueue_scripts' ) );
        }
		/*
		* Enqueue scripts needed for taxonomy image field
		*/
		public function enqueue_scripts() {
            $suffix = alpaca_get_assets_suffix();
			wp_enqueue_script( 'alpaca_admin_taxonomy', ALPACA_ASSETS_URI . 'scripts/admin/taxonomy' . $suffix . '.js', array( 'jquery' ), ALPACA_ASSETS_VERSION, true );
			$dependency = array();
			foreach ( $this->sets as $sid => $set ) {
				if ( ! empty( $set['dependency'] ) ) {
					foreach ( $set['dependency'] as $id => $val ) {
						if ( isset( $dependency[ $id ] ) ) {
							$dependency[ $id ][ $sid ] = $set['dependency'];
						} else {
							$dependency[ $id ] = array( $sid => $set['dependency'] );
 						}
					}
				}
			}
 			wp_localize_script( 'alpaca_admin_taxonomy', 'alpacaCategory', $dependency );
		}
        /**
        * Save form fields
        */
        public function save_form_fields( $term_id ) {
            if ( isset( $_REQUEST['alpaca_category_enable_individual_settings'] ) ) {
                $enabled = sanitize_text_field( wp_unslash( $_REQUEST['alpaca_category_enable_individual_settings'] ) );
                $enabled = empty( $enabled ) ? '' : 'on';
                update_term_meta( $term_id, 'alpaca_category_enable_individual_settings', $enabled );
                foreach( $this->sets as $id => $set ) {
                    if ( isset( $_REQUEST[ $id ] ) ) {
                        $value = sanitize_text_field( wp_unslash( $_REQUEST[ $id ] ) );
                        switch ( $attr['type'] ) {
                            case 'number':
                                $value = intval( wp_unslash( $_REQUEST[ $id ] ) );
                                break;
                            case 'select':
                                $value = sanitize_text_field( wp_unslash( $_REQUEST[ $id ] ) );
                                if ( ! in_array( $value, array_keys( $set['choices'] ) ) ) {
                                    $value = $set['value'];
                                }
                                break;
                            case 'checkbox':
                                $value = sanitize_text_field( wp_unslash( $_REQUEST[ $id ] ) );
                                $value = empty( $value ) ? '' : 'on';
                                break;
                        }
                        update_term_meta( $term_id, $id, $value );
                    } else if ( 'checkbox' === $set['type'] ) {
                        update_term_meta( $term_id, $id, '' );
                    }
                }
            } else {
                update_term_meta( $term_id, 'alpaca_category_enable_individual_settings', '' );
            }
        }
        /**
        * Setup the init settings
        */
        protected function init_settings() {
            $this->sets = array(
                'alpaca_archive_page_category_layout' => array(
    				'type'		=> 'select',
    				'value'	    => 'large',
    				'label'		=> esc_html__( 'Sidebar Layout', 'alpaca' ),
    				'choices'	=> array(
                        ''						=> esc_html__( 'No sidebar', 'alpaca' ),
						'with-sidebar-right'	=> esc_html__( 'Right Sidebar', 'alpaca' ),
						'with-sidebar-left'		=> esc_html__( 'Left Sidebar', 'alpaca' )
    				)
    			),
                'alpaca_archive_page_category_post_layout' => array(
    				'type'		=> 'select',
    				'value'	    => 'layout-masonry_column-3_',
    				'label'		=> esc_html__( 'Posts Layout', 'alpaca' ),
    				'choices'	=> array(
                        'layout-standard__' 							=> esc_html__( 'Standard', 'alpaca' ),
                        'layout-full-overlay__' 						=> esc_html__( 'Full Overlay', 'alpaca' ),
                        'layout-zigzag__' 								=> esc_html__( 'Zigzag', 'alpaca' ),
                        'layout-list__' 								=> esc_html__( 'List', 'alpaca' ),
                        'layout-masonry_column-2_'						=> esc_html__( 'Masonry 2 Columns', 'alpaca' ),
                        'layout-masonry_column-3_'						=> esc_html__( 'Masonry 3 Columns', 'alpaca' ),
                        'layout-grid_column-2_' 						=> esc_html__( 'Grid 2 Columns', 'alpaca' ),
                        'layout-grid_column-3_' 						=> esc_html__( 'Grid 3 Columns', 'alpaca' ),
                        'layout-masonry_column-2_first-side-overlay' 	=> esc_html__( 'First Side Overlay + Masonry 2 Columns', 'alpaca' ),
                        'layout-zigzag__first-side-overlay' 			=> esc_html__( 'First Side Overlay + Zigzag', 'alpaca' ),
                        'layout-grid-overlay_column-2_' 				=> esc_html__( 'Grid Overlay 2 Columns', 'alpaca' ),
                        'layout-grid-overlay_column-3_' 				=> esc_html__( 'Grid Overlay 3 Columns', 'alpaca' ),
                        'layout-grid-overlay_column-4_' 				=> esc_html__( 'Grid Overlay 4 Columns', 'alpaca' ),
                        'layout-masonry_column-2_first-full-overlay' 	=> esc_html__( 'First Full Overlay + Masonry 2 Columns', 'alpaca' ),
                        'layout-masonry_column-3_first-full-overlay' 	=> esc_html__( 'First Full Overlay + Masonry 3 Columns', 'alpaca' ),
                        'layout-grid_column-2_first-full-overlay' 		=> esc_html__( 'First Full Overlay + Grid 2 Columns', 'alpaca' ),
                        'layout-grid_column-3_first-full-overlay' 		=> esc_html__( 'First Full Overlay + Grid 3 Columns', 'alpaca' ),
    				)
    			),
                'alpaca_archive_page_category_image_ratio' => array(
                    'type'		=> 'select',
                    'value' 	=> 'img-ratio-3-2',
                    'label'		=> esc_html__( 'Image Ratio', 'alpaca' ),
                    'choices'	=> array(
                        'img-ratio-3-2' => esc_html__( '3:2', 'alpaca' ),
                        'img-ratio-1-1' => esc_html__( '1:1', 'alpaca' ),
                        'img-ratio-2-3' => esc_html__( '2:3', 'alpaca' )
                    ),
                    'dependency' => array( 'alpaca_archive_page_category_post_layout' => array(
                        'layout-grid_column-2_',
                        'layout-grid_column-3_',
                        'layout-grid_column-2_first-full-overlay',
                        'layout-grid_column-3_first-full-overlay',
                        'layout-grid-overlay_column-2_',
                        'layout-grid-overlay_column-3_',
                        'layout-grid-overlay_column-4_',
                        'layout-list__'
                    ) )
                ),
                'alpaca_archive_page_category_grid_style' => array(
                    'type'		=> 'select',
                    'value' 	=> 'grid-style-1',
                    'label'		=> esc_html__( 'Grid Style', 'alpaca' ),
                    'choices'	=> array(
                        'grid-style-1' => esc_html__( 'Style 1', 'alpaca' ),
                        'grid-style-2' => esc_html__( 'Style 2', 'alpaca' )
                    ),
                    'dependency' => array( 'alpaca_archive_page_category_post_layout' => array(
                        'layout-grid_column-2_',
                        'layout-grid_column-3_',
                        'layout-grid_column-2_first-full-overlay',
                        'layout-grid_column-3_first-full-overlay',
                    ) )
                ),
                'alpaca_archive_page_category_grid_overlay_opacity' => array(
                    'type'		=> 'select',
                    'value' 	=> '',
                    'label'		=> esc_html__( 'Overlay Opacity', 'alpaca' ),
                    'choices'	=> array(
                        'no-overlay' => esc_html__( 'No Overlay', 'alpaca' ),
    					'slight-overlay' => esc_html__( 'Slight Overlay', 'alpaca' ),
    					'' => esc_html__( 'Normal Overlay', 'alpaca' )
                    ),
                    'dependency' => array( 'alpaca_archive_page_category_post_layout' => array(
						'layout-grid-overlay_column-2_',
						'layout-grid-overlay_column-3_',
						'layout-grid-overlay_column-4_'
                    ) )
                ),
                'alpaca_archive_page_category_grid_overlay_large_title' => array(
                    'type'	=> 'checkbox',
    				'value'	=> '',
    				'label'	=> esc_html__( 'Large Title', 'alpaca' ),
                    'dependency' => array( 'alpaca_archive_page_category_post_layout' => array(
						'layout-grid-overlay_column-2_',
						'layout-grid-overlay_column-3_',
						'layout-grid-overlay_column-4_'
                    ) )
                ),
                'alpaca_archive_page_category_metas_title' => array(
                    'type'	=> 'title',
                    'label'	=> esc_html__( 'Display selected post meta:', 'alpaca' )
                ),
                'alpaca_archive_page_category_show_category' => array(
                    'type'	=> 'checkbox',
    				'value'	=> 'on',
    				'label'	=> esc_html__( 'Category', 'alpaca' )
                ),
                'alpaca_archive_page_category_show_author' => array(
                    'type'	=> 'checkbox',
    				'value'	=> 'on',
    				'label'	=> esc_html__( 'Author', 'alpaca' )
                ),
                'alpaca_archive_page_category_show_date' => array(
                    'type'	=> 'checkbox',
    				'value'	=> 'on',
    				'label'	=> esc_html__( 'Publish Date', 'alpaca' )
                ),
                'alpaca_archive_page_category_show_update_date' => array(
                    'type'	=> 'checkbox',
    				'value'	=> '',
    				'label'	=> esc_html__( 'Update Date', 'alpaca' )
                ),
                'alpaca_archive_page_category_show_reading_time' => array(
                    'type'	=> 'checkbox',
    				'value'	=> 'on',
    				'label'	=> esc_html__( 'Reading Time', 'alpaca' )
                ),
    			'alpaca_archive_page_category_show_excerpt' => array(
    				'type'			=> 'checkbox',
    				'value'         => 'on',
    				'label'			=> esc_html__( 'Show Post Excerpt', 'alpaca' ),
                    'dependency' => array( 'alpaca_archive_page_category_post_layout' => array(
                        'layout-standard__',
                        'layout-masonry_column-2_',
                        'layout-masonry_column-3_',
                        'layout-masonry_column-2_first-full-overlay',
                        'layout-masonry_column-3_first-full-overlay',
                        'layout-masonry_column-2_first-side-overlay',
                        'layout-grid_column-2_',
                        'layout-grid_column-3_',
                        'layout-grid_column-2_first-full-overlay',
                        'layout-grid_column-3_first-full-overlay',
                        'layout-zigzag__',
                        'layout-list__',
                        'layout-zigzag__first-side-overlay',
                        'layout-full-overlay__'
                    ) )
    			),
    			'alpaca_archive_page_category_show_read_more_button' => array(
    				'type'          => 'checkbox',
    				'value'         => 'on',
    				'label'         => esc_html__( 'Show Read More Button', 'alpaca' ),
                    'dependency' => array( 'alpaca_archive_page_category_post_layout' => array(
                        'layout-standard__',
                        'layout-masonry_column-2_',
                        'layout-masonry_column-3_',
                        'layout-masonry_column-2_first-full-overlay',
                        'layout-masonry_column-3_first-full-overlay',
                        'layout-masonry_column-2_first-side-overlay',
                        'layout-grid_column-2_',
                        'layout-grid_column-3_',
                        'layout-grid_column-2_first-full-overlay',
                        'layout-grid_column-3_first-full-overlay',
                        'layout-zigzag__',
                        'layout-list__',
                        'layout-zigzag__first-side-overlay',
                        'layout-full-overlay__'
                    ) )
    			),
                'alpaca_archive_page_category_posts_per_page' => array(
    				'type'	=> 'number',
    				'value' => get_option( 'posts_per_page', 10 ),
    				'label'	=> esc_html__( 'Show at most x posts per page', 'alpaca' )
    			)
            );
        }
    }
    new Alpaca_Category_Metas();
}
