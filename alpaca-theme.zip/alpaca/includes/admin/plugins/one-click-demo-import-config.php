<?php
function alpaca_ocdi_import_files () {
	$demos 		= array();
	$data_dir 	= trailingslashit( get_template_directory() ) . 'sample-data/';
	$data_uri 	= get_template_directory_uri() . '/sample-data/';
	$configs	= array(
		'Wild World 1' => 'wildworld-1', 'Wild World 2' => 'wildworld-2', 'Wild World 3' => 'wildworld-3', 'Wild World 4' => 'wildworld-4', 'Wild World 5' => 'wildworld-5', 'Wild World 6' => 'wildworld-6', 'Wild World 7' => 'wildworld-7',
		'Perspective 1' => 'perspective-1', 'Perspective 2' => 'perspective-2', 'Perspective 3' => 'perspective-3', 'Perspective 4' => 'perspective-4', 'Perspective 5' => 'perspective-5', 'Perspective 6' => 'perspective-6', 'Perspective 7' => 'perspective-7', 'Perspective 8' => 'perspective-8',
		'Well Living 1' => 'wellliving-1', 'Well Living 2' => 'wellliving-2', 'Well Living 3' => 'wellliving-3', 'Well Living 4' => 'wellliving-4', 'Well Living 5' => 'wellliving-5', 'Well Living 6' => 'wellliving-6',
		'Glamour Women 1' => 'glamourwomen-1', 'Glamour Women 2' => 'glamourwomen-2','Glamour Women 3' => 'glamourwomen-3', 'Glamour Women 4' => 'glamourwomen-4'
	);
	foreach( $configs as $name => $path ) {
		$content 	= $data_dir . $path . '/content.xml';
		$widgets 	= $data_dir . $path . '/widgets.wie';
		$customize 	= $data_dir . $path . '/customizer.dat';
		// translators: %1$s: demo data root uri, %2$s: demo path
		$screenshot = sprintf( '%1$s%2$s/screenshot.jpg', $data_uri, $path );
		$demos[] = array(
			'import_file_name'             => $name,
			'local_import_file'            => $content,
			'local_import_widget_file'     => $widgets,
			'import_preview_image_url'     => $screenshot,
			'local_import_customizer_file' => $customize
		);
	}
	return $demos;
}
add_filter( 'pt-ocdi/import_files', 'alpaca_ocdi_import_files' );


function alpaca_ocdi_after_import_setup( $selected_import ) {
	// Change the default mc4wp form id
	$form_id = alpaca_get_default_mc4wp_form_id();
	if ( ! empty( $form_id ) ) {
		update_option( 'mc4wp_default_form_id', $form_id );

        set_theme_mod( 'alpaca_site_footer_signup_form_id', $form_id );
        set_theme_mod( 'alpaca_popup_signup_form_id', $form_id );
        set_theme_mod( 'alpaca_single_post_signup_form_id', $form_id );
	}

	// Assign menus to their locations.
	$main_menu 		= get_term_by( 'name', 'Main Menu', 'nav_menu' );
	$left_menu 		= get_term_by( 'name', 'Left Menu', 'nav_menu' );
	$social_menu 	= get_term_by( 'name', 'Social Menu', 'nav_menu' );
	$footer_menu 	= get_term_by( 'name', 'Footer Menu', 'nav_menu' );

	set_theme_mod( 'nav_menu_locations', array(
		'primary-menu' 			=> empty( $main_menu ) ? '' : $main_menu->term_id,
		'left-main-menu'		=> empty( $left_menu ) ? '' : $left_menu->term_id,
		'social-menu' 			=> empty( $social_menu ) ? '' : $social_menu->term_id,
		'footer-bottom-menu'	=> empty( $footer_menu ) ? '' : $footer_menu->term_id
	) );
}
add_action('pt-ocdi/after_import', 'alpaca_ocdi_after_import_setup');
