<?php
/**
* Setup post list args
* @param array
*/
function alpaca_setup_post_list_args( $args ) {
	$GLOBALS['alpaca']['post_list'] = $args;
	do_action( 'loftocean_pre_post_list' );
}
add_action( 'alpaca_start_post_list_loop', 'alpaca_setup_post_list_args' );
/**
* Reset post list args
*/
function alpaca_reset_post_list_args() {
	unset( $GLOBALS['alpaca']['post_list'] );
	do_action( 'loftocean_reset_post_list' );
}
add_action( 'alpaca_end_post_list_loop', 'alpaca_reset_post_list_args' );
/**
* Get setting from post list args
* @param string
* @param string
* @return mix
*/
function alpaca_get_post_list_prop( $prop, $default = '' ) {
	if ( isset( $GLOBALS['alpaca'], $GLOBALS['alpaca']['post_list'], $GLOBALS['alpaca']['post_list'][ $prop ] ) ) {
		return $GLOBALS['alpaca']['post_list'][ $prop ];
	} else {
		return $default;
	}
}
/**
* Sets a property in the post list global.
* @param string
* @param string
*/
function alpaca_set_post_list_prop( $prop, $value = '' ) {
	if ( isset( $GLOBALS['alpaca'], $GLOBALS['alpaca']['post_list'] ) ) {
		$GLOBALS['alpaca']['post_list'][ $prop ] = $value;
	}
}
/**
* Display content after post list
*/
function alpaca_after_post_list_content() {
	$layout = alpaca_get_post_list_prop( 'layout', false );
	$nav_style = alpaca_get_theme_mod( 'alpaca_list_pagination_style' );
	if ( ( 'masonry' == $layout ) && in_array( $nav_style, array( 'ajax-manual', 'ajax-auto' ) ) ) :
		global $wp_query;
		$cols = alpaca_get_post_list_prop( 'columns', false );
		$total = $wp_query->post_count;
		$more_cols = $total < $cols ? ( $cols - $total ) : false;
		if ( $more_cols ) :
			for( $i = 0; $i < $more_cols; $i ++ ) : ?>
				<div class="masonry-column"></div><?php
			endfor;
		endif;
	endif;
}
add_action( 'alpaca_after_post_list_content', 'alpaca_after_post_list_content' );
/**
* Get post list layout and column
*/
function alpaca_get_post_list_layout_settings( $page ) {
	$list = alpaca_get_archive_list();
	$default = array( 'layout-standard', '', '' );
	if ( ! empty( $page ) && in_array( $page, $list ) ) {
		$layout = alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_post_layout' );
		$parts = explode( '_', $layout );
		return ( is_array( $parts ) && ( 3 === count( $parts ) ) ) ? $parts : $default;
	}
	return $default;
}
/**
* Get grid layout style
*/
function alpaca_get_post_list_grid_style( $page ) {
	$list = alpaca_get_archive_list();
	if ( ! empty( $page ) && in_array( $page, $list ) ) {
		return alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_grid_style' );
	}
	return '';
}
/**
* Get grid layout image ratio
*/
function alpaca_get_post_list_grid_image_ratio( $page ) {
	$list = alpaca_get_archive_list();
	if ( ! empty( $page ) && in_array( $page, $list ) ) {
		return alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_image_ratio' );
	}
	return '';
}
/**
* Change default excerpt length
*/
function alpaca_excerpt_length( $length ) {
	$layout = alpaca_get_post_list_prop( 'layout' );
	switch ( $layout ) {
		case 'standard':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_standard' ) );
		case 'zigzag':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_zigzag' ) );
		case 'list':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_list' ) );
		case 'grid':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_grid' ) );
		case 'masonry':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_masonry' ) );
		case 'carousel':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_carousel' ) );
		case 'full-overlay':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_overlay' ) );
		case 'widget_slider':
			return absint( alpaca_get_theme_mod( 'alpaca_post_excerpt_length_for_layout_widget_slider' ) );
	}
	return $length;
}
add_filter( 'excerpt_length', 'alpaca_excerpt_length' );
/**
* Chang excerpt text
*/
function alpaca_excerpt_more( $more ) {
	return ' ...';
}
add_filter( 'excerpt_more', 'alpaca_excerpt_more' );
/**
* Get archive page enabled post metas
* @param string archive page type
* @return array
*/
function alpaca_get_list_post_meta( $page ) {
	$metas = array();
	$pages = alpaca_get_archive_list();
	if ( $page && in_array( $page, $pages ) ) {
		$all = array( 'category', 'author', 'date', 'update_date', 'reading_time', 'excerpt', 'read_more_button' );
		foreach( $all as $meta ) {
			if ( alpaca_module_enabled( 'alpaca_archive_page_' . $page . '_show_' . $meta ) ) {
				array_push( $metas, $meta );
			}
		}
	}
	return $metas;
}
/**
* Get post list wrap class
* @param string
* @param array
* @return array
*/
function alpaca_list_get_wrap_class( $page, $sets = array( 'layout-standard', '', '' ) ) {
	$original_layout = $sets[0];
	$sets[0] = 'layout-grid-overlay' == $sets[0] ? 'layout-grid grid-overlay' : $sets[0];
	$class = array_merge( array( 'posts' ), $sets );
	// Check image ratio
	if ( ( false !== strpos( $sets[0], 'layout-grid' ) ) || ( 'layout-list' == $sets[0] ) ) {
		$image_ratio = alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_image_ratio' );
		array_push( $class, $image_ratio );
	}
	// Check grid style
	$grid_style = alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_grid_style' );
	( 'layout-grid' == $sets[0] ) ? array_push( $class, $grid_style ) : '';
	// Check section inner width
	$fullwidth_layouts = array( 'layout-grid-overlay', 'layout-full-overlay' );
	( ! empty( $sets[2] ) ) || in_array( $original_layout, $fullwidth_layouts ) || ( ( 'layout-grid' == $original_layout ) && ( 'grid-style-1' == $grid_style ) ) ? array_push( $class, 'alignfull' ) : '';
	if ( 'layout-grid-overlay' == $original_layout ) {
		$overlay_opacity = alpaca_get_theme_mod( 'alpaca_archive_page_' . $page . '_grid_overlay_opacity' );
		$large_title = alpaca_module_enabled( 'alpaca_archive_page_' . $page . '_grid_overlay_large_title' );
		empty( $overlay_opacity ) ? '' : array_push( $class, $overlay_opacity );
		$large_title ? array_push( $class, 'large-title' ) : '';
	}
	$class = apply_filters( 'alpaca_post_list_wrap_class', $class, $sets );
	return array_unique( array_filter( $class ) );
}
/**
* Get default post list posts class
*/
function alpaca_list_get_default_wrap_class() {
	return array( 'posts', 'layout-standard' );

}
/**
* Get masonry settings
* @param string layout
* @param int column
* @param int offset
* @return mix
*/
function alpaca_get_masonry_settings( $layout, $column, $offset = 0 ) {
	if ( 'masonry' === $layout ) {
		global $wp_query;
		$query = $wp_query;
		$total = $query->post_count;
		$post_index = $query->current_post + 1;
		$is_start = ( 1 === ( $post_index - $offset ) );
		$is_end = ( $post_index === $total );
		$column_ends = alpaca_get_masonry_column_ends( $query, $column, $offset );
		if ( ! $is_start ) {
			foreach( $column_ends as $ce ) {
				if ( 1 == ( $post_index - $ce ) ) {
					$is_start = true;
					break;
				}
			}
		}
		if ( ! $is_end ) {
			foreach( $column_ends as $ce ) {
				if ( $post_index == $ce ) {
					$is_end = true;
					break;
				}
			}
		}
		return apply_filters( 'alpaca_masonry_column_settings', array(
			'is_start' => $is_start,
			'is_end' => $is_end
		), $query );
	}
	return false;
}
/**
* Help function to generate masonry layout necessary column settings
* @param object
* @param int
* @return array
*/
function alpaca_get_masonry_column_ends( $query, $column ) {
	$column_ends = alpaca_get_post_list_prop( 'masonry_column_ends', false );
	if ( empty( $column_ends ) ) {
		$total = $query->post_count;
		$column = empty( $column ) ? 2 : $column;
		$column_ends = array( $total );
		for( $i = $column; $i > 1; $i-- ) {
			$current = floor( $total / $i );
			if ( ! empty( $current ) ) {
				$total -= $current;
				array_unshift( $column_ends, $total );
			}
		}
		alpaca_set_post_list_prop( 'masonry_column_ends', $column_ends );
	}
	return $column_ends;
}
/**
* Pagination type link with page number
*/
function alpaca_list_pagination_classic() {
	$prev_label = esc_html__( 'Prev', 'alpaca' );
	$next_label = esc_html__( 'Next', 'alpaca' );
	$prev_link 	= get_previous_posts_link( $prev_label );
	$next_link 	= get_next_posts_link( $next_label );

	if ( ! empty( $prev_link) || ! empty( $next_link ) ) : ?>
		<nav class="navigation pagination style-links">
			<div class="pagination-container">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts navigation', 'alpaca' ); ?></h2>
				<?php if ( empty( $prev_link ) ) : ?>
					<span class="prev page-numbers"><?php esc_html_e( 'Prev', 'alpaca' ); ?> </span>
				<?php else: ?>
					<?php previous_posts_link( $prev_label ); ?>
				<?php endif; ?>
				<?php echo paginate_links( array( 'prev_next' => false, 'type' => 'plain' ) ); // phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped ?>
				<?php if ( empty( $next_link ) ) : ?>
					<span class="next page-numbers"> <?php esc_html_e( 'Next', 'alpaca' ); ?></span>
				<?php else: ?>
					<?php next_posts_link( $next_label ); ?>
				<?php endif; ?>
			</div>
		</nav> <?php
	endif;
}
/**
* Pagination style ajax loading manually
*/
function alpaca_list_pagination_ajax_manual() {
	if ( alpaca_test_ajax_nav() ) : ?>
		<nav class="navigation pagination">
			<div class="pagination-container load-more">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts Navigation', 'alpaca' ); ?></h2>
				<a href="#" data-no-post-text="<?php esc_attr_e( 'No More Posts', 'alpaca' ); ?>" class="load-more-btn ajax manual">
					<span><?php esc_html_e( 'Load More Posts', 'alpaca' ); ?></span>
				</a>
			</div>
		</nav> <?php
	endif;
}
/**
* Pagination style ajax loading automatically
*/
function alpaca_list_pagination_ajax_auto() {
	if ( alpaca_test_ajax_nav() ) : ?>
		<nav class="navigation pagination">
			<div class="pagination-container load-more infinite">
				<h2 class="screen-reader-text"><?php esc_html_e( 'Posts Navigation', 'alpaca' ); ?></h2>
				<a href="#" data-no-post-text="<?php esc_attr_e( 'No More Posts', 'alpaca' ); ?>" class="load-more-btn ajax">
					<span><?php esc_html_e( 'Load More Posts', 'alpaca' ); ?></span>
				</a>
			</div>
		</nav> <?php
	endif;
}
/**
* Show post List page pagination
*/
function alpaca_list_pagination() {
	$type = alpaca_get_theme_mod( 'alpaca_list_pagination_style' );
	if ( ! empty( $type ) && in_array( $type, array( 'classic', 'ajax-manual', 'ajax-auto' ) ) ) {
		call_user_func( 'alpaca_list_pagination_' . str_replace( '-', '_', $type ) );
	}
}
/**
* Test if show ajax pagination
*/
function alpaca_test_ajax_nav() {
	global $wp_query, $paged;
	$current_page = max( $paged, 1 );
	return $current_page < $wp_query->max_num_pages;
}
/**
* Add class attribute for previous posts link
* @param string
* @return string
*/
function alpaca_prev_posts_link_attrs( $attrs ) {
	return $attrs . ' class="prev page-numbers"';
}
add_filter( 'previous_posts_link_attributes', 'alpaca_prev_posts_link_attrs' );
/**
* Add class attribute for next posts link
* @param string
* @return string
*/
function alpaca_next_posts_link_attrs( $attrs ) {
	return $attrs . ' class="next page-numbers"';
}
add_filter( 'next_posts_link_attributes', 'alpaca_next_posts_link_attrs' );
/**
* Test if current user has avatar image
*/
function alpaca_current_user_has_avatar() {
	$avatar = get_avatar( get_the_author_meta( 'user_email', get_the_author_meta( 'ID' ) ), 60 );
	return ! empty( $avatar );
}
