<?php
if ( ! class_exists( 'Alpaca_Front_Archive' ) ) {
	class Alpaca_Front_Archive {
        /**
        * String current archive page type
        */
        public $page_queried = '';
		/**
		* Array category individual settings
		*/
		protected $cat_settings = array();
		/**
		* Construct function
		*/
		public function __construct() {
			add_filter( 'alpaca_theme_mod', array( $this, 'theme_mod' ), 10, 2 );
			add_filter( 'alpaca_category_individual_settings', array( $this, 'get_category_individual_settings' ), 10, 2 );

            add_action( 'pre_get_posts', array( $this, 'set_archive_page_args' ), 1 );
            add_action( 'template_redirect', array( $this, 'init_hooks' ), 999 );
			add_action( 'alpaca_the_list_content', array( $this, 'the_list_content' ), 10, 1 );
			add_action( 'alpaca_the_list_content_html', array( $this, 'the_list_content_html' ), 10, 2 );
			add_action( 'alpaca_pre_ajax_handler', array( $this, 'pre_ajax_start' ), 99 );
		}
        /**
        * Init hooks for archive pages
        */
        public function init_hooks() {
			if ( ! empty( $this->page_queried ) || is_archive() ) {
                add_filter( 'alpaca_achive_page_queried', array( $this, 'get_page_queried' ) );
                add_filter( 'alpaca_page_layout', array( $this, 'get_page_layout' ) );
				add_filter( 'alpaca_content_class', array( $this, 'content_class' ) );
				add_filter( 'body_class', array( $this, 'body_class' ) );
				add_filter( 'post_class', array( $this, 'post_class' ) );
			}
        }
		/**
		* Action before ajax start
		*/
		public function pre_ajax_start( $page ) {
			$this->page_queried = $page;
			require_once ALPACA_THEME_INC . 'front/functions-post-list.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			require_once ALPACA_THEME_INC . 'front/functions-post-list-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

			add_filter( 'alpaca_achive_page_queried', array( $this, 'get_page_queried' ) );
			add_filter( 'alpaca_content_class', array( $this, 'content_class' ) );
		}
		/**
		* Set arvhice page query args
		* @param object
		*/
		public function set_archive_page_args( $query ) {
			if ( $query->is_main_query() && ! is_admin() ) {
				if ( is_category() ) {
					$this->page_queried = 'category';
					$this->cat_settings = apply_filters( 'alpaca_category_individual_settings', array(), get_queried_object_id() );
				} else if ( is_author() ) {
					$this->page_queried = 'author';
				} else if ( is_search() ) {
                    $this->page_queried = 'search';
					if ( empty( $_REQUEST['post_type'] ) ) {
						$query->set( 'post_type', 'post' );
					}
                } else if ( is_tag() ) {
					$this->page_queried = 'tag';
				} else if ( is_date() ) {
					$this->page_queried = 'date';
				} else if ( alpaca_is_builder_homepage() ) {
					$this->page_queried = 'home';
				} else if ( is_home() && alpaca_is_static_blog_page() ) {
					$this->page_queried = 'blog';
				}
				if ( ! empty( $this->page_queried ) ) {
                    $setting = 'alpaca_archive_page_' . $this->page_queried . '_posts_per_page';
					$query->set( 'posts_per_page', absint( alpaca_get_theme_mod( $setting ) ) );
				}
				remove_action( 'pre_get_posts', array( $this, 'set_archive_page_args' ), 1 );
			}
		}
		/**
		* Get main content layout class
		*/
		public function content_class( $class ) {
			$layout = $this->get_page_layout( '' );
			$class = array_diff( $class, array( 'with-sidebar-right', 'with-sidebar-left' ) );
			if ( ! empty( $this->page_queried ) ) {
				$sidebar_id = apply_filters( 'alpaca_sidebar_id', 'primary-sidebar' );
				if ( ! empty( $layout ) && is_active_sidebar( $sidebar_id ) ) {
					array_push( $class, $layout );
				}
			}
			return $class;
		}
        /**
        * Get archive page requested currently
        * @param string
        * @return string
        */
        public function get_page_queried( $request ) {
            return $this->page_queried;
        }
        /**
        * Get archive page layout
        * @param string
        * @return string
        */
        public function get_page_layout( $layout ) {
            if ( ! empty( $this->page_queried ) ) {
				$always_fullwidth = array( 'layout-zigzag__first-side-overlay', 'layout-masonry_column-2_first-side-overlay' );
				$current_post_layout = alpaca_get_theme_mod( 'alpaca_archive_page_' . $this->page_queried . '_post_layout' );
				$current_layout = alpaca_get_theme_mod( 'alpaca_archive_page_' . $this->page_queried . '_layout' );
				return in_array( $current_post_layout, $always_fullwidth ) ? '' : $current_layout;
            }
            return $layout;
        }
		/**
		* Output the list content
		*/
		public function the_list_content( $page = '' ) {
			$page = empty( $page ) ? $this->page_queried : $page;
			if ( empty( $page ) ) {
				if ( in_array( 'post', (array)get_query_var( 'post_type' ) ) ) {
					$sets = array( 'layout-standard', '', '' );
					$metas = array( 'category', 'author', 'date', 'reading_time', 'excerpt', 'read_more_button' );
					$class = alpaca_list_get_default_wrap_class();
				} else {
					$sets = array( 'layout-standard', '', '' );
					$metas = array();
					$class = alpaca_list_get_default_wrap_class();
				}
			} else {
				$sets = alpaca_get_post_list_layout_settings( $page );
				$metas = alpaca_get_list_post_meta( $page );
				$class = alpaca_list_get_wrap_class( $page, $sets );
			}
			$layout = str_replace( 'layout-', '', $sets[0] );
			$column = str_replace( 'column-', '', $sets[1] );
			$first_style = wp_doing_ajax() ? '' : $sets[2];

			if ( have_posts() ) : ?>
				<div class="<?php echo esc_attr( implode( ' ', $class ) ); ?>"><?php
				do_action( 'alpaca_the_list_content_html', array(
					'layout' => $layout,
					'columns' => $column,
					'post_meta'	=> $metas,
					'first_style' => $first_style,
					'grid_style' => alpaca_get_post_list_grid_style( $page ),
					'grid_image_ratio' => alpaca_get_post_list_grid_image_ratio( $page ),
					'page_layout' => apply_filters( 'alpaca_page_layout', '' )
				) ); ?>
				</div><?php
			else :
				get_template_part( 'template-parts/archive/content-none', $page );
			endif;
		}
		/**
		* Output the list content html
		*/
		public function the_list_content_html( $args, $no_pagination = false ) {
			$masonry_offset = 0;
			do_action( 'alpaca_start_post_list_loop', $args );
			if ( ! empty( $args['first_style'] ) ) {
				the_post();
				$masonry_offset = 1;
				alpaca_set_post_list_prop( 'layout', 'full-overlay' );
				alpaca_set_post_list_prop( 'image_sizes', Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'archive', 'args' => array( 'layout' => $args['first_style'] ) ) ) );
				get_template_part( 'template-parts/archive/content-full-overlay' );
				alpaca_set_post_list_prop( 'layout', $args['layout'] );
			}
			if ( have_posts() ) : ?>
				<div class="posts-wrapper"><?php
				do_action( 'alpaca_before_list_content' );
				alpaca_set_post_list_prop( 'image_sizes', Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'archive', 'args' => $args ) ) );
				while( have_posts() ) {
					the_post();
					alpaca_set_post_list_prop( 'masonry', alpaca_get_masonry_settings( $args['layout'], $args['columns'], $masonry_offset ) );
					get_template_part( 'template-parts/archive/content', $args['layout'] );
				}
				do_action( 'alpaca_after_post_list_content' );
				wp_reset_postdata(); ?>
				</div><?php
				$no_pagination ? '' : alpaca_list_pagination();
			endif;
			wp_reset_postdata();
			do_action( 'alpaca_end_post_list_loop' );
		}
        /**
        * Get category individual settings
        */
        public function get_category_individual_settings( $metas, $term_id ) {
            $enabled = get_term_meta( $term_id, 'alpaca_category_enable_individual_settings', true );
            if ( 'on' == $enabled ) {
                return get_term_meta( $term_id );
            }
            return $metas;
        }
		/**
		* Get theme mod if any setting changed
		*/
		public function theme_mod( $value, $id ) {
			return isset( $this->cat_settings[ $id ][0] ) ? $this->cat_settings[ $id ][0] : $value;
		}
		/**
		* Add class to body classname list
		*/
		public function body_class( $class ) {
			if ( ! empty( $this->page_queried ) ) {
				( 'blog' == $this->page_queried ) ? array_push( $class, 'archive' ) : '';
			}
			return $class;
		}
		/**
		* Add class to post classname list
		*/
		public function post_class( $class ) {
			if ( ! empty( $this->page_queried ) ) {
				$format = get_post_format();
				if ( in_array( alpaca_get_post_list_prop( 'layout', '' ), array( 'full-overlay' ) ) && in_array( $format, array( 'video', 'gallery' ) ) ) {
					if ( apply_filters( 'loftocean_front_has_post_featured_media', false ) ) {
						$class = array_merge( $class, array( 'has-post-thumbnail' ) );
						'video' == $format ? array_push( $class, 'loftocean-video-post' ) : '';
					}
				}
			}
			return $class;
		}
	}
	new Alpaca_Front_Archive();
}
