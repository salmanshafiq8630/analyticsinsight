<?php
/**
* Get post format label for list page
*/
function alpaca_list_format_label( $format, $vid = false ) {
    if ( ! empty( $format ) ) {
        switch ( $format ) {
            case 'video': ?>
                <span class="format-icon"<?php if ( false !== $vid ) : ?> data-alpaca-video-id="video-id-<?php echo esc_attr( $vid ); ?>"<?php endif; ?>>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24"><path d="M128 104.3v303.4c0 6.4 6.5 10.4 11.7 7.2l240.5-151.7c5.1-3.2 5.1-11.1 0-14.3L139.7 97.2c-5.2-3.3-11.7.7-11.7 7.1z"></path></svg>
                </span><?php
                break;
            case 'audio': ?>
                <span class="format-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24"><path d="M256 123.8c-24.3 0-46.9 10.1-63.9 28.4-17 18.3-26.1 33.2-26.1 59.6 0 7.7 5.9 14 13.2 14 7.3 0 13.2-6.3 13.2-14 0-17.3 6.6-32.4 19-43.5 11.8-10.6 27.7-16.5 44.7-16.5s32.9 5.8 44.7 16.5c12.4 11.2 19 26.2 19 43.5 0 7.7 5.9 14 13.2 14 7.3 0 13.2-6.3 13.2-14 0-26.4-9.2-41.3-26.1-59.6-17.2-18.4-39.8-28.4-64.1-28.4z"></path><path d="M457.1 278.9C442.3 264.1 422.8 256 402 256h-8c-2.2 0-4-1.8-4-4v-37.8c0-35.7-14-69.3-39.4-94.7C325.3 94 291.7 80 256 80c-35.7 0-69.3 14-94.6 39.4-25.4 25.4-39.4 59-39.4 94.7V252c0 2.2-1.8 4-4 4h-8c-20.8 0-40.3 8.1-55.1 22.9C40.1 293.7 32 313.2 32 334v11.8c0 20.8 8.1 40.4 22.9 55.2 14.8 14.8 34.4 23 55.1 23h5.6c4 0 8 1.4 10.9 4.1 2.5 2.3 5.9 3.8 9.5 3.8 7.7 0 14-6.3 14-14.1V214.1c0-28.2 11.1-54.8 31.2-74.9 20.1-20.1 46.7-31.2 74.8-31.2 28.2 0 54.8 11.1 74.8 31.2 20.1 20.1 31.2 46.7 31.2 74.9v203.8c0 7.8 6.3 14.1 14 14.1 3.6 0 7-1.5 9.5-3.8 2.9-2.7 6.9-4.1 10.9-4.1h5.6c20.7 0 40.3-8.2 55.1-23 14.8-14.8 22.9-34.4 22.9-55.2V334c0-20.8-8.1-40.3-22.9-55.1z"></path></svg>
                </span> <?php
                break;
            case 'gallery': ?>
                <span class="format-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24"><path d="M457.6 140.2l-82.5-4-4.8-53.8c-1-11.3-11.1-19.2-22.9-18.3L51.5 88.4c-11.8 1-20.3 10.5-19.4 21.7l21.2 235.8c1 11.3 11.2 19.2 22.9 18.3l15-1.2-2.4 45.8c-.6 12.6 9.2 22.8 22.4 23.5L441.3 448c13.2.6 24.1-8.6 24.8-21.2L480 163.5c.6-12.5-9.3-22.7-22.4-23.3zm-354.9 5.3l-7.1 134.8L78.1 305 62 127v-.5-.5c1-5 4.4-9 9.6-9.4l261-21.4c5.2-.4 9.7 3 10.5 7.9 0 .2.3.2.3.4 0 .1.3.2.3.4l2.7 30.8-219-10.5c-13.2-.4-24.1 8.8-24.7 21.3zm334 236.9l-84.8-99.5-37.4 34.3-69.2-80.8-122.7 130.7L133 168v-.4c1-5.4 6.2-9.3 11.9-9l291.2 14c5.8.3 10.3 4.7 10.4 10.2 0 .2.3.3.3.5l-10.1 199.1z"></path><path d="M384 256c17.6 0 32-14.4 32-32s-14.3-32-32-32c-17.6 0-32 14.3-32 32s14.3 32 32 32z"></path></svg>
                </span><?php
                break;
        }
    }
}
/**
* Show featured image as needed
* @param string how to show the featured image as background image or inline image
* @param boolean if is overlay layout
* @return mix video id or boolean false
*/
function alpaca_list_featured_media( $type, $overlay = false, $show_label = false ) {
    $format = get_post_format();
    if ( $overlay ) {
        $video_id = false;
        $show_thumbnail = true;
        if ( apply_filters( 'loftocean_front_has_post_featured_media', false ) ) {
            switch ( $format ) {
                case 'gallery':
                    $show_thumbnail = false;
                    alpaca_list_featured_gallery( $show_label );
                    break;
                case 'video':
                    if ( ! $show_label ) {
                        $show_thumbnail = false;
                        $video_id = apply_filters( 'loftocean_get_current_video_id', false, apply_filters( 'loftocean_front_get_post_featured_media', '' ) );
                        alpaca_list_featured_video( $show_label, $video_id );
                    }
                    break;
            }
        }
        $show_thumbnail && has_post_thumbnail() ? alpaca_list_featured_image( $type, $show_label ) : '';
        return $video_id;
    } else if ( has_post_thumbnail() ) {
        alpaca_list_featured_image( $type, true );
    }
}
/**
* Show featured video if needed
*/
function alpaca_list_featured_video( $show_label = false, $video_id = false ) {
    if ( has_post_thumbnail() ) :
        alpaca_list_featured_image( 'background', $show_label, $video_id );
    else : ?>
        <div class="featured-img">
            <a href="<?php the_permalink(); ?>"><div class="featured-img-container"></div></a>
            <?php $show_label ? alpaca_list_format_label( 'video', $video_id ) : ''; ?>
        </div><?php
    endif;
}
/**
* Show featured gallery if needed
*/
function alpaca_list_featured_gallery( $show_label = false ) { ?>
    <div class="featured-img">
        <a href="<?php the_permalink(); ?>"><?php
        if ( 'standard' == alpaca_get_post_list_prop( 'layout' ) ) :
            do_action( 'loftocean_front_the_post_featured_media', false, '', array( 'no-caption' => true ) );
        else : ?>
            <div class="featured-img-container"><?php do_action( 'loftocean_front_the_post_featured_media', false, '', array( 'no-caption' => true ) ); ?></div><?php
        endif; ?>
        </a>
        <?php $show_label ? alpaca_list_format_label( get_post_format() ) : ''; ?>
    </div><?php
}
/**
* Show featured image as needed
* @param string how to show the featured image as background image or inline image
*/
function alpaca_list_featured_image( $type, $show_label = false, $video_id = false ) {
	$image_sizes = alpaca_get_post_list_prop( 'image_sizes', array( 'full', 'full' ) ); ?>
    <div class="featured-img">
        <a href="<?php the_permalink(); ?>"><?php
	       if ( ! empty( $type ) && ( 'background' === $type ) ) {
               alpaca_the_preload_bg( array( 'id' => get_post_thumbnail_id(), 'class' => 'featured-img-container', 'sizes' => $image_sizes ) );
            } else {
                the_post_thumbnail( $image_sizes[0] );
            } ?>
        </a>
        <?php $show_label ? alpaca_list_format_label( get_post_format(), $video_id ) : ''; ?>
    </div><?php
}
/**
* Show list categories
* @param array metas enabled
* @param array args
*/
function alpaca_list_category( $metas ) {
	if ( in_array( 'category', $metas ) ) {
        alpaca_the_meta_category();
	}
}
/**
* Show list date
*/
function alpaca_list_date( $metas ) {
    if ( in_array( 'date', $metas ) ) : ?>
        <div class="meta-item post-date"><a href="<?php the_permalink(); ?>"><?php echo esc_html( get_the_date() ); ?></a></div>
    <?php endif;
}
/**
* Show list date
*/
function alpaca_list_update_date( $metas ) {
    if ( in_array( 'update_date', $metas ) ) {
        alpaca_the_meta_update_date( in_array( 'date', $metas ) );
    }
}
/**
* Show list reading time
*/
function alpaca_list_reading_time( $metas ) {
    if ( in_array( 'reading_time', $metas ) ) : ?>
        <div class="meta-item read-time"><?php alpaca_the_post_reading_time( get_the_ID() ); ?></div>
    <?php endif;
}
/**
* Show list like icon
*/
function alpaca_list_author( $metas ) {
    if ( in_array( 'author', $metas ) ) {
        alpaca_meta_author();
    }
}
/**
* Show list excerpt text
* @param array metas enabled
*/
function alpaca_list_excerpt( $metas ) {
	if ( in_array( 'excerpt', $metas ) ) : ?>
		<div class="entry-excerpt"><?php the_excerpt(); ?></div> <?php
	endif;
}
/**
* Show list read more button
* @param array metas enabled
*/
function alpaca_list_more_btn( $metas ) {
	if ( in_array( 'read_more_button', $metas ) ) : ?>
        <div class="read-more-btn">
            <a href="<?php the_permalink(); ?>"><span><?php echo esc_html( alpaca_get_theme_mod( 'alpaca_read_more_button_text' ) ); ?></span></a>
        </div><?php
	endif;
}
