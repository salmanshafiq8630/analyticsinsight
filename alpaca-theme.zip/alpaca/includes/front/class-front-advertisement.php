<?php
if ( ! class_exists( 'Alpaca_Front_Advertisement' ) ) {
    class Alpaca_Front_Advertisement {
        /**
        * Boolean identify if rendering advertisement
        */
        protected $render_advertisement = false;
        /**
        * Array locations
        */
        protected $locations = array(
            'before_single_post_content',
            'after_single_post_content',
            'before_single_page_content',
            'after_single_page_content'
        );
        /**
        * Array allowed html
        */
        protected $allowed_html = array(
            'script' => array( 'async' => 1, 'src' => 1, 'type' => 1, 'data-*' => 1 ),
            'ins' => array( 'style' => 1, 'class' => 1, 'data-*' => 1 )
        );
        /**
        * Construct function
        */
        public function __construct() {
			add_filter( 'wp_get_attachment_image_src', array( $this, 'change_advertisement_image_size' ), 999, 4 );
            add_filter( 'alpaca_show_advertisement_before_content', array( $this, 'show_advertisement_before_content' ), 10, 2 );
            add_filter( 'alpaca_show_advertisement_after_content', array( $this, 'show_advertisement_after_content' ), 10, 2 );
			add_action( 'alpaca_the_advertisement', array( $this, 'the_advertisement' ), 10, 1 );
        }
        /**
        * Test if show advertisement before content
        */
        public function show_advertisement_before_content( $show, $pid ) {
            $meta = get_post_meta( $pid, 'alpaca_hide_before_page_content_ad', true );
            return ( 'on' !== $meta );
        }
        /**
        * Test if show advertisement after content
        */
        public function show_advertisement_after_content( $show, $pid ) {
            $meta = get_post_meta( $pid, 'alpaca_hide_after_page_content_ad', true );
            return ( 'on' !== $meta );
        }
        /**
        * Output the advertisement html
        * @param string type
        */
        public function the_advertisement( $location ) {
            if ( in_array( $location, $this->locations ) ) {
                $source = alpaca_get_theme_mod( 'alpaca_ads_source_' . $location );
                if ( 'custom' == $source ) :
                    $url 		= alpaca_get_theme_mod( 'alpaca_ads_custom_url_' . $location );
                    $image_id 	= alpaca_get_theme_mod( 'alpaca_ads_custom_image_' . $location );
                    $target 	= alpaca_module_enabled( 'alpaca_ads_custom_new_tab_' . $location );
                    if ( alpaca_is_item_exists( $image_id ) ) :
                        $this->render_advertisement = true;
                        $this->current_location = $location;
                        $has_link = ! empty( $url ); ?>
                        <div class="alpaca-bannr">
                        <?php if ( $has_link ) : ?>
                            <a href="<?php echo esc_url( $url ); ?>"<?php if ( $target ) : ?> target="_blank"<?php endif; ?>>
                        <?php endif; ?>
                        <?php echo wp_get_attachment_image( $image_id, 'full', false, array( 'class' => '', 'alt' => alpaca_get_image_alt( $image_id ) ) ); // phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped ?>
                        <?php if ( $has_link ) : ?>
                            </a>
                        <?php endif; ?>
                        </div><?php
                        $this->render_advertisement = false;
                        $this->current_location = '';
                    endif;
                else :
                    $content = alpaca_get_theme_mod( 'alpaca_ads_embed_code_' . $location );
                    if ( ! empty( $content ) ) :
						$allowed_html = class_exists( 'Alpaca_Utils_Sanitize' ) ? Alpaca_Utils_Sanitize::get_custom_content_allowed_html() : $this->allowed_html; ?>
                        <div class="alpaca-bannr">
                            <?php echo wp_kses( $content, $allowed_html ); ?>
                        </div> <?php
                    endif;
                endif;
            }
        }
        /**
        * Change image size for adverisement only
        * @param array
        * @param string image id
        * @param mix
        * @param string
        * @return array
        */
        public function change_advertisement_image_size( $image, $id, $size, $icon ) {
            if ( $this->render_advertisement && ! empty( $this->current_location ) ) {
                $width = intval( alpaca_get_theme_mod( 'alpaca_ads_custom_image_width_' . $this->current_location ) );
                if ( ! empty( $image[1] ) ) {
                    $image[2] = $width / $image[1] * $image[2];
                    $image[1] = $width;
                }
            }
            return $image;
        }
    }
    new Alpaca_Front_Advertisement();
}
