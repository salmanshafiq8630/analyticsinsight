<?php
/**
* Builder homepage managet class
*/

if ( ! class_exists( 'Alpaca_Builder_Manager' ) ) {
	class Alpaca_Builder_Manager {
		/**
		* Object instance to make sure only one instance exists
		*/
		public static $instance = false;
		/**
		* Boolean set to true if is builder homepage
		*/
		public $is_builder_homepage = false;
		/**
		* Boolean if builder home query completed
		*/
		public $is_builder_home_query_completed = false;
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'template_redirect', array( $this, 'register_hooks' ), 5 );
			add_action( 'loftocean_posts_block_the_list_content', array( $this, 'the_widget_post_list_content' ), 10, 1 );
			add_action( 'loftocean_slider_block_the_main_slider', array( $this, 'the_widget_slider_main_content' ), 10, 1 );
			add_action( 'loftocean_slider_block_the_navigation', array( $this, 'the_widget_slider_navigation' ), 10, 1 );
		}
		/**
		* Register hooks for slider featured section
		*/
		public function register_hooks( $query ) {
			if ( alpaca_is_builder_homepage() && ( ! $this->is_builder_home_query_completed ) ) {
				$this->is_builder_home_query_completed = true;
				add_filter( 'body_class', array( $this, 'body_class' ) );
				add_filter( 'alpaca_frontend_get_page_layout', array( $this, 'get_page_layout' ) );
				add_action( 'loftocean_builder_homepage_after_main_content', array( $this, 'load_latest_posts' ), 5, 1 );
			}
		}
		/**
		* Load latest post section
		*/
		public function load_latest_posts( $page ) {
			if ( in_array( $page, array( 'loftbuilder-front', 'homepage' ) ) && ! alpaca_module_enabled( 'alpaca_archive_page_home_hide_main_section' ) ) {
				$title = alpaca_get_theme_mod( 'alpaca_archive_page_home_section_title' );
				$sub_title = alpaca_get_theme_mod( 'alpaca_archive_page_home_section_sub_title' );
				$has_title = ! empty( $title );
				$has_sub_title = ! empty( $sub_title );
				$args = apply_filters( 'alpaca_frontend_homepage_query_posts_args', array(
					'paged' => max( 1,  intval( get_query_var( 'paged' ) ) ),
					'post_type' => 'post',
					'post_status' => is_user_logged_in() ? array( 'publish', 'private' ) : 'publish',
					'posts_per_page' => absint( alpaca_get_theme_mod( 'alpaca_archive_page_home_posts_per_page' ) ),
					'ignore_sticky_posts' => false
				) );
				query_posts( $args ); ?>
                <div class="main">
                	<div class="container">
                		<div id="primary" class="primary content-area"><?php
							if ( $has_title || $has_sub_title ) : ?>
								<div class="section-header">
									<?php if ( $has_title ) : ?><h5 class="section-title"><?php echo esc_html( $title ); ?></h5><?php endif; ?>
									<?php if ( $has_sub_title ) : ?><p class="section-sub-title"><?php echo esc_html( $sub_title ); ?></p><?php endif; ?>
								</div><?php
							endif;
							do_action( 'alpaca_the_list_content', 'home' ); ?>
						</div>
                        <?php get_sidebar(); ?>
                    </div>
                </div><?php
				wp_reset_query();
			}
		}
		/**
		* Output the homepage widget post list content
		* @param array settings
		*/
		public function the_widget_post_list_content( $sets ) {
			if ( have_posts() ) :
				$this->check_required(); ?>
				<div class="<?php echo esc_attr( implode( ' ', $sets['wrap_class'] ) ); ?>"<?php do_action( 'loftocean_posts_wrap_attributes' ); ?>>
					<?php do_action( 'alpaca_the_list_content_html', $sets['args'], true ); ?>
				</div><?php
			endif;
		}
		/**
		* Output the homepage widget slider main content
		* @param array settings
		*/
		public function the_widget_slider_main_content( $sets ) {
			if ( isset( $sets, $sets['query'], $sets['metas'] ) && $sets['query']->have_posts() ) {
				$this->check_required();
				do_action( 'alpaca_start_post_list_loop', array(
					'metas' => $sets['metas'],
					'layout' => 'widget_slider',
					'image_sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'archive', 'args' => array( 'layout' => 'widget_slider' ) ) )
				) );
				while ( $sets['query']->have_posts() ) {
					$sets['query']->the_post();
					alpaca_set_post_list_prop( 'current_index', $sets['query']->current_post );
					get_template_part( 'template-parts/archive/content-slider', 'main' );
				}
				wp_reset_postdata();
				do_action( 'alpaca_end_post_list_loop' );
			}
		}
		/**
		* Output the homepage widget post list content
		* @param array settings
		*/
		public function the_widget_slider_navigation( $sets ) {
			if ( isset( $sets, $sets['query'], $sets['metas'] ) && $sets['query']->have_posts() ) {
				$this->check_required();
				do_action( 'alpaca_start_post_list_loop', array(
					'metas' => $sets['metas'],
					'layout' => 'widget_slider',
					'image_sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'archive', 'args' => array( 'layout' => 'widget_slider' ) ) )
				) );
				while ( $sets['query']->have_posts() ) {
					$sets['query']->the_post();
					get_template_part( 'template-parts/archive/content-slider', 'navigation' );
				}
				wp_reset_postdata();
				do_action( 'alpaca_end_post_list_loop' );
			}
		}
		/**
		* Modify body class names
		* @param array
		* @return array
		*/
		public function body_class( $class ) {
			$remove = array( 'archive', 'post-type-archive', 'post-type-archive-post' );
			$class = array_diff( $class, $remove );
			return array_merge( $class, array( 'front-page', 'home' ) );
		}
		/**
		* Get page layout for builder homepage
		* @param string layout
		* @return string layout
		*/
		public function get_page_layout( $layout ) {
			$always_fullwidth = array( 'layout-zigzag__first-side-overlay', 'layout-masonry_column-2_first-side-overlay' );
			$current_post_layout = alpaca_get_theme_mod( 'alpaca_archive_page_home_post_layout' );
			$current_layout = alpaca_get_theme_mod( 'alpaca_archive_page_home_layout' );
			return in_array( $current_post_layout, $always_fullwidth ) ? '' : $current_layout;
		}
		/**
		* Check required function added
		*/
		protected function check_required() {
			if ( ! function_exists( 'alpaca_the_meta_category' ) ) {
				require_once ALPACA_THEME_INC . 'front/functions.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
				require_once ALPACA_THEME_INC . 'front/functions-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
				require_once ALPACA_THEME_INC . 'front/functions-post-list.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
				require_once ALPACA_THEME_INC . 'front/functions-post-list-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
			}
		}
		/**
		* Static function to make sure only one instance exists
		* @return object
		*/
		public static function _instance() {
			if ( false === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
	}
	Alpaca_Builder_Manager::_instance();
}
