<?php
/**
* Body open action
*/
function alpaca_body_open() {
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	} else {
		do_action( 'wp_body_open' );
	}
}
/**
* Condition function to test if have logo set
*/
function alpaca_has_site_header_logo() {
	$default_logo_id = get_theme_mod( 'custom_logo' );
	if ( alpaca_is_item_exists( $default_logo_id ) ) {
		return true;
	}
	$logos = array(
		'alpaca_site_header_light_desktop_logo',
		'alpaca_site_header_light_mobile_logo',
		'alpaca_site_header_dark_desktop_logo',
		'alpaca_site_header_dark_mobile_logo'
	);
	foreach ( $logos as $l ) {
		$logo_id = alpaca_get_theme_mod( $l );
		if ( ! alpaca_is_item_exists( $logo_id ) ) {
			return false;
		}
	}
	return true;
}
/**
* Show site logo group
*/
function alpaca_the_site_logo_group() {
	$default_logo_id = get_theme_mod( 'custom_logo' );
	$has_default_logo = alpaca_is_item_exists( $default_logo_id );
	$desktop_logo_width = max( absint( alpaca_get_theme_mod( 'alpaca_site_header_logo_desktop_width' ) ), 1 );
	$mobile_logo_width = max( absint( alpaca_get_theme_mod( 'alpaca_site_header_logo_mobile_width' ) ), 1 );
	$logos = array(
		'alpaca_site_header_light_desktop_logo' => array( 'class' => 'custom-logo desktop-logo light-logo', 'size' => array( $desktop_logo_width, 999999 ) ),
		'alpaca_site_header_light_mobile_logo' => array( 'class' => 'custom-logo mobile-logo light-logo', 'size' => array( $mobile_logo_width, 999999 ) ),
		'alpaca_site_header_dark_desktop_logo' => array( 'class' => 'custom-logo desktop-logo dark-logo', 'size' => array(  $desktop_logo_width, 999999 ) ),
		'alpaca_site_header_dark_mobile_logo' => array( 'class' => 'custom-logo mobile-logo dark-logo', 'size' => array(  $mobile_logo_width, 999999 ) )
	);
    foreach ( $logos as $logo => $logo_attr ) {
		$logo_id = alpaca_get_theme_mod( $logo );
		$logo_exists = alpaca_is_item_exists( $logo_id );
		if ( $logo_exists || $has_default_logo ) {
			alpaca_the_site_logo(
				$logo_exists ? $logo_id : $default_logo_id,
				$logo_attr['size'],
				$logo_attr['class']
			);
		}
	}
}
/**
* Show logo
*/
function alpaca_the_site_logo( $image_id, $size, $class ) {
	$logo_image = get_post( $image_id );
	echo wp_get_attachment_image( $image_id, $size, '', array( 'class' => $class ) );
}
/**
* Output class attributes
* @param array default value
* @param string filter name
*/
function alpaca_the_class( $val = array(), $filter = '' ) {
	if ( ! empty( $filter ) ) {
		$class = apply_filters( $filter, $val );
	}
	$class = array_unique( array_filter( $class ) );
	if ( ! empty( $class ) ) {
		printf( ' class="%s"', esc_attr( implode( ' ', $class ) ) );
	}
}
/**
* Custom classes for <html>
*/
function alpaca_the_html_class() {
	$class = array( 'no-js', 'no-svg' );
	if ( wp_is_mobile() ) {
		array_push( $class, 'mobile' );
	}
	alpaca_the_class( $class, 'alpaca_get_html_class' );
}
/**
* Custom classes for site header
*/
function alpaca_the_site_header_class() {
	$class = array( 'site-header' );
	$color_scheme = alpaca_get_theme_mod( 'alpaca_site_header_color_scheme' );
	if ( ! empty( $color_scheme ) ) {
		array_push( $class, $color_scheme );
	}
	alpaca_the_class( $class, 'alpaca_get_site_header_class' );
}
/**
* Custom classes for site header container
*/
function alpaca_the_site_header_main_class() {
	$class = array( 'site-header-main' );
	if ( alpaca_is_site_header_image_exists() ) {
		array_push( $class, 'with-bg' );
	}
	alpaca_the_class( $class, 'alpaca_get_site_header_main_class' );
}
/**
* Custom classes for site branding
*/
function alpaca_the_site_branding_class() {
	$class = array( 'site-branding' );

	if ( ! display_header_text() ) {
		array_push( $class, 'hide-title-tagline' );
	}
	alpaca_the_class( $class, 'alpaca_get_site_branding_class' );
}
/**
* Custom classes for div#content
*/
function alpaca_the_content_class() {
	$class = array( 'site-content' );
	alpaca_the_class( $class, 'alpaca_content_class' );
}
/**
* Classname for site main sidebar
*/
function alpaca_the_site_sidebar_class() {
	alpaca_the_class( array( 'sidebar', 'widget-area' ), 'alpaca_get_sidebar_class' );
}
/**
* Classname for site main sidebar
*/
function alpaca_the_page_header_class( $class = '' ) {
	$header_class = array( 'header-img', 'featured-img', 'parallax-scroll' );
	alpaca_module_enabled( 'alpaca_general_enable_header_entrance_animation' ) ? array_push( $header_class, 'intro-animation' ) : '';
	empty( $class ) ? '' : array_push( $header_class, $class );
	alpaca_the_class( $header_class, 'alpaca_get_page_header_class' );
}
/**
* Attributes for site main sidebar
*/
function alpaca_the_site_sidebar_attributes() {
	if ( alpaca_module_enabled( 'alpaca_sidebar_enable_sticky' ) ) {
		echo ' data-enable-sticky-sidebar="on"';
	}
}
/**
* Condition function if show sidebar
* @return boolean
*/
function alpaca_show_sidebar() {
	$page_layout = apply_filters( 'alpaca_page_layout', '' );
	return apply_filters( 'alpaca_show_sidebar', ! empty( $page_layout ) );
}
/**
* Attributes for site header
*/
function alpaca_the_site_header_attrs() {
	$attrs = apply_filters( 'alpaca_get_site_header_attrs', array() );
	foreach ( $attrs as $name => $value ) {
		$name = ' ' . trim( $name );
		echo esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
	}
}
/**
* Test if given menu exists
* @param string menu location
* @return boolean
*/
function alpaca_has_nav_menu( $location ) {
	$locations = get_nav_menu_locations();
	if ( $location && $locations && isset( $locations[ $location ] ) ) {
	   $menu = wp_get_nav_menu_object( $locations[ $location ] );
	   return $menu !== false;
	}
	return false;
}
/**
* Output social menu
* @return array
*/
function alpaca_the_socials( $args = array() ) {
	if ( alpaca_has_nav_menu( 'social-menu' ) ) {
		return wp_nav_menu( array_merge( array(
			'theme_location' 	=> 'social-menu',
			'depth' 			=> 1,
			'echo' 				=> false
		), $args ) );
	}
}
/**
* Output social menu
*/
function alpaca_social_menu( $args = array() ) {
	alpaca_the_socials( array_merge( array(
		'container' 		=> 'nav',
		'container_class' 	=> 'social-navigation',
		'menu_id' 			=> 'menu-social-menu',
		'menu_class' 		=> 'social-nav menu',
		'echo'				=> true
	), $args ) );
}
/**
* Show primary nav
* @param array
* @param string
* @param string
* @param boolean
*/
function alpaca_primary_nav( $args = array(), $before = '', $after = '', $show_mega_menu = false ) {
	if ( alpaca_has_nav_menu( 'primary-menu' ) ) {
		$walker = $show_mega_menu ? ( new Alpaca_Mega_Walker_Nav_Menu() ) : ( new Alpaca_Walker_Nav_Menu() );
		$menu_wrap_allowed_html = array( 'div' => array( 'class' => 1, 'id' => 1, 'data-*' => 1 ) );
		echo wp_kses( $before, $menu_wrap_allowed_html );
		wp_nav_menu( array_merge( array(
			'echo'				=> true,
			'theme_location' 	=> 'primary-menu',
			'container' 		=> 'nav',
			'container_id' 		=> 'site-navigation',
			'container_class' 	=> 'main-navigation',
			'menu_id' 			=> 'menu-main-menu',
			'menu_class' 		=> 'primary-menu',
			'depth' 			=> 3,
			'walker' 			=> $walker
		), $args ) );
		echo wp_kses( $after, $menu_wrap_allowed_html );
	}
}
/**
* Test current taxonomy has featured image
* @return boolean
*/
function alpaca_has_term_featured_image() {
	if ( is_category() || is_tag() ) {
		$taxonomy = is_category() ? 'category' : 'post_tag';
		$term = get_term( get_queried_object_id(), $taxonomy );
		return apply_filters( 'loftocean_taxonomy_has_image', false, $term );
	}
	return false;
}
/**
* Condition function if site header image setted
* @return boolean
*/
function alpaca_is_site_header_image_exists() {
	$image = get_theme_mod( 'header_image' );
	return ! empty( $image ) && ( 'remove-header' != $image );
}
/**
* Condition functio whether mailchimp for wp plugin activated and the site footer bottom signup form enabled
* @return boolean
*/
function alpaca_is_site_footer_signup_form_enabled() {
	if ( alpaca_module_enabled( 'alpaca_site_footer_enable_signup_form' ) && alpaca_is_mc4wp_activated() ) {
		$form_id = alpaca_get_theme_mod( 'alpaca_site_footer_signup_form_id' );
		return alpaca_is_item_exists( $form_id );
	}
	return false;
}
/**
* Output html attributes
* @param array list of attributes
*/
function alpaca_the_html_attributes( $attrs = array() ) {
	if ( alpaca_is_valid_array( $attrs ) ) {
		foreach ( $attrs as $key => $value ) {
			if ( ! empty( $key ) ) {
				printf( ' %s="%s" ', esc_attr( $key ), esc_attr( $value ) );
			}
		}
	}
}
/**
* Get enable social sharing icons
*/
function alpaca_get_enabled_sharing() {
	$enabled = array();
	$metas = array(
		'alpaca_general_social_like' 		=> 'like',
		'alpaca_general_social_facebook' 	=> 'facebook',
		'alpaca_general_social_twitter' 	=> 'twitter',
		'alpaca_general_social_pinterest' 	=> 'pinterest',
		'alpaca_general_social_whatsapp' 	=> 'whatsapp',
		'alpaca_general_social_reddit' 		=> 'reddit',
		'alpaca_general_social_email' 		=> 'email',
		'alpaca_general_social_linkedin' 	=> 'linkedin',
	);
	foreach( $metas as $mn => $m ) {
		if ( alpaca_module_enabled( $mn ) ) {
			array_push( $enabled, $m );
		}
	}
	return $enabled;
}
/**
* If signup for single post enabled
*/
function alpaca_is_single_signup_form_enabled() {
	if ( alpaca_is_mc4wp_activated() && alpaca_module_enabled( 'alpaca_single_post_show_signup_form' ) ) {
		$form_id = alpaca_get_theme_mod( 'alpaca_single_post_signup_form_id' );
		return alpaca_is_item_exists( $form_id );
	}
	return false;
}
/**
* Condition function test if popup signup form enabled
*/
function alpaca_is_popup_signup_form_enabled() {
	if ( alpaca_is_mc4wp_activated() ) {
		$form_id = alpaca_get_theme_mod( 'alpaca_popup_signup_form_id' );
		$is_preview = alpaca_is_customize_preview();
		$auto_display = alpaca_module_enabled( 'alpaca_popup_signup_form_auto_display' );
		$site_header_popup_button = alpaca_module_enabled( 'alpaca_site_header_show_popup_signup_form_button' );
		return ( alpaca_is_item_exists( $form_id ) && ( $auto_display || $site_header_popup_button ) ) || $is_preview;
	}
	return false;
}
/**
* Get custom archive page list
*/
function alpaca_get_archive_list() {
	return array( 'category', 'tag', 'author', 'search', 'date', 'blog', 'home' );
}
/**
* Conditional function if featured section slider have metas
*/
function alpaca_featured_slider_has_meta( $metas ) {
	if ( alpaca_is_valid_array(  $metas ) ) {
		$has_comment = get_comments_number() || comments_open();
		return ( count( $metas ) == 1 ) && in_array( 'comment', $metas ) && ! $has_comment ? false : true;
	}
	return false;
}
/**
* Get author metas
*/
function alpage_get_author_metas() {
	$author_id = get_the_author_meta( 'ID' );
	$author_email = get_the_author_meta( 'user_email', $author_id );
	return array(
		'ID' => $author_id,
		'email' => $author_email,
		'avatar' => get_avatar( $author_email, 150 ),
		'url' => get_author_posts_url( $author_id ),
		'name' => get_the_author()
	);
}
/**
* Get current post reading time
*/
function alpaca_the_post_reading_time( $pid ) {
	$reading_settings = alpaca_reading_speed_settings( $pid );
	$content = get_the_content( null, false, $pid ); //get_post_field( 'post_content', $pid );
	$content = strip_tags( $content );
	$word_count = ( 'characters' == $reading_settings['unit'] ) ? strlen( utf8_decode( $content ) ) : str_word_count( $content );

	$reading_speed = absint( $reading_settings['speed'] );
	if ( $reading_speed < 1 ) {
		$reading_speed = 300;
	}
	$mins = ceil( $word_count / $reading_speed );
	if ( $mins > 1 ) {
		// translators: reading time with unit minuter
		$string = sprintf( esc_html__( '%s mins read', 'alpaca' ), absint( $mins ) );
		echo esc_html( $string );
	} else {
		esc_html_e( '< 1 min read', 'alpaca' );
	}
}
/**
* Get post content counting by settings
*/
function alpaca_reading_speed_settings( $pid ) {
	if ( 'custom' === get_post_meta( $pid, 'alpaca_post_content_reading_setting', true ) ) {
		return array( 'speed' => get_post_meta( $pid, 'alpaca_reading_speed_per_minute', true ), 'unit' => get_post_meta( $pid, 'alpaca_reading_speed_unit', true ) );
	} else {
		return array( 'speed' => alpaca_get_theme_mod( 'alpaca_reading_speed_per_minute' ), 'unit' => alpaca_get_theme_mod( 'alpaca_reading_speed_unit' ) );
	}
}
/**
* Get post authors
* @return object array users
*/
function alpaca_get_post_authors() {
	$orignal_author = get_the_author_meta( 'ID' );
	if ( has_filter( 'loftocean_get_post_authors' ) ) {
		$ids = apply_filters( 'loftocean_get_post_authors', array() );
		if ( count( $ids ) > 1 ) {
			$authors = get_users( array( 'include' => $ids, 'orderby' => 'display_name' ) );
			$alt_authors = array();
			foreach ( $authors as $author ) {
				$author->ID == $orignal_author ? array_unshift( $alt_authors, $author ) : array_push( $alt_authors, $author );
			}
			return $alt_authors;
		}
	}
	return get_users( array( 'include' => array( $orignal_author ) ) );
}
/**
* If show the more toggle button for site header more section
*/
function alpaca_show_more_toggle_button( $show ) {
    $header_layout = alpaca_get_theme_mod( 'alpaca_site_header_layout' );
    return in_array( $header_layout, array( 'vertical-bar', 'vertical-wide' ) ) && alpaca_module_enabled( 'alpaca_site_header_fold_more_buttons' );
}
