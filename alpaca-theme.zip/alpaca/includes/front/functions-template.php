<?php
if ( ! function_exists( 'alpaca_get_preload_bg' ) ) :
	/**
	* Return the html tag with image as background image for better user experience
	* Create your own function to override in a child theme.
	* @since 1.0.0
	* @param array settings
	* 		id 		int, 	image id
	* 		size 	string, image size
	*		class 	string, html tag class name
	*		html 	string, html string inside tag
	*		tag 	string, html tag
	*		attrs 	array, 	html tag attributes
	*/
	function alpaca_get_preload_bg( $args = array() ) {
		$default_sizes = array( 'full', 'full' );
		$options 	= array_merge( array(
			'id' 	=> null,
			'sizes' => $default_sizes,
			'class' => 'featured-img-container',
			'tag' 	=> 'div'
		), $args );

		$image_id = empty( $options['id'] ) ? get_post_thumbnail_id() : $options['id'];
		$image_sizes = empty( $options['sizes'] ) ? $default_sizes : $options['sizes'];
		$options['tag'] = empty( $options['tag'] ) ? 'div' : $options['tag'];

		if ( has_filter( 'loftocean_media_get_background_image' ) ) {
			unset( $options['id'], $options['size'] );
			return apply_filters( 'loftocean_media_get_background_image', '', $image_id, $image_sizes, $options );
		} else {
			if ( alpaca_is_item_exists( $image_id ) ) {
				$image_src = alpaca_get_image_src( $image_id, $image_sizes[0] );
				$styles = sprintf( 'background-image: url(%s);', esc_url( $image_src ) );
				if ( ! empty( $options['attrs']['style'] ) ) {
					$styles .= ' ' . $options['attrs']['style'];
				}
				return sprintf(
					'<%1$s class="%2$s" style="%3$s"></%1$s>',
					esc_attr( $options['tag'] ),
					esc_attr( $options['class'] ),
					esc_attr( $styles )
				);
			}
		}
	}
endif;

if ( ! function_exists( 'alpaca_the_preload_bg' ) ) :
	/**
	* Output the html tag with image as background image for better user experience
	* Create your own function to override in a child theme.
	* @since 1.0.0
	* @param array settings
	* 		id 		int, 	image id
	* 		size 	string, image size
	*		class 	string, html tag class name
	*		html 	string, html string inside tag
	*		tag 	string, html tag
	*		attrs 	array, 	html tag attributes
	*/
	function alpaca_the_preload_bg( $args = array() ) {
		$default_sizes = array( 'full', 'full' );
		$options 	= array_merge( array(
			'id' 	=> null,
			'sizes' => $default_sizes,
			'class' => 'featured-img-container',
			'tag' 	=> 'div',
			'attrs' => ''
		), $args );

		$image_id = empty( $options['id'] ) ? get_post_thumbnail_id() : $options['id'];
		$image_sizes = empty( $options['sizes'] ) ? $default_sizes : $options['sizes'];
		$options['tag'] = empty( $options['tag'] ) ? 'div' : $options['tag'];

		if ( has_action( 'loftocean_media_the_background_image' ) ) {
			unset( $options['id'], $options['size'] );
			do_action( 'loftocean_media_the_background_image', $image_id, $image_sizes, $options );
		} else {
			if ( alpaca_is_item_exists( $image_id ) ) :
				$image_src = alpaca_get_image_src( $image_id, $image_sizes[0] );
				$styles = sprintf( 'background-image: url(%s);', esc_url( $image_src ) );
				if ( ! empty( $options['attrs']['style'] ) ) {
					$styles .= ' ' . $options['attrs']['style'];
				} ?>
				<<?php echo esc_attr( $options['tag'] ); ?>
					<?php if ( ! empty( $options['class'] ) ) : ?> class="<?php echo esc_attr( $options['class'] ); ?>"<?php endif; ?>
					style="<?php echo esc_attr( $styles ); ?>"
					<?php alpaca_the_html_attributes( $options['attrs'] ); ?>
				></<?php echo esc_attr( $options['tag'] ); ?>><?php
			endif;
		}
	}
endif;

if ( ! function_exists( 'alpaca_the_background_image_attrs' ) ) :
	/**
	* Get html attributes for preload image
	* Create your own function to override in a child theme.
	* @since 1.1.0
	* @param array settings
	* 		id 		int, 	image id
	* 		sizes 	string, image size
	* @param boolean flag identify use call preloader image filter(if exists)
	* @return html element attributes string
	*/
	function alpaca_the_background_image_attrs( $args = array() ) {
		$default_image_sizes = array( 'full', 'full' );
		$options = array_merge( array (
			'id' 	=> null,
			'sizes' => $default_image_sizes
		), $args );

		$image_id = empty( $options['id'] ) ? get_post_thumbnail_id() : $options['id'];
		$image_sizes = empty( $options['sizes'] ) || ! is_array( $options['sizes'] ) ? $default_image_sizes : $options['sizes'];

		if ( has_action( 'loftocean_media_the_background_image_attrs' ) ) {
			do_action( 'loftocean_media_the_background_image_attrs', $image_id, $image_sizes );
		} else {
			$image_src = alpaca_get_image_src( $image_id, $image_sizes[0] );
			printf( ' style="background-image: url(%s);"', esc_url( $image_src ) );
		}
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_image_caption' ) ) :
	/**
	* Output single post image caption
	*/
	function alpaca_the_single_featured_image_caption() {
		$caption = wp_get_attachment_caption( get_post_thumbnail_id() );
		$caption_allowed_html = array( 'span' => array( 'class' => 1 ), 'sub' => array(), 'sup' => array(), 'em' => array(), 'strong' => array(), 'i' => array(), 'b' => array() );
		if ( ! empty( $caption ) ) : ?>
			<span class="featured-img-caption"><?php echo wp_kses( $caption, $caption_allowed_html ); ?></span><?php
		endif;
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_video_button' ) ) :
	/**
	* Output single post play video button
	*/
	function alpaca_the_single_featured_video_button( $class = '' ) {
		$video_id = apply_filters( 'loftocean_get_current_video_id', '', apply_filters('loftocean_front_get_post_featured_media', '' ) ); ?>
		<div
			class="featured-video-play-btn<?php if ( ! empty( $class ) ) : ?> <?php echo esc_attr( $class ); ?><?php endif; ?>"
			data-loftocean-video-id="video-id-<?php echo esc_attr( $video_id ); ?>"
		>
			<div class="play-btn"><span class="play-btn-text"><?php esc_html_e( 'Watch Video', 'alpaca' ); ?></span></div>
			<div class="border-outline"></div>
			<div class="play-arrow"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="24" height="24"><path d="M128 104.3v303.4c0 6.4 6.5 10.4 11.7 7.2l240.5-151.7c5.1-3.2 5.1-11.1 0-14.3L139.7 97.2c-5.2-3.3-11.7.7-11.7 7.1z"></path></svg></div>
		</div><?php
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_audio' ) ) :
	/**
	* Output single post audio
	*/
	function alpaca_the_single_featured_audio( $class = '' ) { ?>
		<div class="header-audio"><?php do_action( 'loftocean_front_the_post_featured_media', false ); ?></div><?php
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_background_image' ) ) :
	/**
	* Output single page/post featured image
	*/
	function alpaca_the_single_featured_background_image( $class = '', $media_args = array(), $template = '' ) {
		$is_audio = ! empty( $media_args['audio'] );
		$has_video_btn = ( ! empty( $media_args['video'] ) ) && ( ! empty( $media_args['video']['has-play-btn'] ) );
		$audio_with_image = $is_audio && ( ! empty( $media_args['audio']['with-image'] ) );
		$audio_without_image = $is_audio && ( ! $audio_with_image ); ?>

		<div<?php alpaca_the_page_header_class( $class ); ?>><?php
			if ( has_post_thumbnail() ) : ?>
				<div class="header-img-container">
					<?php alpaca_the_preload_bg( array( 'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => ( empty( $template ) ? 'page-header' : $template . '-page-header' ) ) ) ) ); ?>
				</div><?php
			elseif ( isset( $media_args['video'] ) || isset( $media_args['audio'] ) ) : ?>
				<div class="header-img-container">
					<div class="featured-img-container"></div>
				</div><?php
			endif;
			$audio_with_image ? alpaca_the_single_featured_audio() : '';
			$has_video_btn ? alpaca_the_single_featured_video_button() : '';
			alpaca_the_single_featured_image_caption(); ?>
		</div><?php
		$audio_without_image ? alpaca_the_single_featured_audio() : '';
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_responsive_image' ) ) :
	/**
	* Output single page/post featured image
	*/
	function alpaca_the_single_featured_responsive_image( $class = '', $media_args = array() ) {
		$has_video_btn = ( ! empty( $media_args['video'] ) ) && ( ! empty( $media_args['video']['has-play-btn'] ) );
		$audio_with_image = ( ! empty( $media_args['audio'] ) ) && ( ! empty( $media_args['audio']['with-image'] ) ); ?>

		<div<?php alpaca_the_page_header_class( $class ); ?>><?php
			if ( has_post_thumbnail() ) : ?>
				<div class="header-img-container">
					<div class="featured-img-container">
						<?php the_post_thumbnail( Alpaca_Utils_Image::get_image_size( array( 'module' => 'singular', 'sub_module' => 'header' ) ) ); ?>
					</div>
				</div><?php
			elseif ( isset( $media_args['video'] ) || isset( $media_args['audio'] ) ): ?>
				<div class="header-img-container">
					<div class="featured-img-container"></div>
				</div><?php
			endif;
			$audio_with_image ? alpaca_the_single_featured_audio() : '';
			$has_video_btn ? alpaca_the_single_featured_video_button() : '';
			alpaca_the_single_featured_image_caption(); ?>
		</div><?php
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_gallery' ) ) :
	/**
	* Print featured media if needed
	* 	Create your own function to override in a child theme.
	*/
	function alpaca_the_single_featured_gallery( $template = '', $class = '', $args = array() ) {  ?>
		<div<?php alpaca_the_page_header_class( $class ); ?>>
			<div class="header-img-container">
				<div class="featured-img-container"><?php do_action( 'loftocean_front_the_post_featured_media', false, $class, $args ); ?></div>
			</div>
		</div><?php
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_media' ) ) :
	/**
	* Print featured media if needed
	* 	Create your own function to override in a child theme.
	*/
	function alpaca_the_single_featured_media( $template = '' ) {
		$format = get_post_format();
		switch ( $format ) {
			case 'gallery':
				$class = '';
				$args = array();
				if ( 'normal' == $template ) {
					$class = 'multi-img-gallery';
					$args['multi-image-gallery'] = true;
				}
				alpaca_the_single_featured_gallery( $template, $class, $args );
				break;
			case 'video':
			case 'audio':
				if ( 'audio' == $format ) {
					$class = ( 'normal' == $template ) ? '' : 'has-audio-player';
					$media_args = array( 'audio' => array( 'with-image' => in_array( $template, array( 'wide', 'normal' ) ) ) );
				} else {
					$class = 'has-play-btn';
					$media_args = array( 'video' => array( 'has-play-btn' => in_array( $template, array( 'wide', 'normal' ) ) ) );
				}
				if ( 'normal' == $template ) {
					alpaca_the_single_featured_responsive_image( $class, $media_args );
				} else {
					alpaca_the_single_featured_background_image( $class, $media_args, $template );
				}
				break;
		}
	}
endif;

if ( ! function_exists( 'alpaca_the_single_featured_section' ) ) :
	/**
	* Output single post/page featured media section
	*/
	function alpaca_the_single_featured_section( $template = '' ) {
		if ( apply_filters( 'loftocean_front_has_post_featured_media', false ) && is_singular( 'post' ) ) {
			alpaca_the_single_featured_media( $template );
	    } else if ( has_post_thumbnail() ) {
	        ( 'normal' == $template ) ? alpaca_the_single_featured_responsive_image() : alpaca_the_single_featured_background_image( '', array(), $template );
	    }
	}
endif;

if ( ! function_exists( 'alpaca_the_meta_category' ) ) :
	/**
	 * Prints HTML with category for current post
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_the_meta_category() {
		$categories = get_the_term_list( get_the_ID(), 'category', '', '', '' );
		$category_list_allowed_html = array( 'a' => array( 'href' => 1, 'id' => 1, 'class' => 1, 'data-*' => 1, 'target' => 1, 'rel' => 1 ) );
		if ( ! empty( $categories ) ) : ?>
			<div class="cat-links"><?php echo wp_kses( $categories, $category_list_allowed_html ); ?></div><?php
		endif;
	}
endif;

if ( ! function_exists( 'alpaca_meta_author' ) ) :
	/**
	 * Prints post meta author for current post
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_meta_author() {
		$authors = alpaca_get_post_authors();
		$author_metas = alpage_get_author_metas(); ?>

		<div class="meta-group author">
            <?php if ( $author_metas['avatar'] ) : ?>
            <div class="author-photo">
                <a href="<?php echo esc_url( $author_metas['url'] ); ?>"><?php echo get_avatar( $author_metas['email'], 160 ); ?></a>
            </div>
            <?php endif; ?>
			<div class="meta-item author-name"><?php
				$author_count = count( $authors ) - 1;
				foreach( $authors as $index => $author ) :
					$author_url = get_author_posts_url( $author->ID );
					$author_name = $author->display_name; ?>
					<a href="<?php echo esc_url( $author_url ); ?>"><?php echo esc_html( $author_name ); ?></a><?php if ( $index < $author_count ) : ?>,<?php endif;
				endforeach; ?>
			</div>
        </div><?php
	}
endif;

if ( ! function_exists( 'alpaca_the_meta_date' ) ) :
	/**
	 * Prints post meta date information for current post.
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_the_meta_date() {
		if ( is_singular() && is_main_query() ) : ?>
			<div class="meta-item post-date"><?php echo esc_html( get_the_date() ); ?></div><?php
		else : ?>
			<div class="meta-item post-date"><a href="<?php the_permalink() ?>"><?php echo esc_html( get_the_date() ); ?></a></div><?php
		endif;
	}
endif;

if ( ! function_exists( 'alpaca_the_meta_update_date' ) ) :
	/**
	 * Prints post meta update date information for current post.
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_the_meta_update_date( $show_publish_date = false ) {
		$pid = get_the_ID();
		$show_update_date = $show_publish_date ? ( strtotime( get_post_field( 'post_modified_gmt', $pid ) ) - strtotime( get_post_field( 'post_date_gmt', $pid ) ) > 60 ) : true;
		if ( $show_update_date ) :
			if ( is_singular() && is_main_query() ) : ?>
				<div class="meta-item update-date"><?php the_modified_date( '', __( 'Updated on ', 'alpaca' ) ); ?></div><?php
			else : ?>
				<div class="meta-item update-date"><a href="<?php the_permalink() ?>"><?php the_modified_date( '', __( 'Updated on ', 'alpaca' ) ); ?></a></div><?php
			endif;
		endif;
	}
endif;

if ( ! function_exists( 'alpaca_the_meta_reading_time' ) ) :
	/**
	 * Prints post meta readubg time for current post.
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_the_meta_reading_time() { ?>
		<div class="meta-item read-time"><?php alpaca_the_post_reading_time( get_the_ID() ); ?></div><?php
	}
endif;

if ( ! function_exists( 'alpaca_meta_view' ) ) :
	/**
	 * Prints post meta date information for current post.
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_meta_view() {
		if ( function_exists( 'alpaca_extension' ) ) :
			$views = apply_filters( 'loftocean_get_post_metas_view_count', 0 ); ?>
			<div class="meta-item view-count loftocean-view-meta" data-post-id="<?php echo esc_attr( get_the_ID() ); ?>"><i class="fas fa-eye"></i> <span class="count"><?php echo esc_html( $views ); ?></span></div><?php
		endif;
	}
endif;

if ( ! function_exists( 'alpaca_meta_like' ) ) :
	/**
	 * Prints post meta date information for current post.
	 * Create your own function to override in a child theme.
	 * @since 1.0.0
	 */
	function alpaca_meta_like() {
		if ( function_exists( 'alpaca_extension' ) ) :
			$likes = apply_filters( 'loftocean_get_post_metas_like_count', 0 ); ?>
			<div class="meta-item like-count" data-post-id="<?php the_ID(); ?>"><i class="fas fa-heart"></i> <span class="count"><?php echo esc_html( $likes ); ?></span></div><?php
		endif;
	}
endif;

if ( ! function_exists( 'alpaca_meta_comment' ) ) :
	/**
	 * Prints post meta comment link.
	 *
	 * Create your own function to override in a child theme.
	 *
	 * @since 1.0.0
	 */
	function alpaca_meta_comment() {
		$num = get_comments_number();
		if ( comments_open() || $num ) {
			$url = sprintf( '%s#comments', get_permalink( get_the_ID() ) );
			$label = ( $num > 1 ) ? esc_html__( 'Comments', 'alpaca' ) : esc_html__( 'Comment', 'alpaca' );
			if ( is_singular() && is_main_query() ) : ?>
				<div class="meta-item comment-count">
					<a href="#comments"><?php echo esc_html( $num ); ?> <?php echo esc_html( $label ); ?></a>
				</div><?php
			else : ?>
				<div class="meta-item comment-count">
					<a href="<?php echo esc_url( $url ); ?>"><i class="fas fa-comments"></i> <?php echo esc_html( $num ); ?></a>
				</div><?php
			endif;
		}
	}
endif;

if ( ! function_exists( 'alpaca_the_single_pagination' ) ) :
	/**
	 * Print content pagination for singles
	 *
	 * Create your own function to override in a child theme.
	 *
	 * @since 1.0.0
	*/
	function alpaca_the_single_pagination() {
		wp_link_pages( array(
			'before'      => '<div class="page-links"><div class="page-links-container"><span class="page-links-title">' . esc_html__( 'Pages:', 'alpaca' ) . '</span>',
			'after'       => '</div></div>',
			'link_before' => '<span>',
			'link_after'  => '</span>'
		) );
	}
endif;

if ( ! function_exists( 'alpaca_meta_edit_link' ) ) :
	/**
	 * Print link to edit a post or page.
	 *
	 * Create your own function to override in a child theme.
	 *
	 * @since 1.0.0
	*/
	function alpaca_meta_edit_link() {
		edit_post_link(
			esc_html__( 'Edit', 'alpaca' ),
			'<div class="meta-item edit-link">',
			'</div>'
		);
	}
endif;

if ( ! function_exists( 'alpaca_the_social_bar' ) ) :
	/**
	* Print social share icon html
	* Create your own function to override in a child theme
	*/
	function alpaca_the_social_bar( $has_wrap = false, $enabled = false, $flag = array( 'sticky' => false, 'product' => false ) ) {
		$socials = alpaca_get_enabled_sharing();
		if ( alpaca_is_valid_array( $socials ) && alpaca_is_extension_activated() && $enabled ) {
			if ( ! empty( $flag['product'] ) ) {
				$socials = array_diff( $socials, array( 'like' ) );
			}
			if ( apply_filters( 'loftocean_has_social_sharing_icons', false, $socials ) ) :
				$sticky = ! empty( $flag['sticky'] );
				if ( $has_wrap && $sticky ) : ?><div class="sticky-share hide-it"><?php endif; ?>
				<div class="article-share"><?php do_action( 'loftocean_the_social_sharing_icons', $socials ); ?></div><?php
				if ( $has_wrap && $sticky ) : ?></div><?php endif;
			endif;
		}
	}
endif;

if ( ! function_exists( 'alpaca_show_yoast_seo_breadcrumbs' ) ) :
	/**
	* Print breadcrumbs
	* Create your own function to override in a child theme
	*/
	function alpaca_show_yoast_seo_breadcrumbs( $page = 'post' ) {
		if ( function_exists( 'yoast_breadcrumb' ) ) {
			$mod = in_array( $page, array( 'page', 'post', 'archive', 'search' ) ) ? 'alpaca_show_yoast_seo_breadcrumbs_on_' . $page : false;
			if ( $mod && alpaca_module_enabled( $mod ) ) {
			  yoast_breadcrumb( '<div id="breadcrumbs" class="breadcrumbs">','</div>' );
			}
		}
	}
endif;
