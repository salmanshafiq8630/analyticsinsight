<?php
if ( class_exists( 'Walker_Nav_Menu' ) ) {
	// For main menu to generate mage menu related elements
	class Alpaca_Mega_Walker_Nav_Menu extends Walker_Nav_Menu {
		/**
		* Rewrite built-in display function
		*/
		public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
			if ( ! $element ) {
				return;
			}

			$id_field = $this->db_fields['id'];
			$id = $element->$id_field;

			//display this element
			$this->has_children = ! empty( $children_elements[ $id ] );
			if ( isset( $args[0] ) && is_array( $args[0] ) ) {
				$args[0]['has_children'] = $this->has_children; // Back-compat.
			}

			$cb_args = array_merge( array( &$output, $element, $depth ), $args );
			call_user_func_array( array( $this, 'start_el' ), $cb_args );

			// descend only when the depth is right and there are childrens for this element
			if ( ( ( $max_depth == 0 ) || ( $max_depth > ( $depth + 1 ) ) ) && isset( $children_elements[ $id ] ) ) {
				$is_mega_list = $this->is_mega_list( $element, $depth );
				if ( $is_mega_list || ! $this->is_mega_category( $element, $depth ) ) {
					$children_length = count( $children_elements[ $id ] );
					foreach ( $children_elements[ $id ] as $child ) {
						if ( ! isset( $newlevel ) ) {
							$newlevel = true;
							//start the child delimiter
							$cb_args = array_merge( array( &$output, $depth ), $args );
							call_user_func_array( array( $this, 'start_lvl'), $cb_args );
						}
						if ( $is_mega_list ) {
							if ( $child->object == 'category' ) {
								$this->display_mega_list( $child, $output, $depth + 1, $args, $children_length );
							}
						} else {
							$this->display_element( $child, $children_elements, $max_depth, ( $depth + 1 ), $args, $output );
						}
					}
				}
				unset( $children_elements[ $id ] );
			}
			if ( isset( $newlevel ) && $newlevel ) {
				//end the child delimiter
				$cb_args = array_merge( array( &$output, $depth ), $args );
				call_user_func_array( array( $this, 'end_lvl' ), $cb_args );
			}

			//end this element
			$cb_args = array_merge( array( &$output, $element, $depth ), $args );
			call_user_func_array( array( $this, 'end_el' ), $cb_args );
		}
		/**
		* Rewrite built-in start elment output function
		*/
		public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
			$classes = empty( $item->classes ) ? array() : (array)$item->classes;
			// $depth starts from 0, so 2 means third level
			if ( $depth > 1 ) {
				if ( in_array( 'menu-item-has-children', $classes ) ) {
					$item->classes = array_diff( $classes, array( 'menu-item-has-children' ) );
				}
			}
			// Support mega menu for first level only
			if ( $depth > 0 ) {
				if ( in_array( 'mega-menu', $classes ) ) {
					$item->classes = array_diff( $classes, array( 'mega-menu' ) );
				}
				if ( in_array( 'cat-list', $classes ) ) {
					$item->classes = array_diff( $classes, array( 'cat-list' ) );
				}
			}
			// If is category and has its child category, add class menu-item-has-children
			if ( ! $this->is_mega_list( $item, $depth ) && $this->is_mega_category( $item, $depth ) ) {
				$term_id = $item->object_id;
				$terms = get_terms( array( 'taxonomy' => 'category', 'parent' => $term_id ) );
				if ( ! is_wp_error( $terms ) && ( count( $terms ) > 0 ) ) {
					$item->classes = array_merge( $classes, array( 'menu-item-has-children' ) );
				};
			}
			parent::start_el( $output, $item, $depth, $args, $id );
		}
		/**
		* Rewrite built-in end element output function
		*/
		public function end_el( &$output, $item, $depth = 0, $args = array() ) {
			if ( ! $this->is_mega_list( $item, $depth ) && $this->is_mega_category( $item, $depth ) ) {
				$term_id = $item->object_id;
				$terms = get_terms( 'category', array( 'parent' => $term_id ) );
				$ppp = ( ! is_wp_error( $terms ) && ( count( $terms ) > 0 ) ) ? 3 : 4;
				$query = new WP_Query( array( 'posts_per_page' => $ppp, 'cat' => $term_id, 'offset' => 0 ) );
				if ( $query->have_posts() ) {
					$output .= '<ul class="sub-menu hide">';
					if ( ! is_wp_error( $terms ) && ( count( $terms ) > 0 ) ) {
						$tmpl = '<li class="sub-cat-list"><ul>%s</ul></li><li class="sub-cat-posts">%s</li>';
						$cat_list = sprintf(
							'<li class="current" data-id="cat-%s"><a href="%s">%s</a></li>',
							$term_id,
							get_term_link( intval( $term_id ), 'category' ),
							esc_html__( 'All', 'alpaca' )
						);
						$post_list = $this->post_list( $query, '<div class="sub-cat current cat-' . $term_id . '"><ul>', '</ul></div>' );
						foreach ( $terms as $t ) {
							$term_id = $t->term_id;
							$query = new WP_Query( array( 'posts_per_page' => $ppp, 'cat' => $term_id, 'offset' => 0 ) );
							if ( $query->have_posts() ) {
								$term_id = $t->term_id;
								$cat_list .= sprintf(
									'<li data-id="cat-%s"><a href="%s">%s</a></li>',
									$term_id,
									get_term_link( $t, 'category' ),
									$t->name
								);
								$post_list .= $this->post_list( $query, '<div class="sub-cat cat-' . $term_id . '"><ul>', '</ul></div>' );
							}
						}
						$output .= sprintf( $tmpl, $cat_list, $post_list );
					} else {
						$output .= $this->post_list( $query );
					}
					$output .= '</ul>';
				}
			}
			parent::end_el( $output, $item, $depth, $args );
		}
		/**
		* Rewrite built-in function
		*/
		public function start_lvl( &$output, $depth = 0, $args = array() ) {
			if ( isset( $args->item_spacing ) && 'discard' === $args->item_spacing ) {
				$t = '';
				$n = '';
			} else {
				$t = "\t";
				$n = "\n";
			}
			$indent = str_repeat( $t, $depth );
			$output .= "{$n}{$indent}<ul class=\"sub-menu hide\">{$n}";
		}
		/**
		* Helper function to check if current is category item with mega set
		*/
		private function is_mega_category( $item, $depth ) {
			return in_array( 'mega-menu', (array) $item->classes ) && ( $depth == 0 ) && ( $item->object == 'category' );
		}
		/**
		* Helper function to list sub menu item as category list
		* @param object menu item
		* @param int menu depth
		* @return boolean
		*/
		private function is_mega_list( $item, $depth ) {
			$classes = (array)$item->classes;
			return in_array( 'mega-menu', $classes ) && in_array( 'cat-list', $classes ) && ( $depth == 0 );
		}
		/**
		* Show mega cat list item
		*/
		private function display_mega_list( $item, &$output, $depth, $args, $children_length ) {
			$bg_image = apply_filters(
				'loftocean_front_get_taxonomy_featured_image',
				'',
				get_category( $item->object_id ),
				Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'menu', 'sub_module' => 'mega-menu-' . $children_length  ) ),
				array( 'class' => 'cat-bg' )
			);
			$extra_args = $this->get_mega_list_args( $bg_image );
			$extra_args = ( object )array_merge( ( array )$args, $extra_args );
			parent::start_el( $output, $item, $depth, $extra_args );
			parent::end_el( $output, $item, $depth, $args );
		}
		public function get_mega_list_args( $bg_image ) {
			$link_before = $bg_image;
			$link_before .= ' <div class="cat-meta"><span class="category-name">';
			return array(
				'before' => '<div class="cat">',
				'after' => '</div>',
				'link_before' => $link_before,
				'link_after' => '</span></div>'
			);
		}
		/**
		* Helper function to get the post list html
		*/
		private function post_list( $query, $before = '', $after = '' ) {
			$image_sizes = Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'menu', 'sub_module' => 'mega-menu' ) );
			$allowed_html = array( 'div' => array( 'class' => 1, 'id' => 1 ), 'ul' => array( 'class' => 1, 'id' => 1 ) );
			ob_start();
			echo wp_kses( $before, $allowed_html );
			while ( $query->have_posts() ) :
				$query->the_post();
				$has_thumbnail = has_post_thumbnail();
				$link = get_permalink(); ?>
				<li>
					<div class="post mega-menu-post<?php if ( $has_thumbnail ) : ?> has-post-thumbnail<?php endif; ?>">
						<?php if ( $has_thumbnail ) : ?>
						<figure class="featured-img">
							<?php alpaca_the_preload_bg( array( 'tag' => 'a', 'sizes' => $image_sizes, 'attrs' => array( 'href' => $link ) ) ); ?>
						</figure>
						<?php endif; ?>
						<p class="entry-title"><a href="<?php echo esc_url( $link ); ?>"><?php the_title(); ?></a></p>
					</div>
				</li> <?php
			endwhile;
			wp_reset_postdata();
			echo wp_kses( $after, $allowed_html );
			return ob_get_clean();
		}
	}

	// Waler class for fullscreen site header
	class Alpaca_Walker_Nav_Menu extends Walker_Nav_Menu {
		/*
		 * @description add a wrapper div
		 * @param string $output Passed by reference. Used to append additional content.
		 * @param int    $depth  Depth of menu item. Used for padding.
		 * @param array  $args   An array of wp_nav_menu() arguments.
		 */
		public function start_lvl( &$output, $depth = 0, $args = array() ) {
			$indent = str_repeat( "\t", $depth );
			$wrap = in_array( $args->theme_location, array( 'primary-menu' ) ) ? sprintf(
				'<button class="dropdown-toggle" aria-expanded="false"><span class="screen-reader-text">%s</span></button>',
				esc_html__( 'expand child menu', 'alpaca' )
			) : '';
			$output .=  "\n$indent$wrap<ul class=\"sub-menu\">\n";
		}
	}
}
