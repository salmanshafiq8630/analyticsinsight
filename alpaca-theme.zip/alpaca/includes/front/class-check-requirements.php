<?php
/**
* Check front requirement for some unusual situation
*/

if ( ! class_exists( 'Alpaca_Front_Check_Requirements' ) ) {
	class Alpaca_Front_Check_Requirements {
		/**
		* Object current class instance to make sure only once instance in running
		*/
		public static $instance = false;
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'alpaca_check_front_requirement', array( $this, 'load_front_files' ) );
			add_action( 'alpaca_check_front_requirement', array( $this, 'load_hooks' ) );
		}
		/**
		* Import required files
		*/
		public function load_front_files() {
            if ( ! class_exists( 'Alpaca_Front_Manager' ) ) {
    			require_once ALPACA_THEME_INC . 'utils/class-utils-sanitize.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    			require_once ALPACA_THEME_INC . 'front/class-mode-switcher.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    			require_once ALPACA_THEME_INC . 'front/class-front-advertisement.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound


                require_once ALPACA_THEME_INC . 'default-option-values.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                require_once ALPACA_THEME_INC . 'front/functions.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                require_once ALPACA_THEME_INC . 'front/functions-template.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                require_once ALPACA_THEME_INC . 'front/class-walker-menu.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
                require_once ALPACA_THEME_INC . 'assets/class-front-assets-controller.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
            }
		}
		/**
		* Hooks needed
		*/
		public function load_hooks() {
            if ( ! class_exists( 'Alpaca_Front_Manager' ) ) {
				add_filter( 'body_class', array( $this, 'body_class' ), 999 );
				add_filter( 'alpaca_page_layout', array( $this, 'get_page_layout'), 9999 );
				add_filter( 'alpaca_content_class', array( $this, 'content_class' ), 9999 );
				add_action( 'alpaca_the_site_footer', array( $this, 'the_site_footer' ) );
				// Woocommerce related
				if ( alpaca_is_woocommerce_activated() ) {
					add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_script' ), 5 );
					add_filter( 'alpaca_front_inline_styles_handler', array( $this, 'inline_style_handler' ) );
					add_filter( 'alpaca_front_get_main_theme_style_dependency', array( $this, 'theme_css_deps' ) );
				}
			}
		}
		/**
		* Add extra class name to <body>
		* @param array class name list
		* @return array class name list
		*/
		public function body_class( $class ) {
			$site_header_style = alpaca_get_theme_mod( 'alpaca_site_header_layout' );
			array_push( $class, esc_attr( alpaca_get_theme_mod( 'alpaca_site_color_scheme' ) ) );
			switch ( $site_header_style ) {
				case 'horizontal-1':
				case 'horizontal-2':
				case 'horizontal-3':
				case 'horizontal-4':
					$class = array_merge( $class, array( 'site-header-horizontal', 'site-header-' . $site_header_style ) );
					break;
				case 'vertical-wide':
					array_push( $class, 'site-header-vertical' );
					array_push( $class, 'site-header-v-wide' );
					break;
				default:
					array_push( $class, 'site-header-vertical' );
					array_push( $class, 'site-header-v-bar' );
			}
			return $class;
		}
		/**
		* Show site footer
		*/
		public function the_site_footer() {
			$show_instagram = $this->show_instagram();
			$show_bottom = $this->show_footer_bottom();
			$show_back_to_top = alpaca_module_enabled( 'alpaca_show_back_to_top_button' );
			$show_signup_form = alpaca_is_mc4wp_activated() && alpaca_module_enabled( 'alpaca_site_footer_show_signup_form' );
			if ( $show_signup_form || $show_instagram || $show_bottom || $show_back_to_top ) : ?>
				<footer id="colophon" class="site-footer">
					<?php $show_signup_form ? get_template_part( 'template-parts/site-footer/footer-signup' ) : ''; ?>
					<?php $show_instagram ? get_template_part( 'template-parts/site-footer/instagram' ) : ''; ?>
					<?php $show_bottom ? get_template_part( 'template-parts/site-footer/bottom' ) : ''; ?>
				</footer><?php
				$show_back_to_top ? get_template_part( 'template-parts/site-footer/back-to-top' ) : '';
			endif;
		}
		/**
		* Check page layout for 404 page
		*/
		public function get_page_layout( $layout ) {
			return '';
		}
		/**
		* Check content class for 404 page
		*/
		public function content_class( $class ) {
			return array_diff( $class, array( 'with-sidebar-right', 'with-sidebar-left' ) );
		}
		/**
		* Condition function if show instagram feeds
		*/
		protected function show_instagram() {
			if ( alpaca_is_extension_activated() && alpaca_module_enabled( 'alpaca_site_footer_enable_instagram' ) ) {
				$instagram_account = esc_attr( alpaca_get_theme_mod( 'alpaca_site_footer_instagram_username' ) );
				return apply_filters( 'loftocean_instagram_has_feed', false, $account );
			}
			return false;
		}
		/**
		* Condition function if show site footer bottom
		*/
		protected function show_footer_bottom() {
			$bottom_copyright_text = alpaca_get_theme_mod( 'alpaca_site_footer_bottom_copyright_text' );
			if ( ! empty( $bottom_copyright_text ) ) {
				return true;
			} else {
				$show_light_logo = alpaca_is_item_exists( alpaca_get_theme_mod( 'alpaca_site_footer_bottom_light_color_scheme_logo' ) );
				$show_dark_logo = alpaca_is_item_exists( alpaca_get_theme_mod( 'alpaca_site_footer_bottom_dark_color_scheme_logo' ) );
				return $show_light_logo || $show_dark_logo || alpaca_has_nav_menu( 'social-menu' );
			}
		}
		/**
		* Enqueue woocommerce related style file
		*/
		public function enqueue_script() {
			$suffix = alpaca_get_assets_suffix();
			wp_enqueue_style( 'alpaca-woocommerce', ALPACA_ASSETS_URI . 'styles/front/shop' . $suffix . '.css', array( 'alpaca-theme-style' ), ALPACA_ASSETS_VERSION );
		}
		/**
		* Add woocommerce style to theme main css dependency list
		*/
		public function theme_css_deps( $deps ) {
			$deps = array_merge( $deps, array( 'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen' ) );
			return $deps;
		}
		/**
		* Theme inline style handler
		*/
		public function inline_style_handler( $handler ) {
			return 'alpaca-woocommerce';
		}
		/**
		* Instance Loader class
		*	there can only be one instance of loader
		* @return class Loader
		*/
		public static function init() {
			if ( false === self::$instance ) {
				self::$instance = new self();
			}
		}
	}
    Alpaca_Front_Check_Requirements::init();
}
