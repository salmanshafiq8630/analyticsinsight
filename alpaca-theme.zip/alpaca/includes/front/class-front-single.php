<?php
if ( ! class_exists( 'Alpaca_Front_Single' ) ) {
	class Alpaca_Front_Single {
		/**
		* String template
		*/
		protected $template = false;
		/**
		* String layout
		*/
		protected $layout = false;
		/**
		* Array settings for page
		*/
		protected $page_settings = array();
		/**
		* Boolean single post checked
		*/
		public $is_single_checked = false;
		/**
		* Construct function
		*/
		public function __construct() {
			add_action( 'template_redirect', array( $this, 'init_hooks' ), 999 );
		}
		/**
		* Init hooks
		*/
		public function init_hooks() {
			if ( is_singular() ) {
				$this->get_current_settings();
				add_filter( 'body_class', array( $this, 'body_class' ) );
				add_filter( 'post_class', array( $this, 'post_class' ) );
				add_filter( 'navigation_markup_template', array( $this, 'navigation_markup_template' ), 99, 2 );
				add_filter( 'alpaca_post_template', array( $this, 'get_post_template' ) );
				add_filter( 'alpaca_content_class', array( $this, 'content_class' ) );
				add_filter( 'prepend_attachment', array( $this, 'attachment_page_content' ), 99 );
				add_filter( 'alpaca_page_template', array( $this, 'get_page_template' ), 99 );
				add_filter( 'alpaca_page_layout', array( $this, 'get_page_layout'), 99 );
				add_filter( 'alpaca_front_get_related_posts', array( $this, 'related_posts' ), 10, 3 );
				add_filter( 'alpaca_singular_page_settings', array( $this, 'get_page_settings' ), 10, 2 );
			}
		}
		/**
		* Get current single post template
		*/
		public function get_post_template() {
			if ( $this->template ) {
				switch ( $this->template ) {
					case 'post-template-wide-header-img':
						return 'wide';
					case 'post-template-wide-overlay-header':
						return 'overlay';
					case 'post-template-normal':
						return 'normal';
					default:
						return 'split';
				}
			}
			return '';
		}
		/**
		* Modify body class for singular pages
		* @param array
		* @return array
		*/
		public function body_class( $class ) {
			$template = $this->template;
			empty( $template ) ? '' : array_push( $class, $template );
			if ( ! empty( $this->page_settings['body_class'] ) ) {
				array_push( $class, $this->page_settings['body_class'] );
				if ( false !== strpos( $this->page_settings['body_class'], 'page-template-fullwidth' ) ) {
					$class = array_diff( $class, array( 'page-template-default' ) );
				}
			}
			if ( is_singular( array( 'post' ) ) ) {
				alpaca_module_enabled( 'alpaca_single_post_show_sticky_social_bar' ) && alpaca_is_extension_activated() ? array_push( $class, 'has-sticky-share' ) : '';
				( 'post-template-split' == $this->template ) && alpaca_module_enabled( 'alpaca_single_post_mobile_enable_large_post_header' ) ? array_push( $class, 'mobile-large-header' ) : '';
			}

			return $class;
		}
		/**
		* For single post page
		*/
		public function post_class( $class ) {
			if ( $this->is_single_checked ) return $class;
			$this->is_single_checked = true;
			if ( is_singular( 'post' ) ) {
				array_push( $class, 'single-post-wrapper' );
				if ( ( 'post-template-split' == $this->template ) && alpaca_module_enabled( 'alpaca_single_post_show_sticky_social_bar' ) ) {
					array_push( $class, 'has-sticky-share' );
				}
				if ( ( 'gallery' == get_post_format() ) && apply_filters( 'loftocean_front_has_post_featured_media', false ) ) {
					array_push( $class, 'has-post-thumbnail' );
				}
			} else if ( ! empty( $this->page_settings['post_class'] ) ) {
				array_push( $class, $this->page_settings['post_class'] );
			} else if ( is_singular( 'attachment' ) ) {
				array_push( $class, 'single-post-wrapper' );
			}
			return $class;
		}
		/**
		* Get main content layout class
		*/
		public function content_class( $class ) {
			$layout = $this->layout;
			$sidebar_id = apply_filters( 'alpaca_sidebar_id', 'primary-sidebar' );
			if ( ! empty( $layout ) && is_active_sidebar( $sidebar_id ) ) {
				array_push( $class, $layout );
			}
			return $class;
		}
		/**
		* Change the attachment page image size to 'large'
		* @param string $attachment_content the attachment html
		* @return string $attachment_content the attachment html
		*/
		public function attachment_page_content( $content ) {
			if ( is_attachment() ) {
				$attachment_id = get_queried_object_id();
				$attachment = wp_get_attachment_image( $attachment_id );
				if ( ! empty( $attachment ) ) {
					$caption = wp_get_attachment_caption( $attachment_id );
					$content = sprintf(
						'<figure class="entry-attachment wp-block-image">%1$s%2$s</figure>',
						wp_get_attachment_link( $attachment_id, 'alpaca_1200w', false ),
						empty( $caption ) ? '' : sprintf( '<figcaption class="wp-caption-text">%s</figcaption>', $caption )
					);
				}
			}
			return $content;
		}
		/**
		* Get page layout
		*/
		public function get_page_template( $template ) {
			return ( false === $this->template ) ? $template : $this->template;
		}
		/**
		* Get page sidebar settings
		*/
		public function get_page_layout( $layout ) {
			return ( false === $this->layout ) ? $layout : $this->layout;
		}
		/**
		* Get related posts
		* @param object WP_Query results
		* @param string filter, category or tag ...
		* @param number posts number needed, default to 3
		* @return object WP_Qurey results
		*/
		public function related_posts( $related, $filter, $ppp = 4 ) {
			$filters = array( 'category', 'tag', 'author' );
			if ( ! empty( $filter ) && in_array( $filter, $filters ) && ( intval( $ppp ) > 0 ) ) {
				$args = array(
					'posts_per_page'=> intval( $ppp ),
					'post__not_in'	=> array( get_the_ID() ),
					'orderby' 		=> 'rand'
				);
				$cats = wp_get_post_categories( get_the_ID(), array( 'fields' => 'ids' ) );
				$tags = wp_get_post_tags( get_the_ID(), array( 'fields' => 'ids' ) );
				$author_id = get_the_author_meta( 'ID' );
				$run_query = false;
				switch ( $filter ) {
					case 'category':
						if ( ! empty($cats ) ) {
							$run_query = true;
							$args['category__in'] = $cats;
						}
						break;
					case 'tag':
						if ( ! empty( $tags ) ) {
							$run_query = true;
							$args['tag__in'] = $tags;
						}
						break;
					default:
						if ( ! empty( $author_id ) ) {
							$run_query = true;
							$args['author'] = $author_id;
						}
				}
				$related = $run_query ? new WP_Query( $args ) : $related;
			}
			return $related;
		}
		/**
		* Get current post template and layout
		*/
		protected function get_current_settings() {
			if ( is_singular( 'post' ) ) {
				$sets = get_post_meta( get_the_ID(), 'alpaca_single_post_template_layout', true );
				if ( '' === $sets ) {
					$this->template = alpaca_get_theme_mod( 'alpaca_single_post_default_template' );
					$this->layout = ( 'post-template-split' == $this->template ) ? '' : alpaca_get_theme_mod( 'alpaca_single_post_default_page_layout' );
				} else {
					$sets = explode( '_', $sets );
					$this->template = $sets[0];
					$this->layout = isset( $sets[1] ) ? $sets[1] : '';
				}
			} else if ( is_singular( 'page' ) ) {
				$pid = alpaca_get_queried_singular_id();
				if ( ! apply_filters( 'loftocean_hide_page_settings', false, get_page( $pid ) ) ) {
					$class = array();

					$layout = get_post_meta( $pid, 'alpaca_page_layout', true );
					if ( 'fullwidth' == $layout ) {
						$this->layout = '';
						array_push( $class, 'page-template-fullwidth' );
					} else {
						$this->layout = $layout;
					}

					$extra_class = get_post_meta( $pid, 'alpaca_advanced_classname', true );
					if ( 'on' == get_post_meta( $pid, 'alpaca_hide_page_header', true ) ) {
						array_push( $class, 'page-header-hidden' );
					}
					if ( ! empty( $extra_class ) ) {
						array_push( $class, $extra_class );
					}
					$this->page_settings['body_class'] = implode( ' ', $class );

					$this->page_settings['post_class'] = 'single-post-wrapper';

					$this->page_settings['sub_title'] = get_post_meta( $pid, 'alpaca_page_sub_title', true );
				}
			}
		}
		/**
		*
		*/
		public function navigation_markup_template( $tmpl, $class ) {
			return 'post-navigation' == $class ? str_replace( '%1$s', 'alignfull %1$s', $tmpl ) : $tmpl;
		}
		/**
		* Get page settings
		*/
		public function get_page_settings( $value, $id ) {
			return isset( $this->page_settings[ $id ] ) ? $this->page_settings[ $id ] : $value;
		}
	}
	new Alpaca_Front_Single();
}
