<?php
/**
* Color scheme switcher class
*/

if ( ! class_exists( 'Alpaca_Color_Scheme_Switcher' ) ) {
    class Alpaca_Color_Scheme_Switcher {
        /**
        * Construct function
        */
        public function __construct() {
            if ( alpaca_module_enabled( 'alpaca_site_header_show_color_scheme_switcher' ) ) {
                add_filter( 'alpaca_get_html_class', array( $this, 'get_html_class' ) );
                alpaca_is_customize_preview() ? '' : add_action( 'wp_print_scripts', array( $this, 'inject_inline_script_in_head' ) );
            }
        }
        /**
        * HTML classes
        */
        public function get_html_class( $class ) {
            array_push( $class, 'original-' . alpaca_get_theme_mod( 'alpaca_site_color_scheme' ) );
            return $class;
        }
		/**
		* Inject inline JavaScript in head
		*/
		public function inject_inline_script_in_head() {
            require_once ALPACA_THEME_DIR . 'assets/scripts/front/early-color-scheme-switcher.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
		}
    }
	new Alpaca_Color_Scheme_Switcher();
}
