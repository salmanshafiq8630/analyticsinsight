<?php
/**
* Theme option default values
*/

global $alpaca_default_settings;

$alpaca_default_settings = apply_filters( 'alpaca_default_option_values', array(
	/** section general posts **/
	'alpaca_reading_speed_per_minute'									=> '300',
	'alpaca_reading_speed_unit'											=> 'words',
	'alpaca_read_more_button_text' 										=> esc_html__( 'Read More', 'alpaca' ),
	'alpaca_list_pagination_style'										=> 'ajax-manual',
	'alpaca_post_thumbnail_shape'										=> '',

	'alpaca_post_excerpt_length_for_layout_standard' 					=> '50',
	'alpaca_post_excerpt_length_for_layout_zigzag'						=> '25',
	'alpaca_post_excerpt_length_for_layout_list'						=> '25',
	'alpaca_post_excerpt_length_for_layout_grid'	 					=> '25',
	'alpaca_post_excerpt_length_for_layout_masonry' 					=> '25',
	'alpaca_post_excerpt_length_for_layout_carousel' 					=> '25',
	'alpaca_post_excerpt_length_for_layout_overlay'						=> '25',
	'alpaca_post_excerpt_length_for_layout_widget_slider'				=> '25',

	'alpaca_load_post_metas_dynamically'								=> '',

	/** section general colors **/
	'alpaca_site_color_scheme'											=> 'light-color',
	'alpaca_custom_accent_color'										=> '#7BBB1B',

	'alpaca_light_scheme_custom_bg_color'								=> '#FFFFFF',
	'alpaca_light_scheme_custom_text_color'								=> '#000000',
	'alpaca_light_scheme_custom_content_color'							=> '#191919',

	'alpaca_dark_scheme_custom_bg_color'								=> '#111111',
	'alpaca_dark_scheme_custom_text_color'								=> '#FFFFFF',
	'alpaca_dark_scheme_custom_content_color'							=> '#E6E6E6',

	/** section social */
	'alpaca_general_social_like'										=> 'on',
	'alpaca_general_social_facebook'									=> 'on',
	'alpaca_general_social_twitter'										=> 'on',
	'alpaca_general_social_pinterest'									=> '',
	'alpaca_general_social_linkedin'									=> '',
	'alpaca_general_social_whatsapp'									=> '',
	'alpaca_general_social_reddit'										=> '',
	'alpaca_general_social_email'										=> 'on',

	/** section back to top **/
	'alpaca_show_back_to_top_button'									=> 'on',

	/** section image loading **/
	'alpaca_general_enable_progressive_image_loading'					=> 'on',
	'alpaca_general_enable_lazy_load'									=> '',
	'alpaca_general_enable_full_image_size'								=> '',

	/** section breadcrumbs **/
	'alpaca_show_yoast_seo_breadcrumbs_on_post'							=> '',
	'alpaca_show_yoast_seo_breadcrumbs_on_page'							=> '',
	'alpaca_show_yoast_seo_breadcrumbs_on_archive'						=> '',
	'alpaca_show_yoast_seo_breadcrumbs_on_search'						=> '',

	/** section image enter animation **/
	'alpaca_general_enable_posts_entrance_animation'					=> 'on',
	'alpaca_general_enable_header_entrance_animation'					=> 'on',

	/** section site header layout **/
	'alpaca_site_header_layout'											=> 'horizontal-2',

	/** section site header logo **/
	'alpaca_site_header_logo_desktop_width'								=> '160',
	'alpaca_site_header_logo_mobile_width'								=> '100',
	'alpaca_site_header_light_desktop_logo'								=> '',
	'alpaca_site_header_light_mobile_logo'								=> '',
	'alpaca_site_header_dark_desktop_logo'								=> '',
	'alpaca_site_header_dark_mobile_logo'								=> '',
	'alpaca_site_header_show_search_form'								=> 'on',

	/** section site header social menu **/
	'alpaca_site_header_show_social_menu'								=> 'on',

	/** section site header color **/
	'alpaca_site_header_color_scheme'									=> 'light-color',
	'alpaca_site_header_light_color_background_color'					=> '',
	'alpaca_site_header_dark_color_background_color'					=> '',
	'alpaca_site_header_image'											=> '',

	/** section site header more **/
	'alpaca_site_header_show_search_button'								=> 'on',
	'alpaca_site_header_show_popup_signup_form_button'					=> 'on',
	'alpaca_site_header_show_color_scheme_switcher'						=> '',
	'alpaca_site_header_hide_more_label'								=> '',
	'alpaca_site_header_fold_more_buttons'								=> 'on',

	/** section site header fullscreen search **/
	'alpaca_site_header_fullscreen_search_style'						=> '',
	'alpaca_site_header_fullscreen_search_show_category'				=> 'on',
	'alpaca_site_header_fullscreen_search_show_tag'						=> '',
	'alpaca_site_header_fullscreen_search_show_author'					=> '',

	/** section fullscreen menu **/
	'alpaca_fullscreen_menu_color_scheme'								=> 'dark-color',
	'alpaca_fullscreen_menu_background_image'							=> '',
	'alpaca_fullscreen_menu_enable_overlay'								=> '',
	'alpaca_fullscreen_menu_background_color'							=> '',
	'alpaca_fullscreen_menu_text_color'									=> '',
	'alpaca_fullscreen_menu_show_search_form'							=> 'on',
	// translators: %s: date format, can be translated by user based their own location.
	'alpaca_fullscreen_menu_copyright_text'								=> sprintf( esc_html__( 'Your custom text &copy; Copyright 2021. All rights reserved.', 'alpaca' ), date( 'Y' ) ),
	'alpaca_fullscreen_menu_widgets_color_scheme'						=> 'light-color',
	'alpaca_fullscreen_menu_widgets_background_color'					=> '',
	'alpaca_fullscreen_menu_widgets_text_color'							=> '',

	/** section site footer signup form **/
	'alpaca_site_footer_show_signup_form'								=> '',
	'alpaca_site_footer_signup_form_id'									=> alpaca_get_default_mc4wp_form_id(),
	'alpaca_site_footer_signup_form_color_scheme'						=> 'light-color',
	'alpaca_site_footer_signup_form_light_color_background_color'		=> '',
	'alpaca_site_footer_signup_form_dark_color_background_color'		=> '',
	'alpaca_site_footer_signup_form_background_image'					=> '',
	'alpaca_site_footer_signup_form_enable_color_overlay'				=> '',

	/** section site footer instagram **/
	'alpaca_site_footer_enable_instagram'								=> '',
	'alpaca_site_footer_instagram_username'								=> '',
	'alpaca_site_footer_instagram_title'								=> '',
	'alpaca_site_footer_instagram_columns'								=> 6,
	'alpaca_site_footer_instagram_rows'									=> 1,
	'alpaca_site_footer_instagram_new_tab'								=> '',
	'alpaca_site_footer_instagram_color_scheme'							=> 'light-color',
	'alpaca_site_footer_instagram_light_color_background_color'			=> '',
	'alpaca_site_footer_instagram_dark_color_background_color'			=> '',

	/** section site footer bottom **/
	// translators: %s: date format, can be translated by user based their own location.
	'alpaca_site_footer_bottom_copyright_text'							=> sprintf( esc_html__( 'Footer text © Copyright 2021. All rights reserved.', 'alpaca' ), date( 'Y' ) ),
	'alpaca_site_footer_bottom_light_color_scheme_logo'					=> '',
	'alpaca_site_footer_bottom_dark_color_scheme_logo'					=> '',
	'alpaca_site_footer_bottom_logo_width'								=> '100',
	'alpaca_site_footer_bottom_color_scheme'							=> 'dark-color',
	'alpaca_site_footer_bottom_light_color_background_color'			=> '',
	'alpaca_site_footer_bottom_dark_color_background_color'				=> '',

	/** section site sidebar **/
	'alpaca_sidebar_enable_sticky'										=> 'on',

	/** section homepage main content area **/
	'alpaca_archive_page_home_section_title'							=> '',
	'alpaca_archive_page_home_section_sub_title'						=> '',
	'alpaca_archive_page_home_layout'									=> '',
	'alpaca_archive_page_home_post_layout'								=> 'layout-masonry_column-3_',
	'alpaca_archive_page_home_image_ratio'								=> 'img-ratio-3-2',
	'alpaca_archive_page_home_grid_style'								=> 'grid-style-1',
	'alpaca_archive_page_home_grid_overlay_opacity'						=> '',
	'alpaca_archive_page_home_grid_overlay_large_title'					=> '',
	'alpaca_archive_page_home_show_category'							=> 'on',
	'alpaca_archive_page_home_show_author'								=> 'on',
	'alpaca_archive_page_home_show_date'								=> 'on',
	'alpaca_archive_page_home_show_update_date'							=> '',
	'alpaca_archive_page_home_show_reading_time'						=> 'on',
	'alpaca_archive_page_home_show_excerpt'								=> 'on',
	'alpaca_archive_page_home_show_read_more_button'					=> 'on',
	'alpaca_archive_page_home_posts_per_page'							=> get_option( 'posts_per_page', 10 ),
	'alpaca_archive_page_home_hide_main_section'						=> '',

	/** section archive page category **/
	'alpaca_archive_page_category_layout'								=> '',
	'alpaca_archive_page_category_post_layout'							=> 'layout-masonry_column-3_',
	'alpaca_archive_page_category_image_ratio'							=> 'img-ratio-3-2',
	'alpaca_archive_page_category_grid_style'							=> 'grid-style-1',
	'alpaca_archive_page_category_grid_overlay_opacity'					=> '',
	'alpaca_archive_page_category_grid_overlay_large_title'				=> '',
	'alpaca_archive_page_category_show_category'						=> 'on',
	'alpaca_archive_page_category_show_author'							=> 'on',
	'alpaca_archive_page_category_show_date'							=> 'on',
	'alpaca_archive_page_category_show_update_date'						=> '',
	'alpaca_archive_page_category_show_reading_time'					=> 'on',
	'alpaca_archive_page_category_show_excerpt'							=> 'on',
	'alpaca_archive_page_category_show_read_more_button'				=> 'on',
	'alpaca_archive_page_category_posts_per_page'						=> get_option( 'posts_per_page', 10 ),

	/** section archive page homepage when homepage builder not enabled **/
	'alpaca_archive_page_blog_layout'									=> 'with-sidebar-right',
	'alpaca_archive_page_blog_post_layout'								=> 'layout-masonry_column-2_',
	'alpaca_archive_page_blog_image_ratio'								=> 'img-ratio-3-2',
	'alpaca_archive_page_blog_grid_style'								=> 'grid-style-1',
	'alpaca_archive_page_blog_grid_overlay_opacity'						=> '',
	'alpaca_archive_page_blog_grid_overlay_large_title'					=> '',
	'alpaca_archive_page_blog_show_category'							=> 'on',
	'alpaca_archive_page_blog_show_author'								=> 'on',
	'alpaca_archive_page_blog_show_update_date'							=> '',
	'alpaca_archive_page_blog_show_date'								=> 'on',
	'alpaca_archive_page_blog_show_reading_time'						=> 'on',
	'alpaca_archive_page_blog_show_excerpt'								=> 'on',
	'alpaca_archive_page_blog_show_read_more_button'					=> 'on',
	'alpaca_archive_page_blog_posts_per_page'							=> get_option( 'posts_per_page', 10 ),

	/** section archive page author **/
	'alpaca_archive_page_author_layout'									=> '',
	'alpaca_archive_page_author_post_layout'							=> 'layout-grid_column-3_',
	'alpaca_archive_page_author_image_ratio'							=> 'img-ratio-3-2',
	'alpaca_archive_page_author_grid_style'								=> 'grid-style-2',
	'alpaca_archive_page_author_grid_overlay_opacity'					=> '',
	'alpaca_archive_page_author_grid_overlay_large_title'				=> '',
	'alpaca_archive_page_author_show_category'							=> 'on',
	'alpaca_archive_page_author_show_author'							=> 'on',
	'alpaca_archive_page_author_show_date'								=> 'on',
	'alpaca_archive_page_author_show_update_date'						=> '',
	'alpaca_archive_page_author_show_reading_time'						=> 'on',
	'alpaca_archive_page_author_show_excerpt'							=> 'on',
	'alpaca_archive_page_author_show_read_more_button'					=> 'on',
	'alpaca_archive_page_author_posts_per_page'							=> get_option( 'posts_per_page', 10 ),

	/** section archive page author **/
	'alpaca_archive_page_search_layout'									=> '',
	'alpaca_archive_page_search_post_layout'							=> 'layout-masonry_column-3_',
	'alpaca_archive_page_search_image_ratio'							=> 'img-ratio-3-2',
	'alpaca_archive_page_search_grid_style'								=> 'grid-style-1',
	'alpaca_archive_page_search_grid_overlay_opacity'					=> '',
	'alpaca_archive_page_search_grid_overlay_large_title'				=> '',
	'alpaca_archive_page_search_show_category'							=> 'on',
	'alpaca_archive_page_search_show_author'							=> 'on',
	'alpaca_archive_page_search_show_date'								=> 'on',
	'alpaca_archive_page_search_show_update_date'						=> '',
	'alpaca_archive_page_search_show_reading_time'						=> 'on',
	'alpaca_archive_page_search_show_excerpt'							=> 'on',
	'alpaca_archive_page_search_show_read_more_button'					=> 'on',
	'alpaca_archive_page_search_posts_per_page'							=> get_option( 'posts_per_page', 10 ),

	/** section archive page tag **/
	'alpaca_archive_page_tag_layout'									=> 'with-sidebar-right',
	'alpaca_archive_page_tag_post_layout'								=> 'layout-masonry_column-2_',
	'alpaca_archive_page_tag_image_ratio'								=> 'img-ratio-3-2',
	'alpaca_archive_page_tag_grid_style'								=> 'grid-style-1',
	'alpaca_archive_page_tag_grid_overlay_opacity'						=> '',
	'alpaca_archive_page_tag_grid_overlay_large_title'					=> '',
	'alpaca_archive_page_tag_show_category'								=> 'on',
	'alpaca_archive_page_tag_show_author'								=> 'on',
	'alpaca_archive_page_tag_show_date'									=> 'on',
	'alpaca_archive_page_tag_show_update_date'							=> '',
	'alpaca_archive_page_tag_show_reading_time'							=> 'on',
	'alpaca_archive_page_tag_show_excerpt'								=> 'on',
	'alpaca_archive_page_tag_show_read_more_button'						=> 'on',
	'alpaca_archive_page_tag_posts_per_page'							=> get_option( 'posts_per_page', 10 ),

	/** section archive page date **/
	'alpaca_archive_page_date_layout'									=> 'with-sidebar-right',
	'alpaca_archive_page_date_post_layout'								=> 'layout-grid_column-2_',
	'alpaca_archive_page_date_image_ratio'								=> 'img-ratio-3-2',
	'alpaca_archive_page_date_grid_style'								=> 'grid-style-2',
	'alpaca_archive_page_date_grid_overlay_opacity'						=> '',
	'alpaca_archive_page_date_grid_overlay_large_title'					=> '',
	'alpaca_archive_page_date_show_category'							=> 'on',
	'alpaca_archive_page_date_show_author'								=> 'on',
	'alpaca_archive_page_date_show_date'								=> 'on',
	'alpaca_archive_page_date_show_update_date'							=> '',
	'alpaca_archive_page_date_show_reading_time'						=> 'on',
	'alpaca_archive_page_date_show_excerpt'								=> 'on',
	'alpaca_archive_page_date_show_read_more_button'					=> 'on',
	'alpaca_archive_page_date_posts_per_page'							=> get_option( 'posts_per_page', 10 ),

	/** section post **/
	'alpaca_single_post_default_template'								=> 'post-template-wide-header-img',
	'alpaca_single_post_default_page_layout'							=> 'with-sidebar-right',
	'alpaca_single_post_header_meta_show_category'						=> 'on',
	'alpaca_single_post_header_meta_show_author'						=> 'on',
	'alpaca_single_post_header_meta_show_date'							=> 'on',
	'alpaca_single_post_header_meta_show_update_date'					=> '',
	'alpaca_single_post_header_meta_show_reading_time'					=> 'on',
	'alpaca_single_post_header_meta_show_manual_excerpt'				=> 'on',
	'alpaca_single_post_footer_meta_show_view_counts'					=> 'on',
	'alpaca_single_post_footer_meta_show_like_counts'					=> 'on',
	'alpaca_single_post_footer_meta_show_comment_counts'				=> 'on',
	'alpaca_single_post_mobile_enable_large_post_header'				=> '',
	'alpaca_single_post_show_social_bar'								=> 'on',
	'alpaca_single_post_show_sticky_social_bar'							=> 'on',
	'alpaca_single_post_show_reading_progress_bar'						=> '',

	/** section after post **/
	'alpaca_single_post_show_author_info_box'							=> 'on',
	'alpaca_single_post_show_pagination'								=> 'on',

	'alpaca_single_post_show_signup_form'								=> '',
	'alpaca_single_post_signup_form_id'									=> alpaca_get_default_mc4wp_form_id(),
	'alpaca_single_post_signup_form_color_scheme'						=> 'dark-color',
	'alpaca_single_post_signup_form_bg_image'							=> '',
	'alpaca_single_post_signup_form_enable_color_overlay'				=> '',

	'alpaca_single_post_show_related_posts'								=> '',
	'alpaca_single_post_related_post_section_title'						=> esc_html__( 'You May Also Like', 'alpaca' ),
	'alpaca_single_post_related_post_filter'							=> 'category',
	'alpaca_single_post_related_post_number'							=> 4,
	'alpaca_single_post_related_post_image_ratio'						=> 'img-ratio-3-2',

	/** section typogaghy */
	'alpaca_typography_heading_font_family_source'						=> 'google_font',
	'alpaca_typography_heading_font-family' 							=> 'Merriweather',
	'alpaca_typography_text_font_family_source'							=> '',
	'alpaca_typography_text_font-family' 								=> 'IBM Plex Sans',

	'alpaca_typography_post_title_font-weight' 							=> '700',
	'alpaca_typography_post_title_text-transform'	 					=> 'none',
	'alpaca_typography_post_title_font-style' 							=> 'normal',

	'alpaca_typography_page_title_font-weight' 							=> '400',
	'alpaca_typography_page_title_text-transform'	 					=> 'none',
	'alpaca_typography_page_title_font-style' 							=> 'normal',

	'alpaca_typography_content_font_family'								=> 'text_font',
	'alpaca_typography_content_font-size' 								=> 16,
	'alpaca_typography_content_line-height' 							=> '1.8',

	'alpaca_typography_post_excerpt_font_family'						=> 'text_font',
	'alpaca_typography_post_excerpt_font-size' 							=> 14,
	'alpaca_typography_post_excerpt_overlay_font-size' 					=> 17,

	'alpaca_typography_homepage_section_title_font_family'				=> 'heading_font',
	'alpaca_typography_homepage_section_title_font-size'				=> 24,
	'alpaca_typography_homepage_section_title_font-weight'				=> '400',
	'alpaca_typography_homepage_section_title_letter-spacing'			=> '0',
	'alpaca_typography_homepage_section_title_text-transform'			=> 'none',

	'alpaca_typography_homepage_section_title_sub_font-size'			=> 14,
	'alpaca_typography_homepage_section_title_sub_font_family'			=> 'text_font',

	/** section advertisement before single post content **/
	'alpaca_ads_source_before_single_post_content' 						=> 'custom',
	'alpaca_ads_custom_url_before_single_post_content' 					=> '',
	'alpaca_ads_custom_image_before_single_post_content' 				=> '',
	'alpaca_ads_custom_image_width_before_single_post_content'			=> '1000',
	'alpaca_ads_custom_new_tab_before_single_post_content' 				=> '',
	'alpaca_ads_embed_code_before_single_post_content' 					=> '',

	/** section advertisement after single post content **/
	'alpaca_ads_source_after_single_post_content' 						=> 'custom',
	'alpaca_ads_custom_url_after_single_post_content' 					=> '',
	'alpaca_ads_custom_image_after_single_post_content' 				=> '',
	'alpaca_ads_custom_image_width_after_single_post_content'			=> '1000',
	'alpaca_ads_custom_new_tab_after_single_post_content' 				=> '',
	'alpaca_ads_embed_code_after_single_post_content' 					=> '',

	/** section advertisement before single page content **/
	'alpaca_ads_source_before_single_page_content' 						=> 'custom',
	'alpaca_ads_custom_url_before_single_page_content' 					=> '',
	'alpaca_ads_custom_image_before_single_page_content' 				=> '',
	'alpaca_ads_custom_image_width_before_single_page_content'			=> '1000',
	'alpaca_ads_custom_new_tab_before_single_page_content' 				=> '',
	'alpaca_ads_embed_code_before_single_page_content' 					=> '',

	/** section advertisement after single page content **/
	'alpaca_ads_source_after_single_page_content' 						=> 'custom',
	'alpaca_ads_custom_url_after_single_page_content' 					=> '',
	'alpaca_ads_custom_image_after_single_page_content' 				=> '',
	'alpaca_ads_custom_image_width_after_single_page_content'			=> '1000',
	'alpaca_ads_custom_new_tab_after_single_page_content' 				=> '',
	'alpaca_ads_embed_code_after_single_page_content' 					=> '',

	/** section 404 page **/
	'alpaca_404_page_title'												=> esc_html__( 'Page Not Found', 'alpaca' ),
	'alpaca_404_page_message'											=> esc_html__( 'Sorry but we couldn\'t find the page you are looking for. It might have been moved or deleted. Perhaps searching can help.', 'alpaca' ),
	'alpaca_404_page_show_search_form'									=> 'on',
	'alpaca_404_page_color_scheme'										=> 'light-color',
	'alpaca_404_page_bg_image'											=> '',

	/** section popup signup form **/
	'alpaca_popup_signup_form_id'										=> alpaca_get_default_mc4wp_form_id(),
	'alpaca_popup_signup_form_auto_display'								=> 'on',
	'alpaca_popup_signup_form_auto_display_once_per_session'			=> '',
	'alpaca_popup_signup_form_display_delay'							=> '0',
	'alpaca_popup_signup_form_not_distrub_text'							=> esc_html__( 'No, thanks.', 'alpaca' ),
	'alpaca_popup_signup_form_exit_message_after_signed'				=> esc_html__( 'Close and continue browsing', 'alpaca' ),
	'alpaca_popup_signup_form_color_scheme'								=> 'light-color',
	'alpaca_popup_signup_form_light_color_background_color'				=> '',
	'alpaca_popup_signup_form_dark_color_background_color'				=> '',
	'alpaca_popup_signup_form_image'									=> '',

	/** section woocommerce sidebar options **/
	'alpaca_shop_archive_sidebar'										=> 'with-sidebar-right',
	'alpaca_shop_single_sidebar'										=> 'with-sidebar-right'
) );
