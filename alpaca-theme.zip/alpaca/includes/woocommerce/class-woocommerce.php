<?php
/**
* Woocommerce related frontend render class.
*/

if ( class_exists( 'WooCommerce' ) && ! class_exists( 'Alpaca_Woocommerce' ) ) {
	class Alpaca_Woocommerce {
		public static $_instance = null;
		private $wc_pages = array( 'myaccount', 'cart', 'checkout' );
		private $header_bg = false;
		protected $has_header_image = false;
		protected $header_image_id = false;
		private $is_archive = false;
		private $is_static_pages = false;
		private $name = '';
		private $description = '';
		public function __construct() {
			$this->load_support();

			add_action( 'wp', array( $this, 'load_frontend_actions' ), 999 );
			add_action( 'widgets_init', array( $this, 'register_sidebar' ), 9999 );

			add_filter( 'theme_page_templates', array( $this, 'remove_page_template' ), 99, 3 );
			add_filter( 'alpaca_static_pages', array( $this, 'static_pages' ) );
		}
		/**
		* Initilize to support woocommerce features
		*/
		public function load_support() {
			add_theme_support( 'woocommerce' );
			add_theme_support( 'wc-product-gallery-zoom' );
			add_theme_support( 'wc-product-gallery-lightbox' );
			add_theme_support( 'wc-product-gallery-slider' );
		}
		/**
		* Register sidebar for woocommerce archive/product pages
		*/
		public function register_sidebar() {
			register_sidebar( array(
				'name'          => esc_html__( 'Shop Sidebar', 'alpaca' ),
				'id'            => 'shop-sidebar',
				'description'   => esc_html__( 'Add widgets here to appear in your shop sidebar.', 'alpaca' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="widget-header"><h5 class="widget-title">',
				'after_title'   => '</h5></div>'
			) );
		}
		/**
		* Load frontend related actions
		*/
		public function load_frontend_actions() {
			// The class will be initialized in action wp, so it's saft to call all functions
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_script' ), 5 );
			add_filter( 'alpaca_front_inline_styles_handler', array( $this, 'inline_style_handler' ) );
			add_filter( 'alpaca_front_get_main_theme_style_dependency', array( $this, 'theme_css_deps' ) );
			add_filter( 'woocommerce_sale_flash', array( $this, 'sale_label' ), 999, 3 );

			$wc_static_page_ids = $this->get_woocommerce_pages( $this->wc_pages );
			$this->is_static_pages = ! empty( $wc_static_page_ids ) && is_page( $wc_static_page_ids );

			if ( ! is_admin() && ( $this->is_shop() || is_product_taxonomy() || is_singular( 'product' ) || $this->is_static_pages ) ) {
				add_filter( 'alpaca_sidebar_id', array( $this, 'get_sidebar_id' ), 999 );
				add_filter( 'alpaca_content_class', array( $this, 'get_content_class' ), 99999 );
				add_filter( 'alpaca_page_layout', array( $this, 'get_page_layout' ), 999 );
			}
			if ( $this->is_static_pages ) {
				add_filter( 'template_include', array( $this, 'shop_general_pages' ), 99 );
			}

			if ( $this->is_shop() || is_product_taxonomy() ) {
				remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
			}

			add_filter( 'woocommerce_output_related_products_args', array( $this, 'related_products_args' ), 99 );
			add_filter( 'woocommerce_upsell_display_args', 			array( $this, 'upsell_products_args' ), 99 );
			add_filter( 'woocommerce_product_review_comment_form_args',	array( $this, 'add_comment_form_fields' ) );

			add_action( 'woocommerce_before_main_content', 			array( $this, 'before_main_content' ), 0 );
			add_action( 'woocommerce_after_main_content', 			array( $this, 'after_main_content' ), 999 );
			add_action( 'woocommerce_sidebar', 						array( $this, 'after_sidebar'), 999 );
			add_action( 'woocommerce_single_product_summary', 		array( $this, 'social_sharing' ), 99 );
			add_action( 'woocommerce_before_shop_loop_item_title', 	array( $this, 'loop_out_of_stock' ), 5 );

			remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
			remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );

			remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
			add_action( 'woocommerce_single_product_summary', 'woocommerce_breadcrumb', 1 );

			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'loop_item_start' ), 6 );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'loop_item_title' ), 6 );
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_rating', 6 );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'loop_item_addcart_start' ), 6 );
			add_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_price', 6 );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'loop_item_addcart_end' ), 35 );
			add_action( 'woocommerce_after_shop_loop_item', array( $this, 'loop_item_end' ), 35 );
		}
		/**
		* Change woocommerce static page template
		*/
		public function shop_general_pages( $template ) {
		    $new_template = locate_template( array( 'woocommerce/general-template.php' ) );
		    if ( '' != $new_template ) {
		        return $new_template ;
		    }
		    return $template;
		}
		/**
		* Get page layout setting id
		* @param string
		* @return string
		*/
		public function get_page_layout( $layout ) {
			return $this->is_static_pages ? '' : alpaca_get_theme_mod( is_singular() ? 'alpaca_shop_single_sidebar' : 'alpaca_shop_archive_sidebar' );
		}
		/**
		* Class for site content
		*/
		public function get_content_class( $class ) {
			$class = array_diff( $class, array( 'with-sidebar-right', 'with-sidebar-left' ) );
			$layout = $this->get_page_layout( '' );
			if ( ! empty( $layout ) && is_active_sidebar( 'shop-sidebar' ) ) {
				array_push( $class, $layout );
			}
			return $class;
		}
		/**
		* Remove page template option for woocommerce pages
		* @param array template list
		* @param object WP_Theme class object
		* @param object WP_Post class object
		*/
		public function remove_page_template( $page_templates, $theme, $post ) {
			$pages = $this->get_woocommerce_pages( $this->wc_pages );
			if ( $post && ( count( $pages ) > 0 ) && in_array( absint( $post->ID ), $pages ) ) {
				$page_templates = array();
			}
			return $page_templates;
		}
		/**
		* Get the woocommerce static pages
		*/
		public function static_pages( $pages ) {
			$wc_pages = $this->wc_pages;
			array_push( $wc_pages, 'shop' );
			$wc_page_ids = $this->get_woocommerce_pages( $wc_pages );
			return is_array( $wc_page_ids ) ? array_merge( $pages, $wc_page_ids ) : $pages;
		}
		/**
		* Enqueue woocommerce related style file
		*/
		public function enqueue_script() {
			$suffix = alpaca_get_assets_suffix();
			wp_enqueue_style( 'alpaca-woocommerce', ALPACA_ASSETS_URI . 'styles/front/shop' . $suffix . '.css', array( 'alpaca-theme-style' ), ALPACA_ASSETS_VERSION );
		}
		/**
		* Add woocommerce style to theme main css dependency list
		*/
		public function theme_css_deps( $deps ) {
			$deps = array_merge( $deps, array( 'woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen' ) );
			return $deps;
		}
		/**
		* Theme inline style handler
		*/
		public function inline_style_handler( $handler ) {
			return 'alpaca-woocommerce';
		}
		/**
		* Get sidebar id for woocommerce pages
		*/
		public function get_sidebar_id( $id ) {
			return 'shop-sidebar';
		}
		/**
		* Change related product query args
		*/
		public function related_products_args( $args ) {
			$args['posts_per_page'] = 3; // 3 related products
			$args['columns'] = 3; // arranged in 3 columns
			return $args;
		}
		/**
		* Change upsell product query args
		*/
		public function upsell_products_args( $args ) {
			$args['posts_per_page'] = 3; // 3 related products
			$args['columns'] = 3; // arranged in 3 columns
			return $args;
		}
		/**
		* Add url field for single product comment form
		*/
		public function add_comment_form_fields( $comment_form ) {
			$fields = isset($comment_form['fields']) ? $comment_form['fields'] : array();
			if ( empty( $fields['url'] ) ) {
				$commenter = wp_get_current_commenter();
				$fields['url'] = sprintf(
					'<p class="comment-form-url"><label for="url">%s</label>%s</p>',
					esc_html__( 'Website', 'alpaca' ),
					sprintf(
						'<input id="url" name="url" type="url" value="%s" size="30" maxlength="200" />',
						esc_attr( $commenter['comment_author_url'] )
					)
				);
			}
			$comment_form['fields'] = $fields;

			return $comment_form;
		}
		public function loop_out_of_stock() {
			global $product;
			if ( ! $product->managing_stock() && ! $product->is_in_stock() ) : ?>
				<span class="stock out-of-stock"><?php esc_html_e( 'Sold Out', 'alpaca' ); ?></span><?php
			endif;
		}
		/**
		* Add open wrap divs before main content
		*/
		public function before_main_content() {
			if ( $this->is_shop() || is_product_taxonomy() ) :
				$image_id = $this->get_page_image_id();
				$has_image = alpaca_is_item_exists( $image_id ); ?>
				<header class="archive-header<?php if ( $has_image ) : ?> overlay-header<?php endif; ?>"><?php
					if ( $has_image ) : ?>
					<div<?php alpaca_the_page_header_class(); ?>>
						<div class="header-img-container"><?php
						alpaca_the_preload_bg( array(
							'id' => $image_id,
				            'sizes' => Alpaca_Utils_Image::get_image_sizes( array( 'module' => 'site', 'sub_module' => 'page-header' ) ),
				            'class' => 'featured-img-container'
						) ); ?>
						</div>
					</div><?php
					endif; ?>

					<div class="header-text"><?php
						woocommerce_breadcrumb();
						if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
							<h1 class="archive-title"><?php woocommerce_page_title(); ?></h1><?php
						endif;
						do_action( 'woocommerce_archive_description' ); ?>
					</div>
				</header><?php
			endif; ?>
			<div class="main">
				<div class="container">
					<div id="primary" class="primary content-area"> <?php
		}
		/*
		* Add close wrap div after main content
		*/
		public function after_main_content() { ?>
					</div> <?php
		}
		/**
		* Add close wrap div after sidebar
		*/
		public function after_sidebar() { ?>
				</div>
			</div><?php
		}
		/**
		* Add Social sharing buttons after product description
		*/
		public function social_sharing() {
			$socials = alpaca_get_enabled_sharing();
			if ( alpaca_is_valid_array( $socials ) && alpaca_is_extension_activated() ) :
				$socials = array_diff( $socials, array( 'like' ) );
				if ( apply_filters( 'loftocean_has_social_sharing_icons', false, $socials ) ) : ?>
					<div class="social-share-icons">
						<span><?php esc_html_e( 'Share: ', 'alpaca' ); ?></span>
						<div class="share-container">
							<div class="share-icons"><?php do_action( 'loftocean_the_social_sharing_icons', $socials, false ); ?></div>
						</div>
					</div><?php
				endif;
			endif;
		}
		/**
		* Add open wrap div open before product link
		*/
		public function list_item_open_wrap() { ?>
			<div class="product-image"> <?php
		}
		/**
		* Add close wrap div after add to cart link
		*/
		public function list_item_close_wrap() { ?>
			</div><?php
		}
		/**
		* Loop item title
		*/
		public function loop_item_title() { ?>
			<h2 class="<?php echo esc_attr( apply_filters( 'woocommerce_product_loop_title_classes', 'woocommerce-loop-product__title' ) ); ?>">
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h2><?php
		}
		/**
		* Loop item add to cart start
		*/
		public function loop_item_addcart_start() { ?>
			<div class="price-addcart-wrapper"><?php
		}
		/**
		* Loop item add to cart end
		*/
		public function loop_item_addcart_end() { ?>
			</div><?php
		}
		/**
		* Loop item start html
		*/
		public function loop_item_start() { ?>
			<div class="product-info"><?php
		}
		/**
		* Loop item start html
		*/
		public function loop_item_end() { ?>
			</div><?php
		}
		/**
		* Change sales label
		*/
		public function sale_label( $label, $post, $product ) {
			return '<span class="onsale">' . esc_html__( 'Sale', 'alpaca' ) . '</span>';
		}
		/**
		* Get woocommerce static page ids
		* @param mix pages
		* @return mix return boolean false if no page passed,
		*	if page exists and only one request one page, return the id,
		*		otherwise return array of ids.
		*/
		private function get_woocommerce_pages( $pages ) {
			$ids = false;
			if ( ! empty( $pages ) ) {
				if ( is_array( $pages ) ) {
					$ids = array();
					foreach ( $pages as $p ) {
						$id = wc_get_page_id( $p );
						if ( ! empty( $id ) && ( $id !== -1 ) ) {
							array_push( $ids, $id );
						}
					}
				} else {
					$ids = wc_get_page_id( $pages );
				}
			}
			return $ids;
		}
		/**
		* Test if is in shop page
		*/
		private function is_shop() {
			$page_id = wc_get_page_id( 'shop' );
			return alpaca_is_item_exists( $page_id ) && is_shop();
		}
		/**
		* Get shop page header image id or archive page header image id
		*/
		protected function get_page_image_id() {
			if ( $this->is_shop() ){
				$shop_page = get_post( wc_get_page_id( 'shop' ) );
				return get_post_thumbnail_id( $shop_page->ID );
			} else if ( is_product_taxonomy() ) {
				$queried = get_queried_object();
				return get_term_meta( $queried->term_id, 'thumbnail_id', true );
			}
			return false;
		}
		/**
		* To make sure only one instance exists
		*/
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}
	}
	Alpaca_Woocommerce::instance();
}
