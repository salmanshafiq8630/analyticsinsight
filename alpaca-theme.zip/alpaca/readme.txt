=== Alpaca ===
Author: loftocean
Requires at least: WordPress 5.0
Tested up to: WordPress 5.9
Version: 1.6.0
License: GPL-2.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: full-width-template, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, rtl-language-support, sticky-post, threaded-comments, translation-ready

== Description ==
Alpaca is a WordPress theme for independent magazine.

== Copyright ==
(c) Copyright Loft.Ocean 2021 to 2022 loftocean.com

Alpaca bundles the following third-party resources:

HTML5 Shiv v3.7.3, @afarkas @jdalton @jon_neal @rem
Licenses: MIT/GPL2
Source: https://github.com/aFarkas/html5shiv

Font Awesome 5.12.1, by @davegandy - http://fontawesome.io - @fontawesome
Licenses: Full Font Awesome Free license, http://fontawesome.io/license
Source: http://fontawesome.io

Elegant Icon Font, Copyright (c) Elegant Themes
Licenses: GPL v2.0 and MIT license, http://www.gnu.org/licenses/gpl-2.0.html, https://opensource.org/licenses/MIT
Source: https://www.elegantthemes.com/blog/resources/elegant-icon-font

Modernizr v2.8.3, copyright (c) Faruk Ates, Paul Irish, Alex Sexton
Licenses: BSD and MIT, www.modernizr.com/license/
Source: www.modernizr.com

FitVids 1.1, Copyright 2013, Chris Coyier
Licenses: WTFPL, http://sam.zoy.org/wtfpl/
Source: http://fitvidsjs.com/

Slick Slider 1.6.0, Ken Wheeler
Licensed: MIT, https://github.com/kenwheeler/slick/blob/master/LICENSE
Source: http://kenwheeler.github.io/slick/

Justified Gallery v3.6.3, Copyright (c) 2018 Miro Mannino
Licensed: MIT, https://github.com/miromannino/Justified-Gallery/blob/master/LICENSE
Source: http://miromannino.github.io/Justified-Gallery/

All photos are licensed under The Unsplash License (https://unsplash.com/license)

== Changelog ==
= 1.6.0 =
* Fixed: Conflict with Smash Balloon Instagram Feed (v6.0.1) update
* Fixed: Customizer style issue in WordPress 5.9 that prevented home widgets from moving
* Fixed: Gutenberg Editor style issues in WordPress 5.9
* Fixed: Empty div in Custom Widget - Posts
* Fixed: Incorrect author information displayed in the Author Archive page haeder in some cases
* Updated: Google Fonts List 
* Updated: Required Plugin Alpaca Extension updated to v1.6

= 1.5.0 =
* Fixed: Compatibility issue with WooCommerce version 5.6.0 (WooCommerce v5.6.0 changed a file name, resulting in a logic error in loading stylesheets)
* Fixed: Custom Widget - Alpaca Posts - issue of calculating reading time by character
* Fixed: Sticky Sidebar position issue when using Google Adsense
* Fixed: Google AdSense code cannot be converted correctly
* Fixed: Minor CSS Issues
* Updated: Required Plugin Alpaca Extension updated to v1.5

= 1.4.0 =
* Added: New Demos
* Added: Support displaying Yoast SEO breadcrumbs
* Added: New post meta - Update Date
* Added: New Posts Layout - List
* Added: New home widget - Posts Slider (including 2 slider styles)
* Added: Options to enable/disable entrance animation
* Improved: Progressive image loading and lazy loading features can be enabled/disabled separately
* Fixed: Google AdSense code cannot be converted correctly
* Fixed: Minor CSS Issues
* Updated: Required Plugin Alpaca Extension updated to v1.4

= 1.3.0 =
* Added: New home widget - Rolling Text
* Added: New Gutenberg block - Rolling Text
* Added: Reading Speed - calculated by word count or character count
* Added: Related Posts - Image Ratio Option
* Added: Grid Overlay Posts - Overlay Opacity options
* Added: Grid Overlay Posts - Large Title option
* Added: Split Template - Option to enable Large Post Header on mobile devices
* Improved: The effect of the color mode switcher on websites with cache plugins
* Fixed: Minor issues with WPML & Polylang
* Fixed: RTL CSS Issues
* Fixed: Other minor CSS Issues

= 1.2.0 =
* Added: New Demos
* Fixed: Minor CSS Issues
* Fixed: Instagram issue when loading Instagram feed by AJAX

= 1.1.0 =
* Added: New Demos
* Fixed: Minor CSS Issues

= 1.0.0 =
* Initial Release
