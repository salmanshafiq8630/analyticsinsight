<?php
// Main template for singles

get_header();

get_template_part( 'template-parts/single/content', get_post_type() );

get_footer();
