<!DOCTYPE html>
<html <?php language_attributes(); ?><?php alpaca_the_html_class(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="//gmpg.org/xfn/11">
		<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
		<?php endif; ?>
		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>
		<?php alpaca_body_open(); ?>
		<?php do_action( 'alpaca_the_advertisement', 'site_top' ); ?>
		<?php get_template_part( 'template-parts/site-header/site-header' ); ?>
		<div id="page">
			<div id="content" <?php alpaca_the_content_class(); ?>>
