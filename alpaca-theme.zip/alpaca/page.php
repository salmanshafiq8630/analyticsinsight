<?php
// Main template for singles

get_header();

while ( have_posts() ) :
    the_post();
    get_template_part( 'template-parts/headers/page' ); ?>
    <div class="main">
    	<div class="container">
    		<div id="primary" class="primary content-area">
    			<article <?php post_class(); ?>>
    				<div class="article-content"><?php
                        if ( is_singular( 'page' ) && apply_filters( 'alpaca_show_advertisement_before_content', false, get_the_ID() ) ) {
                    		do_action( 'alpaca_the_advertisement', 'before_single_page_content' );
                    	} ?>
    					<div class="entry-content"><?php
                            the_content();
                            alpaca_the_single_pagination(); ?>
                        </div><!-- end of .entry-content --><?php
                        if ( get_edit_post_link() ) {
                            alpaca_meta_edit_link();
                        }
                        if ( is_singular( 'page' ) && apply_filters( 'alpaca_show_advertisement_after_content', false, get_the_ID() ) ) {
                    		do_action( 'alpaca_the_advertisement', 'after_single_page_content' );
                    	} ?>
    				</div>
    			</article><?php
                if ( comments_open() || get_comments_number() ) {
                    comments_template();
                } ?>
    		</div><!-- end of #primary -->
            <?php get_sidebar(); ?>
    	</div>
    </div><?php
endwhile;
wp_reset_postdata();

get_footer();
