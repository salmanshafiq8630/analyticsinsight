/**
* Copyright (c) Loft.Ocean
* http://www.loftocean.com
*/

( function( api, $, parent ) {
	"use strict";

	/** Global jQuery objects **/
	var $body = $( 'body' ), $head = $( 'head' ), $fullscreenMenu = $( '.alpaca-fullmenu' ), $siteFooter = $( '.site-footer' ), $popupForm = $( '.popup-signup' ),
		$siteFooterSignupForm = $( '.site-footer .site-footer-signup' ), $siteFooterInstagram = $( '.site-footer .alpaca-widget_instagram' ), $siteFooterBottom = $( '.site-footer .footer-bottom' );

	/**
	* Get attachment url
	* @param string attachment id
	* @return mix if attachment exists attachment url, otherwise boolean false
	*/
	function getAttachmentUrl( id ) {
		if ( id && parent && parent.wp && parent.wp.media ) {
			var attachment = parent.wp.media.attachment( id );
			attachment.fetch();
			return attachment && attachment.attributes ? attachment.get( 'url' ) : false;
		}
		return false;
	}
	/**
	* Set inline styles to <head>
	* @param style id
	* @param string style
	*/
	function updateStyle( id, style ) {
		var $style 	= $head.find( '#' + id );
		style 	= style || '';
		if ( ! $style.length ) {
			$style = $( '<style>', { 'id': id } )
				.appendTo( $head );
		}
		$style.html( style );
	}
	/**
	* Get default colors
	*/
	function getDefaultColors( id ) {
		return id && alpacaCustomizerPreview && alpacaCustomizerPreview[ id ] ? alpacaCustomizerPreview[ id ] : { 'light': '', 'dark': '' };
	}

	/** Customize setting event hanlder if their transort are set with postMessage **/
	api( 'blogname', function( value ) {
		value.bind( function( to ) {
			$( '.site-title a' ).text( to );
		} );
	} );
	api( 'blogdescription', function( value ) {
		value.bind( function( to ) {
			$( '.site-description' ).text( to );
		} );
	} );
	api( 'alpaca_site_color_scheme', function( value ) {
		value.bind( function( to ) {
			$body.removeClass( 'light-color dark-color' ).addClass( to );
		} );
	} );

	// General
	api( 'alpaca_general_enable_posts_entrance_animation', function( value ) {
		value.bind( function( to ) {
			to ? $body.addClass( 'posts-enter-animation' ) : $body.removeClass( 'posts-enter-animation' );
		} );
	} );

	//Site header
	api( 'alpaca_site_header_hide_more_label', function( value ) {
		value.bind( function( to ) {
			var $more = $( '.header-section-more' );
			if ( $more.length ) {
				to ? $more.addClass( 'hide-label' ) : $more.removeClass( 'hide-label' );
			}
		} );
	} );
	api( 'alpaca_site_header_fullscreen_search_style', function( value ) {
		value.bind( function( to ) {
			var $searchScreen = $( '.search-screen' );
			if ( $searchScreen ) {
				to ? $searchScreen.addClass( 'minimal' ) : $searchScreen.removeClass( 'minimal' );
			}
		} );
	} );

	// Fullscreen site header
	api( 'alpaca_fullscreen_menu_color_scheme', function( value ) {
		value.bind( function( to ) {
			if ( $fullscreenMenu.length && $fullscreenMenu.find( '.menu-wrapper' ).length ) {
				$fullscreenMenu.find( '.menu-wrapper' ).removeClass( 'dark-color light-color' ).addClass( to );
			}
		} );
	} );
	api( 'alpaca_fullscreen_menu_background_image', function( value ) {
		value.bind( function( to ) {
			if ( $fullscreenMenu.length ) {
				var $wrap = $fullscreenMenu.find( '.menu-wrapper' ), $bgContainer = $fullscreenMenu.find( '.fullmenu-bg .fullmenu-bg-container' );
				if ( ! $bgContainer.length ) {
					var containerClass = api( 'alpaca_fullscreen_menu_enable_overlay' )() ? 'fullmenu-bg has-overlay' : 'fullmenu-bg';
					$bgContainer = $( '<div>', { 'class': 'fullmenu-bg-container' } );
					$( '<div>', { 'class': containerClass } ).append( $bgContainer ).prependTo( $wrap );
				}
				to ? $bgContainer.css( 'backgroundImage', 'url(' + getAttachmentUrl( to ) + ')' ) : $bgContainer.parent().remove();
			}
		} );
	} );
	api( 'alpaca_fullscreen_menu_enable_overlay', function( value ) {
		value.bind( function( to ) {
			var $bg = $fullscreenMenu.find( '.menu-wrapper .fullmenu-bg' );
			if ( $bg.length ) {
				to ? $bg.addClass( 'has-overlay' ) : $bg.removeClass( 'has-overlay' );
			}
		} );
	} );
	api( 'alpaca_fullscreen_menu_background_color', function( value ) {
		value.bind( function( to ) {
			var colors = getDefaultColors( 'alpaca_fullscreen_menu_background_color' ),
				styles = to
					? '.alpaca-fullmenu .menu-wrapper:before { background-color: ' + to + '; }'
						: '.alpaca-fullmenu .menu-wrapper.light-color:before { background-color: ' + colors.light + '; } .alpaca-fullmenu .menu-wrapper.dark-color:before { background-color: ' + colors.dark + '; }'

			updateStyle( 'alpaca-fullscreen-menu-background-color', styles );
		} );
	} );
	api( 'alpaca_fullscreen_menu_text_color', function( value ) {
		value.bind( function( to ) {
			var colors = getDefaultColors( 'alpaca_fullscreen_menu_text_color' ),
				styles = to
					? '.alpaca-fullmenu .menu-wrapper .container { color: ' + to + '; }'
						: '.alpaca-fullmenu .menu-wrapper.light-color  .container { color: ' + colors.light + '; } .alpaca-fullmenu .menu-wrapper.dark-color  .container { color: ' + colors.dark + '; }'

			updateStyle( 'alpaca-fullscreen-menu-text-color', styles );
		} );
	} );
	api( 'alpaca_fullscreen_menu_show_search_form', function( value ) {
		value.bind( function( to ) {
			if ( $fullscreenMenu.length && $fullscreenMenu.find( '.search' ).length ) {
				to ? $fullscreenMenu.find( '.search' ).removeClass( 'hide' ) : $fullscreenMenu.find( '.search' ).addClass( 'hide' );
			}
		} );
	} );
	api( 'alpaca_fullscreen_menu_copyright_text', function( value ) {
		value.bind( function( to ) {
			if ( $fullscreenMenu.length && $fullscreenMenu.find( '.menu-wrapper .text' ).length ) {
				$fullscreenMenu.find( '.menu-wrapper .text' ).html( to );
			}
		} );
	} );
	api( 'alpaca_fullscreen_menu_widgets_color_scheme', function( value ) {
		value.bind( function( to ) {
			if ( $fullscreenMenu.length && $fullscreenMenu.find( '.widgets-wrapper' ).length ) {
				$fullscreenMenu.find( '.widgets-wrapper' ).removeClass( 'dark-color light-color' ).addClass( to );
			}
		} );
	} );
	api( 'alpaca_fullscreen_menu_widgets_background_color', function( value ) {
		value.bind( function( to ) {
			var colors = getDefaultColors( 'alpaca_fullscreen_menu_widgets_background_color' ),
				styles = to
					? '.alpaca-fullmenu .widgets-wrapper:before { background-color: ' + to + '; }'
						: '.alpaca-fullmenu .widgets-wrapper.light-color:before { background-color: ' + colors.light + '; } .alpaca-fullmenu .widgets-wrapper.dark-color:before { background-color: ' + colors.dark + '; }'

			updateStyle( 'alpaca-fullscreen-widgets-menu-background-color', styles );
		} );
	} );
	api( 'alpaca_fullscreen_menu_widgets_text_color', function( value ) {
		value.bind( function( to ) {
			var colors = getDefaultColors( 'alpaca_fullscreen_menu_widgets_text_color' ),
				styles = to
					? '.alpaca-fullmenu .widgets-wrapper .container { color: ' + to + '; }'
						: '.alpaca-fullmenu .widgets-wrapper.light-color .container { color: ' + colors.light + '; } .alpaca-fullmenu .widgets-wrapper.dark-color .container { color: ' + colors.dark + '; }'

			updateStyle( 'alpaca-fullscreen-widgets-menu-text-color', styles );
		} );
	} );

	// Site footer
	api( 'alpaca_site_footer_signup_form_color_scheme', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterSignupForm.length ) {
				$siteFooterSignupForm.removeClass( 'light-color dark-color' ).addClass( to );
			}
		} );
	} );
	api( 'alpaca_site_footer_signup_form_enable_color_overlay', function( value) {
		value.bind( function( to ) {
			if ( $siteFooterSignupForm.length ) {
				to ? $siteFooterSignupForm.addClass( 'has-overlay' ) : $siteFooterSignupForm.removeClass( 'has-overlay' );
			}
		} );
	} );
	api( 'alpaca_site_footer_instagram_color_scheme', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterInstagram.length ) {
				$siteFooterInstagram.removeClass( 'light-color dark-color' ).addClass( to );
			}
		} );
	} );
	api( 'alpaca_site_footer_bottom_color_scheme', function( value ) {
		value.bind( function( to ) {
			if ( $siteFooterBottom.length ) {
				$siteFooterBottom.removeClass( 'light-color dark-color' ).addClass( to );
			}
		} );
	} );

	// Popup signup form
	api( 'alpaca_popup_signup_form_auto_display', function( value ) {
		value.bind( function( to ) {
			if ( $popupForm.length ) {
			//	to ? $popupForm.addClass( 'show' ) : $popupForm.removeClass( 'show' );
			}
		} );
	} );
	api( 'alpaca_popup_signup_form_not_distrub_text', function( value ) {
		value.bind( function( to ) {
			if ( $popupForm.length ) {
				var $wrap = $popupForm.find( '.popup-exit' );
				if ( $wrap.length ) {
					var $link = $wrap.find( '.alpaca-disable-popup-signup-form' );
					if ( ! $link.length ) {
						$link = $( '<a>', { 'class': 'alpaca-disable-popup-signup-form' } );
						$wrap.prepend( $link );
					}
					to ? $link.text( to ) : $link.remove();
				}
			}
		} );
	} );
	api( 'alpaca_popup_signup_form_exit_message_after_signed', function( value ) {
		value.bind( function( to ) {
			var $wrap = $popupForm.find( '.popup-exit' );
			if ( $wrap.length ) {
				var $link = $wrap.find( '.alpaca-exit-popup-signup-form' );
				if ( ! $link.length ) {
					$link = $( '<a>', { 'class': 'alpaca-exit-popup-signup-form' } );
					$wrap.append( $link );
				}
				to ? $link.text( to ) : $link.remove();
			}
		} );
	} );
	api( 'alpaca_popup_signup_form_color_scheme', function( value ) {
		value.bind( function( to ) {
			$popupForm.length ? $popupForm.removeClass( 'light-color dark-color' ).addClass( to ) : '';
		} );
	} );
	api( 'alpaca_popup_signup_form_light_color_background_color', function( value ) {
		value.bind( function( to ) {
			var defaultColor = alpacaCustomizerPreview.alpaca_popup_signup_form_light_color_background_color ? alpacaCustomizerPreview.alpaca_popup_signup_form_light_color_background_color : '',
			 	styles = to ? '.popup-signup.light-color .container-inner { background-color: ' + to + '}' : '.popup-signup.light-color .container-inner { background-color: ' + defaultColor + '}';
			updateStyle( 'alpaca-popup-signup-form-light-color-background-color', styles );
		} );
	} );
	api( 'alpaca_popup_signup_form_dark_color_background_color', function( value ) {
		value.bind( function( to ) {
			var defaultColor = alpacaCustomizerPreview.alpaca_popup_signup_form_dark_color_background_color ? alpacaCustomizerPreview.alpaca_popup_signup_form_dark_color_background_color : '',
			 	styles = to ? '.popup-signup.dark-color .container-inner { background-color: ' + to + '}' : '.popup-signup.dark-color .container-inner { background-color: ' + defaultColor + '}';
			updateStyle( 'alpaca-popup-signup-form-dark-color-background-color', styles );
		} );
	} );
	api( 'alpaca_popup_signup_form_image', function( value ) {
		value.bind( function( to ) {
			if ( $popupForm.length ) {
				var $background = $popupForm.find( '.img-wrapper' );
				if ( ! $background.length ) {
					$background = $( '<div>', { 'class': 'img-wrapper' } ).prependTo( $popupForm.find( '.container-inner' ) );
				}
				if ( to ) {
					$background.css( 'backgroundImage', 'url(' + getAttachmentUrl( to ) + ')' );
					$popupForm.addClass( 'has-img' );
				} else {
					$background.remove();
					$popupForm.removeClass( 'has-img' );
				}
			}
		} );
	} );

	// 404 page
	api( 'alpaca_404_page_color_scheme', function( value ) {
		value.bind( function( to ) {
			var $page404 = $( '.error404 .page.type-page.page-404' );
			if ( $page404.length ) {
				$page404.removeClass( 'light-color dark-color' ).addClass( to );
			}
		} );
	} );
	api( 'alpaca_404_page_bg_image', function( value ) {
		value.bind( function( to ) {
			var $page404 = $( '.error404 .page.type-page.page-404' );
			if ( $page404.length ) {
				var $bg = $page404.find( '.page-404-bg' ).length ? $page404.find( '.page-404-bg' ) : $( '<div>', { 'class': 'page-404-bg' } ).prependTo( $page404 );
				to ? $bg.css( 'background-image', 'url(' + to + ')' ) : $bg.css( 'background-image', '' );
			}
		} );
	} );

	$( 'body' ).on( 'click', '.popup-signup.show .close-button', function( e ) {
		e.preventDefault();
		$popupForm.removeClass( 'show' );
	} )

} ) ( wp.customize, jQuery, parent );
