/**
* Copyright (c) Loft.Ocean
* http://www.loftocean.com
*/

( function( api, $ ) {
	"use strict";

	/** Add theme special class to control wrap */
	$( '#customize-theme-controls' ).addClass( 'alpaca-customizer-wrapper' );
	api.alpaca = api.alpaca || {};
	api.alpaca.controls = api.alpaca.controls || {};

	var site_layout_id = 'alpaca_site_layout';

	/**
	* Helper function is Object
	*/
	function isObject( obj ) {
		var type = typeof obj;
		return type === 'function' || type === 'object' && !!obj;
	}
	/**
	* Helper function object given is not empty
	*/
	function notEmptyObejct( obj ) {
		for ( var key in obj ) {
			return obj.hasOwnProperty( key );
		}
	}
	/**
	* Get the customize control's first setting name
	* @param object customize control
	* @return mix customize setting id string if exists, otherwise boolean false
	*/
	function getControlSettingId( control ) {
		var control_settings = control.settings,
			keys = Object.keys( control_settings ),
			first_key = ( 'default' in control_settings )  ? 'default' : ( keys.length ? keys[0] : false );
		return first_key ? control_settings[ first_key ] : false;
	}
	/**
	* Get setting dependency
	*/
	function getSettingDependency( deps, sets ) {
		if ( isObject( deps ) ) {
			if ( deps.query && notEmptyObejct( deps.query ) ) {
				$.each( deps.query, function( index, list ) {
					sets = getSettingDependency( list, sets );
				} );
			} else {
				$.each( deps, function( pid, attrs ) {
					if ( ! ( pid in sets ) ) {
						sets.push( pid );
					}
				} );
			}
		}
		return sets;
	}
	/**
	* Generate setting dependency
	* 	1. Generate the dependency object for wp.customize.setting.controls
	*	2. Get child controls and append to its parent
	*/
	function generateSettingDependency() {
		var settings = api.settings.settings, dependency = {},
			controls = $.extend( {}, api.settings.controls, api.alpaca.controls );
		$.each( controls, function( id, control ) {
			var setting = getControlSettingId( control );
			if ( setting && settings[ setting ] && settings[ setting ].dependency ) {
				var deps = getSettingDependency( settings[ setting ]['dependency'], [] );
				$.each( deps, function( index, pid ) {
					var element = { 'control': ( api.control( id ) || control ), 'dependency': settings[ setting ].dependency };
					if ( pid in dependency ) {
						dependency[pid].push( element );
					} else if ( api( pid ) ) {
						dependency[ pid ] = [ element ];
						api( pid ).bind( function( to ) {
							api.trigger( 'change.alpaca.customizer', pid );
						} );
					}
				} );
			}
		} );
		api.alpaca.dependency = dependency;
	}
	/**
	* Get customize setting value by id
	* @param string setting id
	* @return string setting value
	*/
	function getSettingValue( id ) {
		if ( id in api.settings.settings ) {
			var settings = api.get(),
				setting = settings[ id ];
			return ( setting === true ) ? 'on' : setting;
		}
	}
	/**
	 * @param {String} widgetId
	 * @returns {Object}
	 */
	function parseWidgetId( widgetId ) {
		var matches, parsed = {
			number: null,
			id_base: null
		};

		matches = widgetId.match( /^(.+)-(\d+)$/ );
		if ( matches ) {
			parsed.id_base = matches[1];
			parsed.number = parseInt( matches[2], 10 );
		} else {
			// likely an old single widget
			parsed.id_base = widgetId;
		}

		return parsed;
	}
	/**
	 * @param {String} widgetId
	 * @returns {String} settingId
	 */
	function widgetIdToSettingId( widgetId ) {
		var parsed = parseWidgetId( widgetId ), settingId;

		settingId = 'widget_' + parsed.id_base;
		if ( parsed.number ) {
			settingId += '[' + parsed.number + ']';
		}

		return settingId;
	}
	/**
	* Dependency process determination
	*/
	function processDependency( deps ) {
		if ( isObject( deps ) ) {
			if ( deps.query && notEmptyObejct( deps.query ) ) {
				var isRelationAnd = deps.relation && ( 'or' === deps.relation.toLowerCase() ) ? false : true;
				var passed = isRelationAnd, result = false;
				$.each( deps.query, function( i, list ) {
					result = processDependency( list );
					if ( isRelationAnd && ( ! result ) ) {
						passed = false;
						return false;
					} else if ( ( ! isRelationAnd ) && result ) {
						passed = true;
						return false;
					}
				} );
				return passed;
			} else {
				var passed = true;
				$.each( deps, function( pid, attr ) {
					var operator = attr.operator || 'in',  value = getSettingValue( pid );
					if ( ( ( operator === 'in' ) && ( attr.value.indexOf( value ) === -1 ) )
						|| ( ( operator !== 'in' ) && ( attr.value.indexOf( value ) !== -1 ) ) ) {
						passed = false;
						return false;
					}
				} );
				return passed;
			}
		} else {
			return true;
		}
	}
	/**
	* Post list metas check
	*/
	function processPostListMetas( id ) {
		var targetLayouts = [ 'layout-grid-overlay_column-2_', 'layout-grid-overlay_column-3_', 'layout-grid-overlay_column-4_' ],
			match = false;
		if ( id && ( match = id.match( /^alpaca_archive_page_(.+)_post_layout$/ ) ) ) {
			var $metas = $( '<div>' )
				.add( $( 'input[data-customize-setting-link="alpaca_archive_page_' + match[1] + '_show_excerpt"]' ) )
				.add( $( 'input[data-customize-setting-link="alpaca_archive_page_' + match[1] + '_show_read_more_button"]' ) )
				.not( 'div' );
			if ( $metas.length ) {
				targetLayouts.includes( api( id )() ) ? $metas.each( function() { $( this ).parent().hide() } ) : $metas.each( function() { $( this ).parent().show(); } );
			}
		}
	}
	/**
	* To deal with the event of setting changed
	*	This will decide to display the controls related or not
	*/
	api.bind( 'change.alpaca.customizer', function( id ) {
		if ( id in api.alpaca.dependency ) { // If current setting id is in the dependency list
			$.each( api.alpaca.dependency[ id ], function( index, item ) {
				var $control = item.control.container;    //, pass = true;
				// $.each( item.dependency, function( pid, attr ) { // Check if all dependency are passed
				// 	var operator = attr.operator || 'in',  value = getSettingValue( pid );
				//
				// 	if ( ( ( operator === 'in' ) && ( attr.value.indexOf( value ) === -1 ) )
				// 		|| ( ( operator === 'not in' ) && ( attr.value.indexOf( value ) !== -1 ) ) ) {
				// 		pass = false;
				// 		return false;
				// 	}
				// } );
				// Show control if passed
				processDependency( item.dependency ) ? $control.show() : $control.hide();
			} );
			processPostListMetas( id );
		}
	} );

	/**
	* Add new control constructor for slider type control
	*	which will enable jQuery ui to control
	**/
	api.controlConstructor.number_slider = api.Control.extend( {
		ready: function(){
			var elem = this.container.find('.loader-ui-slider'),
				input = this.container.find('input[data-customize-setting-link]');
			elem.slider( {
				'range': 	'min',
				'min': 		elem.data( 'min' ),
				'max': 		elem.data( 'max' ),
				'value': 	elem.data( 'value' ),
				'step': 	elem.data( 'step' ),
				'slide': 	function( event, ui ) {
					input.val( ui.value ).trigger( 'change' );
				}
			} );
		}
	} );

	/**
	* Register event handlers for customize control type number with unit
	*	To determine if current value excced the range set
	*/
	api.controlConstructor.number = api.controlConstructor.number_with_unit = api.Control.extend( {
		ready: function() {
			this.container.find( 'input[type=number]' ).on( 'change', function( e ) {
				var $self 	= $( this ),
					val 	= parseInt( $self.val(), 10 ),
					min		= $self.attr( 'min' ) ? parseInt( $self.attr( 'min' ), 10 ) : 1,
					max 	= $self.attr( 'max' ) ? parseInt( $self.attr( 'max' ), 10 ) : false;
				( ! val || ( val < min ) ) ? $self.val( min ).trigger( 'change' )
					: ( ( ( false !== max ) && ( val > max ) ) ? $self.val( max ).trigger( 'change' ) : '' );
			} );
		}
	} );

	/**
	* Register event handlers for customize control type image_id
	*	To open media lib, remove current image and features after image chosed
	*/
	api.controlConstructor.image_id = api.Control.extend( {
		ready: function() {
			var $container = $( this.container );
			$container.on( 'click', '.alpaca-customize-upload-image, .attachment-thumb', function( e ) {
				e.preventDefault();
				alpacaMedia.open( $( this ).parent().siblings( 'input[type=hidden]' ).first() );
			} )
			.on( 'click', '.alpaca-customize-remove-image', function( e ) {
				e.preventDefault();
				var $action = $( this ).parent();

				$( this ).addClass( 'hide' );
				$action.siblings( 'input[type=hidden]' ).first().val( '' ).trigger( 'change' );
				$action.siblings( '.placeholder' ).removeClass( 'hide' );
				$action.siblings( '.thumbnail-image' ).remove();
				$action.parent().removeClass( 'attachment-media-view-image' );
			} )
			.on( 'changed.alpaca.media', 'input[type=hidden]', function( e, image ) {
				e.preventDefault();
				if ( image && ( 'image' == image.type ) ) {
					var $container = $( this ).closest( '.attachment-media-view' ).addClass( 'attachment-media-view-image' ),
						targetObject = image.sizes ? ( image.sizes.medium ? image.sizes.medium : ( image.sizes.thumbnail ? image.sizes.thumbnail : image ) ) : image,
						$image = $( '<div>', { 'class': 'thumbnail thumbnail-image' } ).append( $( '<img>', { 'class': "attachment-thumb", 'src': targetObject.url } ).attr( 'width', targetObject.width ).attr( 'height', targetObject.height ) );

					$container.children( '.thumbnail-image' ).remove();
					$container.children( '.placeholder' ).addClass( 'hide' ).after( $image );
					$container.find( '.alpaca-customize-remove-image' ).removeClass( 'hide' );
					$( this ).val( image.id ).trigger( 'change' );
				}
			} );
		}
	} );

	/**
	* Register event hanlder for customize control type multiple_selection
	*	If the drop donw has option to select all and more than one options selected,
	*		remove the selection of all option.
	*/
	api.controlConstructor.multiple_selection = api.Control.extend( {
		ready: function(){
			var $select = $( this.container ).find( 'select[multiple]' );
			if ( $select.length && $select.children( '[value=""]' ).length ) {
				$select.on( 'change', function( e ) {
					var $options = $( this ).children();

					( $options.filter( ':selected' ).length > 1 ) ? $options.filter( '[value=""]' ).removeAttr( 'selected' ) : '';
				} );
				// Check current value after page initialized
				$select.trigger( 'change' );
			}
		}
	} );

	/**
	* Add new control constructor for mce_editor type control
	*	which will enable tinymce on it
	**/
	api.controlConstructor.mce_editor = api.Control.extend( {
		ready: function() {
			var control 	= this,
				id 			= control.id,
				in_ids 		= alpacaCustomizer && alpacaCustomizer.editor_ids && ( alpacaCustomizer.editor_ids.indexOf( id ) != -1 ),
				in_mceInit 	= tinyMCEPreInit && tinyMCEPreInit.mceInit && ( id in tinyMCEPreInit.mceInit ) && window.tinymce,
				in_qtInit 	= tinyMCEPreInit && tinyMCEPreInit.qtInit && ( id in tinyMCEPreInit.qtInit ) && quicktags;
			if ( in_ids && in_mceInit && in_qtInit ) {
				var $container = $( control.container );
				alpacaInitEditor( id, { 'mce': tinyMCEPreInit.mceInit[ id ], 'qt': tinyMCEPreInit.qtInit[ id ] }, $container );
				window.wpActiveEditor = id;
			}
		}
	} );

	/**
	* Add new control constructor for button type control
	*/
	api.controlConstructor.button = api.Control.extend( {
		ready: function( e ) {
			api.Control.prototype.ready.apply( this, arguments );
			var message = alpacaCustomizer.sync_message || {
					'sending'	: 'Data is syncing. Please wait. It can take a couple of minutes.',
					'done'		: 'Congratulations! Sync is completed.',
					'fail'		: 'Sorry but unable to sync. Please try again later.'
				},
				$container = $( this.container ),
				$notification = $container.find( '.customize-control-notifications-container' );
			$container.find( 'input[type=button]' ).on( 'click', function( e ) {
				e.preventDefault();
				var $self = $( this );
				$notification.css( 'display', 'none' );
				if ( $self.attr( 'action' ) && $self.attr( 'nonce') ) {
					$self.attr( 'disabled', 'disabled' );
					$notification.css( 'display', '' ).children().html( '<li>' + message.sending + '</li>' );
					wp.ajax.post( $self.attr( 'action'), { 'nonce': $self.attr( 'nonce' ) } )
						.done( function( response ) {
							$notification.css( 'display', '' ).children().html( '<li>' + message.done + '</li>' );
						} )
						.fail( function( response ) {
							$notification.css( 'display', '' ).children().html( '<li>' + message.fail + '</li>' );
						} )
						.always( function() {
							$self.removeAttr( 'disabled' );
						} );
				}
			} );
		}
	} );

	/**
	* Add new control type group
	*	1. add child controls when ready
	*/
	api.controlConstructor.group = api.Control.extend( {
		ready: function() {
			var control = this;
			if ( control.params.children ) {
				var $wrap = control.container.find( 'ul.group-controls-wrap' );
				$.each( control.params.children, function( cid, param ) {
					var Constructor = api.controlConstructor[ param.type ] || api.Control,
						Modified_Constructor = Constructor.extend( {
							embed: function() {
								var control = this, inject;
								inject = function( sectionId ) {
									var parentContainer;
									api.section( sectionId, function( section ) {
										// Wait for the section to be ready/initialized
										section.deferred.embedded.done( function() {
											$wrap.append( control.container );
											control.renderContent();
											control.deferred.embedded.resolve();
										} );
									} );
								};
								control.section.bind( inject) ;
								inject( control.section.get() );
							}
						} ),
						options = _.extend( { 'params': param }, param ),
						sub_controls = new Modified_Constructor( cid, options );
					api.alpaca.controls[ cid ] = $.extend( { 'container': sub_controls.container }, param );
				} );
			}
		}
	} );

	/**
	* For site layout
	*/
	api.alpaca.site_layout = api.Control.extend( {
		initialize: function(id, options){
			var control = this, settings;

			control.params = {};
			$.extend( control, options || {} );
			control.id = id;

			settings = $.map( control.params.settings, function( value ) {
				return value;
			} );

			if ( settings.length ) {
				api.apply( api, settings.concat( function() {
					var key;
					control.settings = {};
					for ( key in control.params.settings ) {
						control.settings[ key ] = api( control.params.settings[ key ] );
					}
					control.setting = control.settings['default'] || null;
				} ) );
			} else {
				control.setting = null;
				control.settings = {};
			}
			control.ready();
		},
		ready: function() {
			var control = this;
			if ( control.setting ) {
				control.setting.bind( function( value ) {
					control.settingChanged( value, control );
				} );
				control.settingChanged( control.setting(), control );
				api.trigger( 'change.alpaca.customizer', control.id );
			}
		},
		settingChanged: function( value, control ) {
			if ( value in alpacaCustomizer ) {
				$.each( alpacaCustomizer[ value ], function( id, title ) {
					control.updateControlTitle( id, title );
				});
			}
		},
		updateControlTitle: function( id, title ) {
			var c = api.control( id ), $container = c ? $( c.container ) : false;
			if ( $container && c.params.type ) {
				switch ( c.params.type ) {
					case 'title_only':
						$container.find( 'h3' ).text( title );
						break;
					case 'checkbox':
						var $label = $container.children( 'label' );
						$label.length ? $label.text( title ) : '';
						break;
					default:
						var $title = $container.find( '.customize-control-title' );
						$title.length ? $title.text( title ) : '';
				}
			}
		}
	} );

	/**
	* Register event handlers after wp.customize ready
	*/
	api.bind( 'ready', function( e ) {
		$( '#customize-control-header_image .customizer-section-intro' ).html( alpacaCustomizer.header_description );
		$( '#customize-control-header_image .current .customize-control-title' ).html( alpacaCustomizer.header_label );
		generateSettingDependency();
		if ( site_layout_id in api.settings.controls ) {
			new api.alpaca.site_layout( site_layout_id, {
				params: api.settings.controls[ site_layout_id ]
			} );
		}

		function checkPreviewerURL( target ) {
			var current = api.previewer.previewUrl();
			if ( ( typeof target != 'undefined' ) && target && ( current != target ) ) {
				api.previewer.previewUrl.set( target );
			}
		}

		$( 'body' ).on( 'click', 'a.show-control', function( e ) {
			e.preventDefault();
			var targetID = $( this ).data( 'control-id' );
			if ( targetID ) {
				api.previewer.trigger( 'focus-control-for-setting', targetID );
			}
		} )
		.on( 'click', 'a.show-panel, a.show-section', function( e ) {
			e.preventDefault();
			var targetID = $( this ).data( 'section-id' ), $currentOpen = $( '.control-section.open .customize-section-back' );
			if ( targetID && $( '#' + targetID ).length ) {
				$currentOpen.length ? $currentOpen.trigger( 'click' ) : '';
				$( '#' + targetID ).find( '.accordion-section-title' ).trigger( 'click' );
			}
		} )
		.on( 'click', 'a.redirect-preview-url', function( e ) {
			e.preventDefault();
			var param = $( this ).attr( 'href' );
			if ( $( this ).hasClass( 'static-home' ) ) {
				var home_id = api.get().page_for_posts ? api.get().page_for_posts : false;
				param = home_id ? '?page_id=' + home_id : '';
			}
			if ( param && ( param != '#' ) ) {
				checkPreviewerURL( api.settings.url.home + param );
			}
		} )
		.on( 'click', '#accordion-section-alpaca_section_404_page', function( e ) {
			checkPreviewerURL( alpacaCustomizer.errorURL );
		} )
		.on( 'click', '#sub-accordion-section-alpaca_section_404_page .customize-section-back', function( e ) {
			if ( api.previewer ) {
				checkPreviewerURL( alpacaCustomizer.homeURL );
			}
		} )
		.on( 'click', '#accordion-panel-alpaca_panel_homepage', function( e ) {
			checkPreviewerURL( alpacaCustomizer.homeURL );
		} )
		.on( 'click', '#accordion-section-alpaca_section_popup_signup_form', function( e ) {
			var $popupForm = $( '.popup-signup', api.previewer.targetWindow().document );
			$popupForm.length ? $popupForm.addClass( 'show' ) : '';
		} )
		.on( 'click', '#sub-accordion-section-alpaca_section_popup_signup_form .customize-section-back', function( e ) {
			if ( api.previewer ) {
				var $popupForm = $( '.popup-signup', api.previewer.targetWindow().document );
				$popupForm.length ? $popupForm.removeClass( 'show' ) : '';
			}
		} )
		.on( 'click', '#accordion-panel-alpaca_panel_fullscreen_menu', function( e ) {
			if ( api.previewer ) {
				var $menuToggle = $( '#menu-toggle', api.previewer.targetWindow().document ),
					$fullscreenMenu = $( '.alpaca-fullmenu', api.previewer.targetWindow().document );
				if ( $menuToggle.length && $fullscreenMenu.length && ( ! $fullscreenMenu.hasClass( 'show' ) ) ) {
					$menuToggle.trigger( 'click' );
				}
			}
		} )
		.on( 'click', '#sub-accordion-panel-alpaca_panel_fullscreen_menu .customize-panel-back', function( e ) {
			if ( api.previewer ) {
				var $menuToggle = $( '#menu-toggle', api.previewer.targetWindow().document ),
					$fullscreenMenu = $( '.alpaca-fullmenu', api.previewer.targetWindow().document );
				if ( $menuToggle.length && $fullscreenMenu.length && $fullscreenMenu.hasClass( 'show' ) ) {
					$menuToggle.trigger( 'click' );
				}
			}
		} );

		$( document ).on( 'keyup', function( e ) {
			if ( 27 === e.keyCode ) {
				var $popupForm = $( '.popup-signup', api.previewer.targetWindow().document );
				$popupForm.length ? $popupForm.removeClass( 'show' ) : '';
			}
		} );

		[
			'alpaca_archive_page_home_post_layout',
			'alpaca_archive_page_blog_post_layout',
			'alpaca_archive_page_category_post_layout',
			'alpaca_archive_page_tag_post_layout',
			'alpaca_archive_page_author_post_layout',
			'alpaca_archive_page_date_post_layout',
			'alpaca_archive_page_search_post_layout'
		].forEach( function( settingID ) {
			api( settingID ) ? processPostListMetas( settingID ) : '';
		} );
	} );
} ) (  wp.customize, jQuery);
