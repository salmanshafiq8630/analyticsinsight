( function( components, i18n, element, hooks ) {
	"use strict";
	const __ = i18n.__;
	const addFilter = hooks.addFilter;
	const el = element.createElement;
	const {
		SelectControl,
		TextControl,
		PanelBody
	} = components;

	function addPostMetas( metas, context ) {
		var newMetas = Object.assign( metas, {
			reading: function() {
				var currentTemplate = context.alpaca_post_content_counting_by;
				return el( PanelBody, {
						title: __( 'Reading Settings' ),
						initialOpen: false
					},
					el( SelectControl, {
						value: context.props.meta.alpaca_post_content_reading_setting,
						label: i18n.__( 'Reading Speed ( Per Minute )' ),
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_post_content_reading_setting: value } );
						},
						help: __( 'When choosing "Default", the settings from "Customize > General > Posts General Options > Reading Speed ( Per Minute )" will be used.' ),
						options: [
							{ value: '', 'label': __( 'Default' ) },
							{ value: 'custom', 'label': ( 'Custom' ) }
						]
					} ),
					( 'custom' == context.props.meta.alpaca_post_content_reading_setting ) && el( TextControl, {
						value: context.props.meta.alpaca_reading_speed_per_minute || 300,
						type: 'number',
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_reading_speed_per_minute: value } );
						}
					} ),
					( 'custom' == context.props.meta.alpaca_post_content_reading_setting ) && el( SelectControl, {
						value: context.props.meta.alpaca_reading_speed_unit || 'words',
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_reading_speed_unit: value } );
						},
						options: [
							{ value: 'words', 'label': __( 'Words' ) },
							{ value: 'characters', 'label': ( 'Characters' ) }
						]
					} )
				);
			},
			postTemplates: function() {
				var currentTemplate = context.alpaca_single_post_template_layout;
				return el( PanelBody, {
						title: __( 'Template & Layout' ),
						initialOpen: false
					},
					el( SelectControl, {
						value: context.props.meta.alpaca_single_post_template_layout,
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_single_post_template_layout: value } );
						},
						help: __( 'When choosing "Default", the settings from "Customize > Single Post > Post" will be used.' ),
						options: [
							{ value: '', 'label': __( 'Default' ) },
							{ value: 'post-template-split', 'label': __( 'Split Template' ) },
							{ value: 'post-template-wide-header-img_with-sidebar-right', 'label': __( 'Wide Header Image + Right Sidebar' ) },
							{ value: 'post-template-wide-header-img_with-sidebar-left', 'label': __( 'Wide Header Image + Left Sidebar' ) },
							{ value: 'post-template-wide-header-img', 'label': __( 'Wide Header Image + No Sidebar' ) },
							{ value: 'post-template-wide-overlay-header_with-sidebar-right', 'label': __( 'Overlay Header + Right Sidebar' ) },
							{ value: 'post-template-wide-overlay-header_with-sidebar-left', 'label': __( 'Overlay Header + Left Sidebar' ) },
							{ value: 'post-template-wide-overlay-header', 'label': __( 'Overlay Header + No Sidebar' ) },
							{ value: 'post-template-normal_with-sidebar-right', 'label': __( 'Normal Template + Right Sidebar' ) },
							{ value: 'post-template-normal_with-sidebar-left', 'label': __( 'Normal Template + Left Sidebar' ) },
							{ value: 'post-template-normal', 'label': __( 'Normal Template + No Sidebar' ) }
						]
					} )
				);
			}
		} );
		return newMetas;
	}
	addFilter(
		'loftocean.post.metas.filter',
		'loftocean/post-metas',
		addPostMetas
	);
} )(
	window.wp.components,
	window.wp.i18n,
	window.wp.element,
	window.wp.hooks
);
