( function( components, i18n, element, hooks ) {
	"use strict";
	const __ = i18n.__;
	const addFilter = hooks.addFilter;
	const el = element.createElement;
	const {
		ToggleControl,
		TextControl,
		TextareaControl,
		SelectControl,
		PanelBody
	} = components;

	function addPageMetas( metas, context ) {
		var newMetas = Object.assign( metas, {
			pageLayout: function() {
				return el( PanelBody, {
						className: 'loftocean-page-layout-options',
						title: __( 'Page Layout' ),
						initialOpen: false
					},
					el( SelectControl, {
						label: i18n.__( 'Page Layout' ),
						value: context.props.meta.alpaca_page_layout,
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_page_layout: value } );
						},
						options: [
							{ value: '', 'label': __( 'No sidebar' ) },
							{ value: 'fullwidth', 'label': __( 'Fullwidth' ) },
							{ value: 'with-sidebar-right', 'label': __( 'Right Sidebar' ) },
							{ value: 'with-sidebar-left', 'label': __( 'Left Sidebar' ) }
						]
					} )
				);
			},
			pageHeader:	function() {
				return el( PanelBody, {
						className: 'loftocean-page-header-options',
						title: __( 'Page Header' ),
						initialOpen: false
					},
					el( ToggleControl, {
						label: i18n.__( 'Hide page header' ),
						checked: ! ! context.props.meta.alpaca_hide_page_header,
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_hide_page_header: ( value ? 'on' : '' ) } );
						}
					} ),
					el( TextareaControl, {
						label: i18n.__( 'Sub Title' ),
						value: context.props.meta.alpaca_page_sub_title,
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_page_sub_title: value } );
						}
					} )
				);
			},
			hideAD:	function() {
				return el( PanelBody, {
						className: 'loftocean-page-ads-options',
						title: __( 'Hide AD' ),
						initialOpen: false
					},
					el( ToggleControl, {
						label: i18n.__( 'Hide advertisement before page content' ),
						checked: ! ! context.props.meta.alpaca_hide_before_page_content_ad,
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_hide_before_page_content_ad: ( value ? 'on' : '' ) } );
						}
					} ),
					el( ToggleControl, {
						label: i18n.__( 'Hide advertisement after page content' ),
						checked: ! ! context.props.meta.alpaca_hide_after_page_content_ad,
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_hide_after_page_content_ad: ( value ? 'on' : '' ) } );
						}
					} )
				);
			},
			advanced: function() {
				return el( PanelBody, {
						className: 'loftocean-advanced-options',
						title: __( 'Advanced' ),
						initialOpen: false
					},
					el( TextControl, {
						label: i18n.__( 'Additional CSS Class(es) to <body>' ),
						value: context.props.meta.alpaca_advanced_classname,
						help: i18n.__( 'Separate multiple classes with spaces.' ),
						onChange: ( value ) => {
							context.onSaveMeta( { alpaca_advanced_classname: value } );
						}
					} )
				);
			}
		} );
		return newMetas;
	}
	addFilter(
		'loftocean.page.metas.filter',
		'loftocean/page-metas',
		addPageMetas
	);
} )(
	window.wp.components,
	window.wp.i18n,
	window.wp.element,
	window.wp.hooks
);
