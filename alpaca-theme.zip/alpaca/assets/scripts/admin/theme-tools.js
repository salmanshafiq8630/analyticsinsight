( function( $ ) {
	"use strict";

    var url = alpacaThemeTools.apiRoot + 'loftocean/v1/clear-gutenberg-conflicts/';
	$( 'body' ).on( 'click', '.alpaca-panel-column.theme-tools .clear-gutenberg-issue', function( e ) {
        e.preventDefault();
        var $btn = $( this ), $notification = $btn.siblings( '.notification' );
        $btn.attr( 'disabled', 'disabled' );
        $notification.text( alpacaThemeTools.sendingRequest );
        $.get( url )
            .done( function( data, text, status ) { ( 200 == status.status ) && ( data && data.code && ( 200 == data.code ) ) ? $notification.text( alpacaThemeTools.done ) : $notification.text( alpacaThemeTools.failed ); } )
            .fail( function() { $notification.text( alpacaThemeTools.failed ); } )
            .always( function() { $btn.removeAttr( 'disabled' ); } );
    } );
} ) ( jQuery );
