( function( $ ) {
	$( document ).ready( function() {
        if ( $( '.alpaca-category-settings' ).length && alpacaCategory ) {
            $( '#alpaca_category_enable_individual_settings' ).on( 'change', function( e ) {
                if ( $( this ).is( ':checked' ) ) {
                    $( '.alpaca-category-settings .category-item-wrap' ).removeClass( 'hidden' );
                } else {
                    $( '.alpaca-category-settings .category-item-wrap' ).addClass( 'hidden' );
                }
            } ).trigger( 'change' );

            var prefix = '.category-item-wrap.item-';
            $.each( alpacaCategory, function( id, children ) {
                $( '#' + id ).on( 'change', function( e ) {
                    var val = $( this ).val();
                    $.each( children, function( cid, deps ) {
                        var passed = true;
                        $.each( deps, function( did, dval ) {
                            var val = $( '#' + did ).val();
                            if ( -1 === dval.indexOf( val ) ) {
                                passed = false;
                            }
                        } );
                        if ( passed ) {
                            $( prefix + cid ).css( 'display', '' );
                        } else {
                            $( prefix + cid ).css( 'display', 'none' );
                        }
                        $( '#' + cid ).trigger( 'change' );
                    } );
                } );
                $.each( children, function( cid, deps ) {
                    var passed = true;
                    $.each( deps, function( did, dval ) {
                        var val = $( '#' + did ).val();
                        if ( -1 === dval.indexOf( val ) ) {
                            passed = false;
                        }
                    } );
                    if ( passed ) {
                        $( prefix + cid ).css( 'display', '' );
                    } else {
                        $( prefix + cid ).css( 'display', 'none' );
                    }
                } );
            } );
        }
    } );
} ) ( jQuery );
