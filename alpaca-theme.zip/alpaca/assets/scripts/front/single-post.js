( function( $ ) {
	"use strict";
	var $win = $( window ), $doc = $( document ), $body = $( 'body' ), progressBarStyle = $body.hasClass( 'site-header-horizontal' ) || ( window.alpacaInnerWidth < 1024 ) ? 'scaleX' : 'scaleY',
		alpacaSinglePost = {};

	alpacaSinglePost = {
		'templateSplitSide': false,
		'templateSplitVideoBtn': false,
		'templateSplitVideoHeader': false,
		'contentWrap': false,
		'readingBar': false,
		'content': false,
		'socialBar': false,
		'stickySocialBarTimer': false,
		'init': function() {
			if ( $body.hasClass( 'single-post' ) ) {
				this.contentWrap = $( '.single-post-wrapper' );
				this.content = this.contentWrap.find( '.entry-content' );

				var self = this, scrollTop = alpacaParseInt( $win.scrollTop() ), list = [
					{ 'selector': '.sticky-share', 'cb': 'stickySocialBar', 'prop': 'socialBar' },
					{ 'selector': '.reading-progress', 'cb': 'readingBarProgress', 'prop': 'readingBar' },
					{ 'selector': 'body.post-template-split .article-side-section', 'cb': 'templateSplit', 'prop': 'templateSplitSide' }
				];
				$doc.on( 'resize.alpaca.window', function() {
					progressBarStyle = $body.hasClass( 'site-header-horizontal' ) || ( window.alpacaInnerWidth < 1024 ) ? 'scaleX' : 'scaleY';
				} );
				list.map( function ( item ) {
					if ( $( item[ 'selector' ] ).length ) {
						self[ item[ 'prop' ] ] = $( item[ 'selector' ] );
						self[ item[ 'cb' ] ] = self[ item[ 'cb' ] ].bind( self );
						$win.on( 'load', function() {
							self[ item[ 'cb' ] ]( alpacaParseInt( $win.scrollTop() ) );
						} );
						$doc.on( 'resize.alpaca.window scrolling.alpaca.window', function() {
							self[ item[ 'cb' ] ]( alpacaParseInt( $win.scrollTop() ) );
						} );
						self[ item[ 'cb' ] ]( scrollTop );
					}
				} );

				this.processPostHeaderSlider();
			}
			this.processTemplateSplit( scrollTop );
		},
		'stickySocialBar': function( top ) {
            var self = this, entryHeight = this.content.outerHeight( true ), entryTop = this.content.offset().top;
			if ( ( top >= ( entryTop - window.alpacaInnerHeight / 2 ) ) && ( top <= ( entryHeight + entryTop - window.alpacaInnerHeight ) ) ) {
				this.socialBar.removeClass( 'hide-it' ).addClass( 'show-it' );
				this.stickySocialBarTimer ? clearTimeout( this.stickySocialBarTimer ) : '';
				this.stickySocialBarTimer = setTimeout( function() {
					if ( self.socialBar.hasClass( 'show-it' ) ) {
						self.socialBar.addClass( 'minimize' );
					}
					self.stickySocialBarTimer = false;
				}, 3000 );
			} else {
				this.socialBar.removeClass( 'show-it' ).addClass( 'hide-it' );
			}
		},
		'readingBarProgress': function( top ) {
			var contentTop = Math.max( 0, ( this.content.offset().top - window.alpacaInnerHeight ) );
			if ( top > contentTop ) {
				var contentHeight = this.content.outerHeight( true ), maxTop = this.content.offset().top + contentHeight - window.alpacaInnerHeight ;
				if ( maxTop > 0 ) {
					var currentPercentage = top <= maxTop ? ( ( top - contentTop ) / contentHeight ) : 1;
					this.readingBar.css( { 'transform': progressBarStyle + '(' + currentPercentage + ')' } );
				} else {
					this.readingBar.css( { 'transform': '' } );
				}
			} else {
				this.readingBar.css( { 'transform': progressBarStyle + '(0)' } );
			}
		},
		'templateSplit': function( top ) {
			if ( top > ( alpacaParseInt( this.contentWrap.outerHeight( true  ) ) + alpacaParseInt( this.contentWrap.offset().top ) - window.alpacaInnerHeight ) ) {
				this.templateSplitSide.hasClass( 'reach-bottom' ) ? '' : this.templateSplitSide.removeClass( 'is-sticky' ).addClass( 'reach-bottom' );
			} else if ( ( top > 0 ) && ! this.templateSplitSide.hasClass( 'is-sticky' ) ) {
				this.templateSplitSide.hasClass( 'is-sticky' ) ? '' : this.templateSplitSide.addClass( 'is-sticky' ).removeClass( 'reach-bottom' );
            }
        },
        processTemplateSplit: function( top ) {
            this.templateSplitVideoBtn = $( 'body.post-template-split .featured-video-play-btn' );
	        if ( this.templateSplitVideoBtn.length ) {
	        	var self = this, callback = this.templateSplitVideoCallback.bind( self );
	        	this.templateSplitVideoHeader = $( '.post-template-split .entry-header' );
	        	callback( top, false );
	        	$doc.on( 'scrolling.alpaca.window', function( e, args ) {
	        		args ? callback( args['top'], args['goUp'] ) : '';
	        	} )
	        	.on( 'resize.alpaca.window', function( e, args ) {
	        		if ( args ) {
	        			self.templateSplitVideoBtn.data( 'slideUp', false ).data( 'positionChange', false );
	        			callback( args['top'], true );
	        		}
	        	} );
	        }
	    },
	    'templateSplitVideoCallback': function( top, goUp ) {
			var minTop = window.alpacaInnerWidth >= 1120 ? 300 : ( window.alpacaInnerWidth >= 1024 ? 200 : 0 ), self = this;
			if ( minTop ) {
				if ( top > minTop ) {
					if ( ! self.templateSplitVideoBtn.data( 'positionChange' ) ) {
						self.templateSplitVideoBtn.data( 'positionChange', true ).removeClass( 'slide-up' ).data( 'slideUp', false );
						self.templateSplitVideoBtn.data( 'slideUpTimer' ) ? clearTimeout( self.templateSplitVideoBtn.data( 'slideUpTimer' ) ) : '';
						self.templateSplitVideoBtn.data( 'positionChangeTimer', setTimeout( function() {
							if ( self.templateSplitVideoHeader.hasClass( 'fade-text' ) ) {
								self.templateSplitVideoBtn
									.addClass( 'position-change reslide' );
							}
						}, 1000 ) );
					}
				} else {
					if ( ! self.templateSplitVideoBtn.data( 'slideUp' ) && ( goUp ) ) {
						self.templateSplitVideoBtn.data( 'slideUp', true ).data( 'positionChange', false );
						self.templateSplitVideoBtn.data( 'positionChangeTimer' ) ? clearTimeout( self.templateSplitVideoBtn.data( 'positionChangeTimer' ) ) : '';
						self.templateSplitVideoBtn.data( 'slideUpTimer', setTimeout( function() {
							if ( ! self.templateSplitVideoHeader.hasClass( 'fade-text' ) ) {
								self.templateSplitVideoBtn.removeClass( 'position-change' );

								if ( self.templateSplitVideoBtn.hasClass( 'reslide' ) ) {
									self.templateSplitVideoBtn.addClass( 'slide-up' );
								}
							}
						}, 100 ) );
					}
				}
			} else {
				self.templateSplitVideoBtn
					.data( 'positionChange', true ).data( 'slideUp', false )
					.addClass( 'slide-up' ).removeClass( 'position-change' );
				self.templateSplitVideoBtn.data( 'slideUpTimer' ) ? clearTimeout( self.templateSplitVideoBtn.data( 'slideUpTimer' ) ) : '';
				self.templateSplitVideoBtn.data( 'positionChangeTimer' ) ? clearTimeout( self.templateSplitVideoBtn.data( 'positionChangeTimer' ) ) : '';
			}
		},
		'processPostHeaderSlider': function() {
			var $slider = $( '.single-format-gallery .featured-img-container .image-gallery' );
			if ( $slider.length ) {
				$slider.alpacaSlickSlider( $slider.hasClass( 'multi-img-gallery' ) ? {
						dots: false,
						infinite: true,
						speed: 500,
						slidesToShow: 1,
						centerMode: true,
						autoplay: true,
						autoplaySpeed: 5000,
						arrows: true,
						variableWidth: true
					} : {
						dots: false,
						infinite: true,
						speed: 500,
						fade: true,
						cssEase: 'linear',
						autoplay: true,
						autoplaySpeed: 5000,
						arrows: true,
						swipeToSlide: true
					}
				);
			}
		}
	};

	$doc.on( 'alapca.init', function() {
		alpacaSinglePost.init();
	} );
} ) ( jQuery );
