( function ( $ ) {
	"user strict";
	/**
	* Callback function to show navigation if needed
	*/
	function alpacaAjaxNav( data, $nav ) {
		if ( data && data.more ) {
			alpacaAjaxLoadMore.data.query.paged ++;
		} else {
			if ( $nav.hasClass( 'infinite' ) ) {
				$nav.find( '.load-more-btn.ajax' ).remove();
				$nav.removeClass( 'infinite' ).append( $( '<span>', { 'class': 'no-more-posts-message', 'text': alpacaAjaxLoadMore.noMoreText } ) );
			} else {
				$nav.find( '.load-more-btn.ajax.manual' ).remove();
				$nav.append( $( '<span>', { 'class': 'no-more-posts-message', 'text': alpacaAjaxLoadMore.noMoreText } ) );
			}
		}
		$nav.data( 'loading', false ).removeClass( 'loading' );
	}
	if ( alpacaAjaxLoadMore ) {
		var $doc = $( document );
		$doc.on( 'alpacaAjaxLoadMoreProcessData', function( e, args ) {
			var $nav = args['target'].closest( '.navigation.pagination' ), $list = $nav.siblings( '.posts-wrapper' ).parent();
			if ( $list.length && $list.hasClass( 'posts' ) && $( args['data']['items'] ).length ) {
				var $wrap = false, $posts = $( '<div>' ).append( args['data']['items'] ), $gallery = $posts.find( '.image-gallery' ), hasGallery = $gallery.length, hasPreloader = $.fn.loftoceanImageLoading;
				$posts.children().addClass( 'new-post-item post' );

				if ( $list.hasClass( 'layout-masonry' ) ) {
					var list = $list.data( 'post-list' ) ? $list.data( 'post-list' ) : [],
						$columns = $list.find( '.masonry-column' );
					$posts.children().each( function() {
						list.unshift( $( this ) );
					} );
					$list.data( 'post-list', list );
					if ( $list.data( 'mobile-mode' ) ) { // If in mobile mode, just append the posts
						$columns.first().append( $posts.children() );
						$( document ).trigger( 'loftcean/moreContent/loaded' );
						$list.find( '.new-post-item' ).removeClass( 'new-post-item' );
						alpacaAjaxNav( args['data'], args['target'] );
						if ( hasPreloader ) {
							$list.loftoceanImageLoading();
						}
					} else { // Recalculate the height
						$columns.first().append( $posts.children() );
						$list.alpacaMasonry( { 'post': '.post.new-post-item', 'append': true } );
						hasGallery ? $gallery.alpacaPostsGallery() : '';
						$( document ).trigger( 'loftcean/moreContent/loaded' );
						$list.find( '.new-post-item' ).removeClass( 'new-post-item' );
						alpacaAjaxNav( args['data'], args['target'] );
						if ( hasPreloader ) {
			 				$list.loftoceanImageLoading();
			 			}
					}
				} else {
					$wrap = $list.find( '.posts-wrapper' );
					$wrap.append( $posts.children() );
	 				$( document ).trigger( 'loftcean/moreContent/loaded', { 'videos': ( args['data']['videos'] && Array.isArray( args['data']['videos'] ) ? args['data']['videos'] : false ) } );
					$list.find( '.new-post-item' ).removeClass( 'new-post-item' );
					hasGallery ? $gallery.alpacaPostsGallery() : '';
 					$( document ).trigger( 'changed.alpaca.mainContent' );
					alpacaAjaxNav( args['data'], args['target'] );
	 				if ( hasPreloader ) {
		 				$list.loftoceanImageLoading();
		 			}
	 			}
	 		}
		} );
		$( 'body' ).on( 'alpacaAjaxLoadMoreStart', '.pagination-container.load-more', function( e ) {
			e.preventDefault();
			var $nav = $( this );
			if ( $nav.data( 'loading' ) ) return false;

			$nav.data( 'loading', true ).addClass( 'loading' );
			var data = alpacaAjaxLoadMore.data;
			$.post( alpacaAjaxLoadMore.url, data ).done( function( response ) {
				if ( response.success ) {
					$( document ).trigger( 'alpacaAjaxLoadMoreProcessData', { 'data': response.data, 'target': $nav } );
				} else {
					$nav.data( 'loading', false ).removeClass( 'loading' );
				}
			} ).fail( function() {
				$nav.data( 'loading', false ).removeClass( 'loading' );
			} );
		} ).on( 'click', '.load-more-btn.ajax.manual', function( e ) {
			e.preventDefault();
			$( this ).closest( '.pagination-container.load-more' ).trigger( 'alpacaAjaxLoadMoreStart' );
		} );

		$doc.data( 'previousTop', alpacaParseInt( $( window ).scrollTop() ) );
		$doc.on( 'scrolling.alpaca.window', function( e ) {
			var $doc = $( this ), currentTop = alpacaParseInt( $( window ).scrollTop() ),
				$autLoadMore = $( '.pagination-container.load-more.infinite' );
			if ( $autLoadMore.length && $doc.data( 'previousTop' ) && ( $doc.data( 'previousTop' ) < currentTop ) ) {
				var currentBottom = alpacaParseInt( currentTop ) + alpacaParseInt( $( window ).height() );
				$autLoadMore.each( function() {
					var navTop = $( this ).closest( '.navigation.pagination' ).offset().top;
					if ( ( navTop > currentTop ) &&  ( navTop < currentBottom ) ) {
						$( this ).trigger( 'alpacaAjaxLoadMoreStart' );
						return false;
					}
				} );
			}
			$doc.data( 'previousTop', currentTop );
		} );
	}
} ) ( jQuery );
