( function( $ ) {
	"use strict";
	var $doc = $( document ), $win = $( window ), $body = $( 'body' ), $html = $( 'html' ), $page = $( '#page' ), $siteHeader = $( '.site-header' ), $siteHeaderMain = $siteHeader.find( '.site-header-main' ),
		$readingBar = $( '.reading-progress' ), $headerMore = $( '.site-header-vertical .header-section-more' ), $headerCart = $( '.site-header-vertical #site-header-cart' ),
		$adminBar = $( '#wpadminbar' ), $cartContent = $( '#site-header-cart .cart-contents' ), $fullmenu = $( '.alpaca-fullmenu' ), $searchScreen = $( '.search-screen' ),
		$topBtn = $( '.top-btn' ), isRTL = window.alpacaIsRTL, topOffset = alpacaParseInt( $body.offset().top );

	alpaca = alpaca || {};
	alpaca.pages = alpaca.pages || {};

	/**
	* For all pages features
	*	1. Scroll to top button
	* 	2. Sticky sidebar
	* 	3. Sticky page header
	* 	4. Fallback css generate
	*/
	alpaca.pages.all = {
		'loaded': false,
		'init': function(){
			var site = this, scrollTop = alpacaParseInt( $win.scrollTop() );
			this.fixPrimaryMenu();

			site.maybeStickySiteHeader( scrollTop, false );
			$topBtn.length ? this.scrollToTopButton( scrollTop, false ) : '';
			$( 'ins.adsbygoogle' ).length && $( '[data-enable-sticky-sidebar=on]' ).length ? $body.fixGoogleAdsenseInlineStyles() : '';

			$win.on( 'load', function() {
				site.fixRollingText();
				site.load( $win.scrollTop() );
			} );
			$doc.on( 'scrolling.alpaca.window', function( e, args ) {
				args ? site.scroll( args['top'], args['goUp'] ) : '';
			} )
			.on( 'resize.alpaca.window', function( e, args ) {
				site.fixRollingText();
				if ( $siteHeader.length && args ) {
					$siteHeader.removeAttr( 'data-threhold' );
					site.scroll( args['top'], args['goUp'] );
				}
			} );
		},
		'load': function( top ) {
			this.loaded = true;
			if ( top > 0 ) {
				this.windowEventCallback( alpacaParseInt( top ), false );
			}
		},
		'scroll': function( top, goUp ) {
			top = alpacaParseInt( top );
			this.loaded ? this.windowEventCallback( top, goUp ) : '';
			$topBtn.length ? this.scrollToTopButton( top, goUp ) : '';
		},
		'windowEventCallback': function( top, goUp ) {
			this.maybeStickySiteHeader( top, goUp );
		},
		'scrollToTopButton': function( top, goUp ) {
			var shortBtnTop = $( document ).height() - window.alpacaInnerHeight - $( '.site-footer' ).height() - 50;
			top > 150 ? $topBtn.addClass( 'show' ) : $topBtn.removeClass( 'show' );
			if ( ! $topBtn.hasClass( 'reach-to-bottom' ) && ( top > shortBtnTop ) ) {
				$topBtn.addClass( 'reach-to-bottom' );
			} else if ( $topBtn.hasClass( 'reach-to-bottom' ) && ( top < shortBtnTop ) ) {
				$topBtn.removeClass( 'reach-to-bottom' );
			}
		},
		'maybeStickySiteHeader': function( top, goUp ) {
			var isHorizontalHeader = $body.hasClass( 'site-header-horizontal' ), $tops, testTop,
				headerHeight = alpacaParseInt( $siteHeaderMain.outerHeight( true ) ),
				minTop = $adminBar.length ? $adminBar.outerHeight( true ) : 0;
			// Show & Hide the Header More Section toggle button & Header Mini Cart
			if ( $headerMore.length || $headerCart.length ) {
				$tops = $( '.top-corner' );
				testTop = minTop + $tops.first().outerHeight( true );
				if ( ( top > testTop ) && ( window.alpacaInnerWidth > 1023 ) ) {
					$tops.addClass( 'is-sticky' );
					if ( goUp ) {
						$tops.addClass( 'show-it' ).removeClass( 'hide-it' );
					} else if ( $tops.hasClass( 'show-it' ) ) {
						$tops.removeClass( 'show-it' ).addClass( 'hide-it' );
					}
				} else {
					$tops.addClass( 'is-sticky show-it' );
				}
			}

			if ( ( isHorizontalHeader || ( window.alpacaInnerWidth < 1024 ) ) && ( ( window.alpacaInnerHeight + headerHeight * 2 ) < $doc.outerHeight( true ) ) ) {
				testTop = minTop + headerHeight;
				if ( top > testTop ) {
					$siteHeader.addClass( 'is-sticky' );
					$body.css( 'padding-top', headerHeight );
					if ( goUp ) {
						$siteHeader.addClass( 'show-header' ).removeClass( 'hide-header' );
					} else if ( $siteHeader.hasClass( 'show-header' ) ) {
						$siteHeader.removeClass( 'show-header' ).addClass( 'hide-header' );
					}
				} else {
					if ( ( top > 0 ) && goUp ) {
						$siteHeader.removeClass( 'hide-header' );
					} else {
						$siteHeader.removeClass( 'is-sticky hide-header show-header' );
						$body.css( 'padding-top', '' );
					}
				}
			} else if ( $siteHeader.hasClass( 'is-sticky' ) ) {
				$siteHeader.removeClass( 'is-sticky hide-header show-header' );
				$body.css( 'padding-top', '' );
			}
		},
		'fixPrimaryMenu': function() {
			var $primaryMenus = $( '#masthead #horizontal-site-header-main-menu > li' );
			if ( $primaryMenus.length ) {
				if ( $primaryMenus.filter( '.mega-menu' ).length ) {
					alpacaAdjustMegaMenu();
					$win.on( 'resize.alpaca.window', function() {
						alpacaAdjustMegaMenu();
					} );
				}
				if ( $primaryMenus.filter( '.menu-item-has-children' ).not( '.mega-menu' ).length ) {
					var boundary = alpacaParseInt( window.alpacaInnerWidth - 10 );
					$primaryMenus.filter( '.menu-item-has-children' ).not( '.mega-menu' ).on( 'mouseover', function( e ) {
						if ( ! $( this ).hasClass( 'right' ) ) {
							var $self = $( this );
							$self.find( 'ul.sub-menu' ).each( function() {
								if ( isRTL && ( $( this ).offset().left < alpacaParseInt( $( '#page' ).offset().left + 10 ) ) ) {
									$self.addClass( 'right' );
									return false;
								} else if ( ! isRTL && ( alpacaParseInt( $( this ).offset().left + $( this ).outerWidth( true ) ) > boundary ) ) {
									$self.addClass( 'right' );
									return false;
								}
							} );
						}
					} );
					$win.on( 'resize.alpaca.window', function() {
						boundary = alpacaParseInt( window.alpacaInnerWidth - 10 );
						$primaryMenus.filter( '.menu-item-has-children' ).removeClass( 'right' );
					} );
				}
			}
			$( '#masthead .sub-menu' ).length ? $( '#masthead .sub-menu' ).removeClass( 'hide' ) : '';
		},
		'fixRollingText': function() {
			var $rollingText = $( '.marquee span' );
			if ( $rollingText.length ) {
				$rollingText.each( function() {
					var $parent = $( this ).parent(), classes = $parent.attr( 'class' );
					$parent.attr( 'class', '' ).css( 'width', alpacaParseInt( $( this ).outerWidth( true ) ) ).attr( 'class', classes );
				} );
			}
		}
	};
	/**
	*
	*/
	function alpacaAdjustMegaMenu() {
		$( '#masthead #horizontal-site-header-main-menu .mega-menu' ).each( function() {
			if ( isRTL ) {
				$( this ).children( 'ul' ).css( 'right', - ( window.alpacaInnerWidth - $( this ).offset().left - $( this ).outerWidth( true ) ) );
			} else {
				$( this ).children( 'ul' ).css( 'left', - $( this ).offset().left );
			}
		} );
	}
	/**
	* Slick slider arrow style on mobile
	*/
	function alpacaMobileSliderArrowStyle( $slider, $arrows ) {
		if ( $slider.hasClass( 'image-gallery' ) && $arrows && $arrows.length && alpaca.mobile_slider_arrow_style ) {
			$arrows.addClass( alpaca.mobile_slider_arrow_style );
		}
	}

	$doc.on( 'alapca.init', function() {
		alpaca.pages.all.init();
	} );

	/** Let render the page */
	document.addEventListener( 'DOMContentLoaded', function() {
		var $contentImages = $( '.comment-content img, .post-entry img' ), $colorSwitcher = $( '.reading-mode-switch' ), isCustomizePreview = wp && wp.customize,
			signalClass = '', colorSchemeSwitcherSessionName = alpaca.colorSchemeSwitcherSessionName ? alpaca.colorSchemeSwitcherSessionName : 'alpacaReverseColorScheme';

		$doc.trigger( 'alapca.init' );

		// Fit videos if any
		if ( $( 'body.page #primary iframe, body.single #primary iframe' ).length ) {
			var $primary = $( 'body.page #primary, body.single #primary' ), sources = [
				'iframe[data-src*="videopress.com"]',
				'iframe[data-src*="video.wordpress.com"]',
				'iframe[data-src*="player.vimeo.com"]',
				'iframe[data-src*="youtube.com"]',
		        'iframe[data-src*="youtube-nocookie.com"]',
		        'iframe[data-src*="kickstarter.com"][src*="video.html"]',
			];
			$primary.fitVids( { 'customSelector': 'iframe[src*="video.wordpress.com"]' } );
			if ( $primary.find( sources.join( ',' ) ).length ) {
				$primary.find( sources.join( ',' ) ).each( function() {
					var $video = $( this ), width = alpacaParseInt( $video.attr( 'width' ) ), height = alpacaParseInt( $video.attr( 'height' ) );
					if ( ! $( this ).parents( '.fluid-width-video-wrapper' ).length && width && height ) {
						$video.attr( 'src', $video.data( 'src' ) )
							.wrap( $( '<div>', { class: 'fluid-width-video-wrapper' } ).css( 'padding-top', ( ( height / width ) * 100 ) + '%' ) )
				        	.removeAttr( 'height' ).removeAttr( 'width' );
					}
				} );
			}
		}

		// Initilize settings for color scheme switcher
		if ( $colorSwitcher.length ) {
			signalClass = $html.hasClass( 'original-light-color' ) ? 'change-to-color-scheme-dark' : 'change-to-color-scheme-light';
		}

		$win.on( 'load', function() {
			if ( window.location.hash && ( '#comments' == window.location.hash ) && $( '#comments' ).length ) {
				var top = $( '#comments' ).offset().top - topOffset;
				$( 'html, body' ).animate( { scrollTop: top }, 200 );
			}
		} );

		$doc.on( 'ajaxSuccess', function( e, xhr, settings ) {
			var url = settings.url;
			if ( url.includes( 'wc-ajax=remove_from_cart' ) || url.includes( 'wc-ajax=add_to_cart' ) ) {
				if ( xhr.responseJSON && xhr.responseJSON.cart_hash ) {
					$cartContent.find( '.cart-notification' ).length ? '' : $cartContent.append( $( '<span>', { 'class': 'cart-notification' } ) );
				} else {
					$cartContent.find( '.cart-notification' ).length ? $cartContent.find( '.cart-notification' ).remove() : '';
				}
			}
		} )
		.on( 'click', '.top-btn.show', function( e ) {
			e.preventDefault();
			$( 'html, body' ).animate( { scrollTop: 0 }, Math.min( 800, Math.max( 300, Math.round( $win.scrollTop() / 5 ) ) ) );
		} )
		.on( 'click', '.site-header #menu-toggle', function( e ) {
			e.preventDefault();
			if ( $fullmenu.length ) {
				$( this ).toggleClass( 'toggled-on' );
				if ( $( this ).hasClass( 'toggled-on' ) ) {
					$fullmenu.addClass( 'show' );
					$body.css( 'overflow', 'hidden' );
					$readingBar.length ? $readingBar.css( 'opacity', 0 ) : '';
				} else {
					$fullmenu.removeClass( 'show' );
					$body.css( 'overflow', '' );
					$readingBar.length ? $readingBar.css( 'opacity','' ) : '';
				}
			}
		} )
		.on( 'click', '.alpaca-fullmenu.show .close-button', function( e ) {
			e.preventDefault();
			$( '.site-header #menu-toggle' ).removeClass( 'toggled-on' );
			$fullmenu.removeClass( 'show' );
			$body.css( 'overflow', '' );
			$readingBar.length ? $readingBar.css( 'opacity', '' ) : '';
		} )
		.on( 'click', '.top-corner .more-toggle', function( e ) {
			e.preventDefault();
			var $headerMore = $( '.top-corner .header-section-more' );
			if ( $headerMore.length ) {
				$headerMore.hasClass( 'folded' ) ? $headerMore.removeClass( 'folded' ).addClass( 'expanded' ) : $headerMore.removeClass( 'expanded' ).addClass( 'folded' );
			}
		} )
		.on( 'mouseover', '#masthead #horizontal-site-header-main-menu .mega-menu .sub-cat-list li', function(  ) {
			if ( ! $( this ).hasClass( 'current' ) ) {
				var $posts = $( this ).parents( '.sub-cat-list' ).first().siblings( '.sub-cat-posts' ).first();
				$( this ).siblings( '.current' ).removeClass( 'current' ).end().addClass( 'current' );
				$posts.children( '.current' ).removeClass( 'current' );
				$posts.children( '.' + $( this ).attr( 'data-id' ) ).addClass( 'current' );
			}
		} )
		.on( 'click', '.main-navigation .dropdown-toggle', function( e ) {
			e.preventDefault();
			if ( $( this ).hasClass( 'toggled-on' ) ) {
				$( this ).parent().find( '.toggled-on' ).removeClass( 'toggled-on' );
			} else {
				$( this ).parent().siblings( 'li' ).find( '.toggled-on' ).removeClass( 'toggled-on' );
				$( this ).addClass( 'toggled-on' );
			}
		} )
		.on( 'click', '.reading-mode-switch', function( e ) {
			e.preventDefault();

			if ( $html.hasClass( signalClass ) ) {
				$html.removeClass( signalClass );
				isCustomizePreview ? '' : alpacaLocalStorage.setItem( colorSchemeSwitcherSessionName, '' );
			} else {
				$html.addClass( signalClass );
				isCustomizePreview ? '' : alpacaLocalStorage.setItem( colorSchemeSwitcherSessionName, 'on' );
			}
		} )
		.on( 'click', '.header-more-btn.popup-signup-btn', function( e ) {
			e.preventDefault();
			if ( $( '.popup-signup' ).length ) {
				$( '.popup-signup' ).addClass( 'show' );
			}
		} )
		.on( 'click', '.popup-search-btn', function( e ) {
			e.preventDefault();
			if ( $searchScreen.length ) {
				if ( ! $searchScreen.hasClass( 'show' ) ){
					$searchScreen.addClass( 'show' );
					setTimeout( function() {
						$searchScreen.find( 'form .search-field' ).focus();
					}, 250 );
					$body.css( 'overflow', 'hidden' );
				}
			}
		} )
		.on( 'click', '.search-screen.show .close-button', function( e ) {
			e.preventDefault();
			$searchScreen.removeClass( 'show' );
			$body.css( 'overflow', '' );
		} )
		.on( 'click', '.single #primary .post-footer .comments-link a', function( e ) {
			e.preventDefault();
			var $comments = $( '#comments' );
			if ( $comments.length ) {
				var top = $comments.offset().top - topOffset;
				$( 'html, body' ).animate( { scrollTop: top }, 200 );
			}
		} )
		.on( 'click', function( e ) {
			var $focused = $( '#masthead .menu-item.focused' );
			if ( $focused.length ) {
				$focused.removeClass( 'focused' );
			}
		} )
		.on( 'keyup', function( e ) {
			var code = e.keyCode || e.which;
			if ( code === 9 ) {
				var $current = $( e.target ), $all = $( '#masthead .menu-item' ),
					isCurrentMenuItem = $current.hasClass( 'menu-item' ) || $current.parents( '.menu-item' ).length;
				if ( isCurrentMenuItem ) {
					var $item = $current.parents( '.menu-item' ).length ? $current.parents( '.menu-item' ).last() : $current;
					$all.removeClass( 'focused' );
					$item.addClass( 'focused' );
				} else {
					$all.removeClass( 'focused' );
				}
			}
		} );

		// Add extra class to image wrapper link
		if ( $contentImages.length ) {
			$contentImages.each( function() {
				if ( $( this ).parent( 'a' ).length ) {
					$( this ).parent( 'a' ).addClass( 'image-link' );
				}
			} );
		}
		// Gustified galleries
		$( '.post-content-gallery.gallery-justified' ).alpacaJustifiedGallery();
	} );
} ) ( jQuery );
