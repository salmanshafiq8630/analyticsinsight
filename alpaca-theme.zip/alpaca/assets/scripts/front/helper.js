( function( $ ) {
	"use strict";
	var tagA = document.createElement( 'a' ), cookieRootPath = '', $doc = $( document ), $win = $( window );

	tagA.href = alpacaHelper && alpacaHelper.siteURL ? alpacaHelper.siteURL : '';
	cookieRootPath = tagA.pathname;

	window.alpacaIsRTL = $( 'body' ).hasClass( 'rtl' );
	window.alpacaParseInt = function ( val ) {
		return val ? parseInt( val, 10 ) : 0;
	}
	function alpacaSetWindowProps( e ) {
		var top = alpacaParseInt( $win.scrollTop() ), goUp = top < $win.previousTop;
		$win.previousTop = top;
		return { 'top': top, 'goUp': goUp, 'originalEvent': e };
	}
	$win.previousTop = alpacaParseInt( $win.scrollTop() );
	window.alpacaInnerHeight = alpacaParseInt( $win.innerHeight() );
	window.alpacaInnerWidth = alpacaParseInt( $win.innerWidth() );
	document.addEventListener( 'DOMContentLoaded', function() {
		$win.on( 'resize', function( e ) {
			$doc.trigger( 'resize.alpaca.window', alpacaSetWindowProps( e ) );
			window.alpacaInnerHeight = alpacaParseInt( $win.innerHeight() );
			window.alpacaInnerWidth = alpacaParseInt( $win.innerWidth() );
		} )
		.on( 'scroll', function( e ) {
			$doc.trigger( 'scrolling.alpaca.window', alpacaSetWindowProps( e ) );
		} );
	} );

	$.fn.alpacaJustifiedGallery = function() {
		if ( ! $( this ).length ) return;
		return $( this ).each( function() {
			var $gallery = $( this );
			$gallery.children( '.image-gallery' ).justifiedGallery( {
				'rtl': alpacaIsRTL,
				'rowHeight': $gallery.data( 'row-height' ),
				'lastRow': $gallery.data( 'last-row' ),
				'margins': $gallery.data( 'margin' ),
				'captions': false
			} ).on( 'jg.complete', function( e ) {
				$gallery.addClass( 'justified-gallery-initialized' );
				$( document ).trigger( 'changed.alpaca.mainContent' );
			} );
		} );
	}

	$.fn.alpacaSlickSlider = function( args ) {
		if ( ! $( this ).length ) return;

		args.rtl = alpacaIsRTL;

		return $( this ).each( function() {
			$( this ).on( 'init', function( e ) {
				$( this ).find( '.gallery-item' ).removeClass( 'hide' );
				$.fn.loftoceanImageLoading ? $( this ).loftoceanImageLoading() : '';
			} ).slick( args );
		} );
	}

	window.alpacaCookie = {
		set: function( name, value, days ) {
			try {
			   	var expires = "";
				if ( days ) {
				   var date = new Date();
				   date.setTime( date.getTime() + ( days * 24 * 60 * 60 * 1000 ) );
				   expires = "; expires=" + date.toGMTString();
			   }
			   document.cookie = name + "=" + value + expires + "; path=" + cookieRootPath;
		   } catch( msg ) {}
	   },
	   get: function( name ) {
		   	try {
				var nameEQ = name + "=";
				var ca = document.cookie.split( ';' );
				for ( var i = 0; i < ca.length; i++ ) {
					var c = ca[i];
					while ( c.charAt(0) == " " ) {
						c = c.substring( 1, c.length );
					}
					if ( c.indexOf( nameEQ ) == 0 ) {
						return c.substring(nameEQ.length, c.length);
					}
				}
				return null;
			} catch ( msg ) {
				return null;
			}
		},
		remove: function( name ) {
			alpacaCookie.set( name, '', -1 );
		}
	};

	window.alpacaSessionStorage = {
		getItem: function( name ) {
			try {
				return sessionStorage.getItem( name );
			} catch ( msg ) {
				return null;
			}
		},
		setItem: function( name, value ) {
			try {
				sessionStorage.setItem( name, value );
			} catch ( msg ) {}
		}
	};

	window.alpacaLocalStorage = {
		getItem: function( name ) {
			try {
				return localStorage.getItem( name );
			} catch ( msg ) {
				return null;
			}
		},
		setItem: function( name, value ) {
			try {
				localStorage.setItem( name, value );
			} catch ( msg ) {}
		}
	};

	$.fn.fixGoogleAdsenseInlineStyles = function() {
		var flex = document.getElementById( 'secondary' );
		const observer = new MutationObserver( function( mutations, observer ) {
			flex.style.height = "";
		} );
		observer.observe( flex, {
			attributes: true,
			attributeFilter: [ 'style' ]
		} );
		return this;
	}
} ) ( jQuery );
