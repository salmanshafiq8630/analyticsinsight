( function( $ ) {
   "use strict";
   var $win = $( window ), $doc = $( document ), $body = $( 'body' ), $page = $( '#page' ), $siteHeader = $( '.site-header .site-header-main' ), alpacaAnimations = {}, alpacaMasonry = {};

   alpacaAnimations = {
       'parallaxItems': false,
       'overlayItems': false,
       'fadeInItems': false,
       'sideOverlayItems': false,
       'carouselItems': false,
       'homeBanner': false,
       'slideInImages': false,
       'overlayHeaders': false,
       'init': function() {
           var self = this, list = [
               { 'selector': '.header-img.parallax-scroll .featured-img-container', 'cb': 'processParallax', 'prop': 'parallaxItems' },
               { 'selector': '.posts .post.post-overlay, .header-img.intro-animation', 'cb': 'processOverlay', 'prop': 'overlayItems' },
               { 'selector': '.header-img.intro-animation', 'cb': 'processPageHederOverlay', 'prop': 'pageHeaderOverlayItems' },
               { 'selector': '.posts-enter-animation .posts.layout-grid .posts-wrapper .post', 'cb': 'processFadeIn', 'prop': 'fadeInItems' },
               { 'selector': '.posts.first-side-overlay .post-overlay', 'cb': 'processSideOverlay', 'prop': 'sideOverlayItems' },
               { 'selector': '.home-widget.alpaca-bannr.fullwidth.large-banner-special .section-content .bannr-img', 'cb': 'processHomeBanner', 'prop': 'homeBanner' },
               { 'selector': '.posts-enter-animation .posts.layout-carousel .posts-wrapper', 'cb': 'processCarouselPosts', 'prop': 'carouselItems' },
               { 'selector': 'figure.cta-img', 'cb': 'processSlideInImages', 'prop': 'slideInImages' },
               { 'selector': '.overlay-header', 'cb': 'processOverlayHeader', 'prop': 'overlayHeaders' }
           ], newAdded = [
               { 'selector': '.posts .new-post-item .featured-img-container', 'cb': 'processParallax', 'prop': 'parallaxItems' },
               { 'selector': '.posts .new-post-item.post-overlay', 'cb': 'processOverlay', 'prop': 'overlayItems' },
               { 'selector': '.posts-enter-animation .posts.layout-masonry .posts-wrapper .new-post-item, .posts-enter-animation .posts.layout-grid .posts-wrapper .new-post-item', 'cb': 'processFadeIn', 'prop': 'fadeInItems' }
           ];

           list.map( function ( item ) {
               if ( $( item[ 'selector' ] ).length ) {
                   self[ item[ 'prop' ] ] = $( item[ 'selector' ] );
                   self[ item[ 'cb' ] ] = self[ item[ 'cb' ] ].bind( self );
                   self[ item[ 'cb' ] ]( alpacaParseInt( $win.scrollTop() ) );
                   $win.on( 'load scroll loaded.alpaca.morecontent', function( e ) {
                       self[ item[ 'cb' ] ]( alpacaParseInt( $win.scrollTop() ) );
                   } );
                   $doc.on( 'resize.alpaca.window', function() {
                       self[ item[ 'cb' ] ]( alpacaParseInt( $win.scrollTop() ) );
                   } );
               }
           } );
           $doc.on( 'loftcean/moreContent/loaded', function() {
               newAdded.map( function ( item ) {
                   if ( $( item[ 'selector' ] ).length ) {
                       if ( self[ item[ 'prop' ] ] && self[ item[ 'prop' ] ].length ) {
                           self[ item[ 'prop' ] ] = self[ item[ 'prop' ] ].add( $( item[ 'selector' ] ) );
                       } else {
                           self[ item[ 'prop' ] ] = $( item[ 'selector' ] );
                       }
                   }
               } );
               $win.trigger( 'loaded.alpaca.morecontent' );
           } )
           .one( 'animation.alpaca.masonry', function() {
               var $masonryPosts = $( '.posts-enter-animation .posts.layout-masonry .posts-wrapper .post' ), cbFunc = self.processFadeIn.bind( self );
               if ( $masonryPosts.length ) {
                   if ( self['fadeInItems'] && self['fadeInItems'].length ) {
                       self['fadeInItems'] = self['fadeInItems'].add( $masonryPosts );
                   } else {
                       self['fadeInItems'] = $masonryPosts;
                   }
                   cbFunc( alpacaParseInt( $win.scrollTop() ) );
                   $win.on( 'load scroll loaded.alpaca.morecontent', function() {
                       cbFunc( alpacaParseInt( $win.scrollTop() ) );
                   } );
                   $doc.on( 'resize.alpaca.window', function() {
                       cbFunc( alpacaParseInt( $win.scrollTop() ) );
                   } );
               }
           } );

           self.processSlickSlider();
           if ( ! $( 'html' ).hasClass( 'mobile' ) ) {
               self.processSingleAutoplayVideo();
               self.processListAutoplayVideos();
               if ( $( '.layout-full-overlay.posts').length && $( '.pagination-container.load-more' ).length ) {
                   $doc.on( 'loftcean/moreContent/loaded', function( e, args ) {
                       if ( args && args[ 'videos' ] ) {
                           self.processLoadMoreAutoplayVideos( args[ 'videos' ] );
                       }
                   } );
               }
           }
       },
       'processParallax': function( top ) {
           this.parallaxItems.each( function() {
               var $item = $( this ), $parent = $item.parent(), itemTop = $parent.offset().top, delta = 5,
                   itemBottom = itemTop + $parent.outerHeight( true );
                if ( ( ( top < alpacaParseInt( itemTop ) ) && $item.data( 'top-freeze' ) ) || ( ( top > alpacaParseInt( itemBottom ) ) && $item.data( 'bottom-freeze' ) ) ) return;

               if ( top < itemTop ) {
                   $item.css( { 'transform': '', 'transform-style': '' } ).data( 'top-freeze', true ).data( 'bottom-freeze', false );
               } else if ( top <= itemBottom ) {
                   $item.css( { 'transform-style': 'preserve-3d', 'transform': ( 'translate3d(0, ' + ( top - itemTop ) / 5 + 'px, 0)' ), 'transition': 'all 0s' } ).data( 'top-freeze', false ).data( 'bottom-freeze', false );
               } else {
                   $item.css( { 'transform-style': 'preserve-3d', 'transform': ( 'translate3d(0, ' + ( itemBottom - itemTop ) / 5 + 'px, 0)' ), 'transition': 'all 0s' } ).data( 'bottom-freeze', true ).data( 'top-freeze', false );
               }
           } );
       },
       'processOverlay': function( top ) {
           var self = this;
           if ( self.overlayItems.length ) {
               self.overlayItems.each( function() {
                   if ( ! $( this ).hasClass( 'fade-in' ) ) {
                       var $item = $( this ), startPosition = $item.offset().top - window.alpacaInnerHeight * 0.8;
                       if ( top < startPosition ) return;
                       $item.addClass( 'fade-in' );
                       self.overlayItems = self.overlayItems.not( $item );
                   }
               } );
           }
       },
       'processPageHederOverlay': function( top ) {
           var self = this;
           if ( self.pageHeaderOverlayItems.length ) {
               self.pageHeaderOverlayItems.each( function() {
                   if ( ! $( this ).hasClass( 'animated' ) ) {
                       var $item = $( this ), startPosition = $item.offset().top - window.alpacaInnerHeight * 0.8;
                       if ( top < startPosition ) return;
                       $item.addClass( 'animated' );
                       self.overlayItems = self.overlayItems.not( $item );
                   }
               } );
           }
       },
       'processFadeIn': function( top ) {
           var self = this;
           if ( self.fadeInItems.length ) {
               this.fadeInItems.each( function() {
                   if ( ! $( this ).hasClass( 'fade-in' ) ) {
                       var $item = $( this ), startPosition = alpacaParseInt( $item.offset().top ) - window.alpacaInnerHeight;
                       if ( $body.hasClass( 'site-header-vertical' ) && ( top >= startPosition ) ) {
                           $item.addClass( 'fade-in' );
                           self.fadeInItems = self.fadeInItems.not( $item );
                       }

                       if ( $body.hasClass( 'site-header-horizontal' ) && ( top >= alpacaParseInt( startPosition - $siteHeader.outerHeight( true ) ) ) ) {
                           $item.addClass( 'fade-in' );
                           self.fadeInItems = self.fadeInItems.not( $item );
                       }
                   }
               } );
           }
       },
       'processCarouselPosts': function( top ) {
           var self = this;
           if ( self.carouselItems.length ) {
               self.carouselItems.each( function() {
                   if ( ! $( this ).hasClass( 'fade-in' ) ) {
                       var $item = $( this ), startPosition = alpacaParseInt( $item.offset().top ) - window.alpacaInnerHeight + 100;
                       if ( top < startPosition ) return;
                       $item.addClass( 'fade-in' );
                       self.carouselItems = self.carouselItems.not( $item );
                   }
               } );
           }
       },
       'processSideOverlay': function( top ) {
           this.sideOverlayItems.each( function( e ) {
               var $item = $( this ), $parent = $item.parent(), itemTop = alpacaParseInt( $parent.offset().top ), itemBottom = itemTop + alpacaParseInt( $parent.outerHeight() );

               if ( window.alpacaInnerWidth >= 1120 ) {
                   if ( ( top > itemTop ) && ( top < ( itemBottom - window.alpacaInnerHeight ) ) ) {
                       $item.hasClass( 'is-sticky' ) ? '' : $item.addClass( 'is-sticky' ).removeClass( 'reach-bottom' );
                   } else if ( top >= ( itemBottom - window.alpacaInnerHeight ) ) {
                       $item.hasClass( 'is-sticky' ) ? $item.removeClass( 'is-sticky' ).addClass( 'reach-bottom' ) : '';
                   } else if ( $item.hasClass( 'is-sticky' ) ) {
                       $item.removeClass( 'is-sticky' );
                   }
               }
           } );
       },
       'processHomeBanner': function( top ) {
           this.homeBanner.each( function() {
               var $item = $( this ), $parent = $item.parent(), itemTop = alpacaParseInt( $parent.offset().top ), itemHeight = alpacaParseInt( $parent.outerHeight( true ) ),
                   itemBottom = itemTop + itemHeight, startPosition = itemTop - window.alpacaInnerHeight, centerPosition = itemTop + itemHeight / 2;

               // add the custom height set by user to the banner section, only works when window width >= 768px
               window.alpacaInnerWidth >= 768 ? $parent.css( 'height', $parent.data( 'custom-height' ) ) : $parent.css( 'height', '' );

               ( top >= startPosition ) && ( top <= itemBottom ) && ( window.alpacaInnerWidth >= 768 )
                   ? $item.css( { 'transform-style': 'preserve-3d', 'transform': ( 'translate3d(0, ' + ( ( top + window.alpacaInnerHeight / 2 ) - centerPosition ) / 2 + 'px, 0)' ) } )
                       : $item.css( { 'transform': '', 'transform-style': '' } );
           } );
       },
       'processSlideInImages': function( top ) {
           var self = this;
           if ( self.slideInImages.length ) {
               self.slideInImages.each( function() {
                   if ( ! $( this ).hasClass( 'slide-in' ) ) {
                       var $item = $( this ), startPosition = alpacaParseInt( $item.offset().top ) - window.alpacaInnerHeight + 100;
                       if ( top < startPosition ) return;
                       $item.addClass( 'slide-in' );
                       self.slideInImages = self.slideInImages.not( $item );
                   }
               } );
           }
       },
       'processOverlayHeader': function( top ) {
           var minTop = ( window.alpacaInnerWidth >= 1120 ) ? 300 : 200;
           if ( window.alpacaInnerWidth > 600 ) {
               top > minTop ? this.overlayHeaders.addClass( 'fade-text' ) : this.overlayHeaders.removeClass( 'fade-text' );
           } else {
               this.overlayHeaders.removeClass( 'fade-text' );
           }
       },
       'processListAutoplayVideos': function() {
           var $icons = $( '.format-icon[data-alpaca-video-id^="video-"]' ), videos = [];
           if ( $icons.length ) {
               $icons.each( function() {
                   videos.push( {
                       'args': { 'className': 'featured-video-bg' },
                       'vid': $( this ).data( 'alpaca-video-id' ).replace( 'video-id-', '' ),
                       'container': $( this ).closest( '.loftocean-video-post' ).find( '.featured-img-container' )
                   } );
                   $( this ).removeAttr( 'data-alpaca-video-id' );
               } );
               this.showAutoplayVideo( videos );
           }
       },
       'processLoadMoreAutoplayVideos': function( videosList ) {
           var $icons = $( '.format-icon[data-alpaca-video-id^="video-"]' ), videos = [], vid = false;
           if ( $icons.length ) {
               $icons.each( function() {
                   vid = $( this ).data( 'alpaca-video-id' ).replace( 'video-id-', '' );
                   if ( ! videosList[ vid ] ) return;
                   videos.push( {
                       'args': { 'className': 'featured-video-bg' },
                       'video': videosList[ vid ],
                       'container': $( this ).closest( '.post-overlay' ).find( '.featured-img-container' )
                   } );
                   $( this ).removeAttr( 'data-alpaca-video-id' );
               } );
               this.showAutoplayVideo( videos, 'autoplay.loftocean.video.list' );
           }
       },
       'processSingleAutoplayVideo': function() {
           var videos = [], $btns = $( '.featured-video-play-btn[data-loftocean-video-id^="video-"]' );
           if ( $btns.length ) {
               $btns.each( function() {
                   videos.push( {
                       'args': { 'className': 'header-video-bg' },
                       'vid': $( this ).data( 'loftocean-video-id' ).replace( 'video-id-', '' ),
                       'container': $( this ).siblings( '.header-img-container' ).length ? $( this ).siblings( '.header-img-container' ).find( '.featured-img-container' )
                           : $( this ).closest( '.entry-header' ).find( '.featured-img-container' )
                   } );
               } );
               this.showAutoplayVideo( videos );
           }
       },
       'showAutoplayVideo': function( videos, cbEvent ) {
           cbEvent = cbEvent ? cbEvent : 'autoplay.loftocean.video';
           videos.forEach( function( video ) {
               $doc.trigger( cbEvent, video );
           } );
       },
       'processSlickSlider': function() {
           var $postsGallery = $( '.posts .format-gallery .image-gallery' ), args = {
               dots: 			false,
               infinite: 		true,
               speed: 			500,
               fade: 			true,
               cssEase: 		'linear',
               autoplay: 		true,
               autoplaySpeed: 	5000,
               swipeToSlide: 	true,
               appendArrows:  	false
           };
           [ '.post-content-gallery.gallery-slider .image-gallery', '.loftocean-popup-sliders .popup-slider.gallery-slider .image-gallery' ].forEach( function( selector ) {
               if ( $( selector ).length ) {
                   $( selector ).each( function() {
                       var $gallery = $( this ), arrows = false, currentArgs = $.extend( {}, args );
                       arrows = $( '<div>', { 'class': 'slider-arrows' } );
                       $gallery.after( arrows );
                       currentArgs['appendArrows'] = arrows;
                       if ( $gallery.closest( '.popup-slider' ).length ) {
                           currentArgs['autoplay'] = false;
                       }
                       $gallery.alpacaSlickSlider( currentArgs );
                   } );
               }
           } );

           $.fn.alpacaPostsGallery = function() {
               if ( ! $( this ).length ) return;

               $( this ).each( function() {
                   $( this ).alpacaSlickSlider( args );
               } );
           }
           $postsGallery.length ? $postsGallery.alpacaPostsGallery() : '';
       }
   };

   alpacaMasonry = {
       'init': function() {
           var $masonry = $( '.posts.layout-masonry' );
           if ( $masonry.length ) {
               var site = this;
               site.masonry = $masonry;
               $masonry.data( 'mobile-mode', false ).each( function() {
                   var $layout = $( this );
                   if ( $( this ).find( '.posts-wrapper .post' ).length ) {
                       var list = [];
                       $layout.find( '.posts-wrapper .post' ).each( function() {
                           list.unshift( $( this )    );
                       } );
                       $layout.data( 'post-list', list );
                   } else {
                       $layout.data( 'post-list', false );
                   }
               } );
               $doc.on( 'resize.alpaca.window', function() {
                   var is_mobile = site.isMobileDevice( site.masonry ), current_mode_mobile = site.masonry.first().data( 'mobile-mode' );
                   if ( is_mobile && ! current_mode_mobile ) {
                       site.runMasonryMobileMode( site.masonry );
                   } else if ( ! is_mobile ) {
                       $masonry.each( function() {
                           site.changeMasonryColumnSettings( $( this ) );
                           site.resetMasonryPosts( $( this ) );
                           site.runMasonryDesktopMode( $( this ) );
                       } );
                   }
               } );
               if ( site.isMobileDevice( $masonry ) ) {
                   site.runMasonryMobileMode( $masonry );
               } else {
                   $win.on( 'load', function() { site.processDesktopMasonryLayout( $masonry ); } );
               }
           }
       },
       'processDesktopMasonryLayout': function( $masonry ) {
           var site = this;
           $masonry.each( function() {
               site.changeMasonryColumnSettings( $( this ) );
               site.runMasonryDesktopMode( $( this ), true );
           } );
       },
       'changeMasonryColumnSettings': function( $layout ) {
           if ( window.alpacaInnerWidth > 768 ) {
               if ( window.alpacaInnerWidth < 1024 ) {
                   $layout.data( 'masonry-column', 2 );
               } else {
                   $layout.data( 'masonry-column', $layout.find( '.masonry-column' ).length );
               }
           } else {
               $layout.data( 'masonry-column', false );
           }
       },
       'isMobileDevice': function( $layout ) {
           return $layout.length && $layout.find( '.posts-wrapper .post' ).length && ( window.alpacaInnerWidth < 768 );
       },
       'runMasonryMobileMode': function( $layout ) {
           var site = this;
           $layout.data( 'mobile-mode', true ).each( function() {
               site.resetMasonryPosts( $( this ) );
           } );
           $doc.trigger( 'animation.alpaca.masonry' );
       },
       'resetMasonryPosts': function( $wrap ) {
           if ( $wrap.data( 'post-list' ) ) {
               var list = $wrap.data( 'post-list' ), $container = $wrap.find( '.masonry-column' ).data( 'column-height', 0 ).first();
               list.forEach( function( $p ) {
                   $container.prepend( $p );
               } );
               $wrap.data( 'current', 0 );
               $container.siblings().addClass( 'empty' );
           }
       },
       'runMasonryDesktopMode': function( $layout, resize ) {
           var option = resize ? { 'trigger-sidebar-resize': true } : {};
           $layout.data( 'current', 0 ).find( '.masonry-column' ).data( 'column-height', 0 );
           $layout.data( 'mobile-mode', false ).alpacaMasonry( option );
           $doc.trigger( 'animation.alpaca.masonry' );
       }
   };

   /**
   * Enable masonry for post list with masonry
   * 	Actually it's alreay splite into columns, just reorder it to fit the height
   */
   $.fn.alpacaMasonry = function( args ) {
       var options = $.extend({}, { 'post': '.post', 'append': false, 'trigger-sidebar-resize': false }, args || {} );
       $( this ).each( function() {
           var $masonry = $( this ), selector = options.post;
           if ( $masonry.hasClass( 'layout-masonry' ) && $masonry.find( selector ).length ) {
               var columns = [], length = $masonry.data( 'masonry-column' ) ? $masonry.data( 'masonry-column' ) : 2,
                   current = $masonry.data( 'current' ) || 0, $columns = $masonry.find( '.masonry-column' );
               for ( var i = 0; i < length; i ++ ) {
                   columns.push( $columns.eq( i ).data( 'column-height' ) || 0 );
               }

               $masonry.find( '.posts-wrapper ' + selector ).each( function( index, item ) {
                   var $item = $( item ), lowest = 0;
                   columns[ current ] += alpacaParseInt( $item.outerHeight( true ) );
                   $item.addClass( 'masonry-column-' + current );

                   lowest = columns[ current ];
                   for ( var i = ( length - 1 ); i >= 0; i -- ) {
                       if ( columns[ i ] <= lowest ) {
                           lowest 	= columns[ i ];
                           current = i;
                       }
                   }
               } );
               $columns.each( function( ci, co ) {
                   var column_class = 'masonry-column-' + ci;
                   if ( $masonry.find( '.post.' + column_class ).length ) {
                       $( this ).append( $masonry.find( '.post.' + column_class ).removeClass( column_class ).detach() );
                   }
                   $( this ).data( 'column-height', columns[ ci ] );
                   if ( columns[ ci ] ) {
                       $( this ).hasClass( 'empty' ) ? $( this ).removeClass( 'empty' ) : '';
                   } else {
                       $( this ).hasClass( 'empty' ) ? '' : $( this ).addClass( 'empty' );
                   }
               } );
               $masonry.data( 'current', current );
           }
       } );
       $doc.trigger( 'changed.alpaca.mainContent' );
       return this;
   }

   $doc.on( 'alapca.init', function() {
       alpacaAnimations.init();
       // Process masonry posts layout
       alpacaMasonry.init();
   } );
} ) ( jQuery );
