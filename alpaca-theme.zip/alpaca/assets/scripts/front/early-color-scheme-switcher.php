<script type="text/javascript" id="alpaca-early-color-scheme-switcher">
    function alpaca_early_color_scheme_switcher_is_reversed() {
        var sessionName = '<?php echo esc_js( apply_filters( 'alpaca_color_scheme_switcher_session_name', 'alpacaReverseColorScheme' ) ); ?>';
        try {
            return localStorage.getItem( sessionName ) && ( 'on' == localStorage.getItem( sessionName ) );
        } catch( msg ) {
            return false;
        }
    }
    if ( alpaca_early_color_scheme_switcher_is_reversed() ) {
        var HTMLClassList = document.documentElement.classList;
        HTMLClassList.contains( 'original-light-color' ) ? HTMLClassList.add( 'change-to-color-scheme-dark' ) : HTMLClassList.add( 'change-to-color-scheme-light' );
    }
</script>
