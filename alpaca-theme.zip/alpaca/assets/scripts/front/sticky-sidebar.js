( function( $ ) {
	"use strict";
	var $win = $( window ), $doc = $( document ), alpacaStickySidebar = { };

	alpacaStickySidebar = {
		'isSticky': 			false,
		'primary': 				false,
		'secondary': 			false,
		'container': 			false,
		'mainContent': 		 	false,
		'upThreshholdSet': 		false,
		'downThresholdSet': 	false,
		'sidebarMarginTop': 	'',
		'sidebarPaddingBottom': '',
		'sidebarHeight': 		'',
		'primaryHeight': 		'',
		'delta': 				'',
		'previousAction': 		'',
		'thresholdMax': 		'',
		'thresholdMin': 		'',
		'stickyOffsetTop': 		'',
		'init': function() {
			var self = this, stickySidebar = false;
			self.stickyOffsetTop = $( 'body' ).offset().top;
			self.primary = $( '#primary' );
			self.secondary = $( '#secondary' );
			self.container = $( '#secondary .sidebar-container' );
			self.mainContent = $( '#content' );

			stickySidebar = self.container.length && ( self.secondary.attr( 'data-enable-sticky-sidebar' ) == 'on' );

			if ( self.container.length && self.container.find( '.widget' ).length && stickySidebar && self.primary.length ) {
				$win.one( 'load', function() {
					self.resize();
					self.fixSidebar();

					$( '.main img, .main iframe' ).each( function() {
						self.observeElementLoaded( this );
					} );
					self.observeDOMChanges( $( '.main' ) );

					// Register following events
					$doc.on( 'scrolling.alpaca.window', function( e, args ) {
						if ( args ) {
							self.recalculate( args['top'], self.stickyOffsetTop, args['goUp'] );
						}
					} )
					.on( 'resize.alpaca.window rendered.loftocean.facebook ajaxSuccess', function( e ) {
						self.resize();
						self.fixSidebar();
					} )
					.on( 'changed.alpaca.mainContent', function() {
						self.resize();
					} );
				} );
			}
		},
		'observeElementLoaded': function( target ) {
			if ( $( target ).length ) {
				var self = this;
				$( target ).one( 'load', function() {
					self.resize();
				} );
			}
		},
		'observeDOMChanges': function( target ) {
			if ( $( target ).length ) {
				var self = this,
					targetNode = $( target ).get( 0 ), // Select the node that will be observed for mutations
					config = { attributes: false, childList: true, subtree: true }, // Options for the observer (which mutations to observe)
					callback = function( mutationsList, observer ) { // Callback function to execute when mutations are observed
						//for ( let mutation of mutationsList ) {
						mutationsList.forEach( function( mutation ) {
							if ( mutation.type === 'childList' ) {
								var $targets = ['IMG', 'IFRAME'].includes( mutation.target.tagName ) ? $( mutation.target ) : $( mutation.target ).find( 'img, iframe' );
								if ( $targets.length ) {
									$targets.each( function() {
										self.observeElementLoaded( this );
									} );
								}
							}
						} );
					},
					observer = new MutationObserver( callback );

				// Start observing the target node for configured mutations
				observer.observe( targetNode, config );
			}
		},
		'resize': function() {
			this.sidebarMarginTop 	= alpacaParseInt( this.secondary.css( 'margin-top' ) );
			this.sidebarPaddingBottom = alpacaParseInt( this.secondary.css( 'padding-bottom' ) );
			this.primaryHeight 		= this.primary.height();
			this.sidebarHeight 		= this.secondary.hasClass( 'sidebar-sticky' )
				? alpacaParseInt( this.container.outerHeight( true ) ) + alpacaParseInt( this.sidebarPaddingBottom )
					: ( this.secondary.outerHeight( true ) - this.sidebarMarginTop );
			this.delta 				= this.primaryHeight - this.sidebarHeight;
			this.isSticky 			= this.testSticky();
		},
		'testSticky': function() {
			return ( this.primary.outerWidth( true ) < this.primary.parent().width() ) // Main sidebar is not below main content
				&& ( this.delta > this.sidebarMarginTop ); // Sidebar is shorter than main content
		},
		'fixSidebar': function() {
			if ( this.isSticky && ( 'fixed' != this.container.css( 'position' ) ) ) {
				var stickyOffsetTop = this.stickyOffsetTop, scrollTop = alpacaParseInt( $win.scrollTop() );
				if ( 'static' == this.container.css( 'position' ) ) {
					this.recalculate( scrollTop, stickyOffsetTop, false );
				} else {
					var self = this, runAnimation = false, top = '', fixedTop = '', fixTop = '', fixBottom = '', primaryOffsetTop = self.primary.offset().top,
						sidebarHeight = alpacaParseInt( self.sidebarHeight ), primaryHeight = alpacaParseInt( self.primaryHeight );

					if ( self.sidebarHeight > window.alpacaInnerHeight ) {
						if ( ! this.downThresholdSet ) {
							fixedTop = primaryOffsetTop - window.alpacaInnerHeight;
							fixTop = fixedTop + sidebarHeight;
							fixBottom = fixedTop + primaryHeight;

							if ( ( scrollTop >= fixTop ) && ( scrollTop <= fixBottom ) ) {
								top = scrollTop - self.sidebarHeight + window.alpacaInnerHeight - primaryOffsetTop;
								runAnimation = true;
							} else if ( scrollTop > fixBottom ) {
								top = self.delta;
								runAnimation = true;
							}
						}
					} else {
						var delta = alpacaParseInt( self.delta ), sidebarMarginTop = alpacaParseInt( self.sidebarMarginTop );
						fixedTop = primaryOffsetTop - stickyOffsetTop,
						fixBottom = fixedTop + delta,
						fixTop = fixedTop + sidebarMarginTop;

						if ( scrollTop > fixBottom ) {
							top = delta;
							runAnimation = true;
						} else if ( ( scrollTop >= fixTop ) && ( scrollTop <= fixBottom ) ) {
							top = scrollTop - primaryOffsetTop + sidebarMarginTop;
							runAnimation = true;
						}
					}
					if ( runAnimation ) {
						self.container.animate( { 'top': top }, 170, function() {
							self.recalculate( scrollTop, stickyOffsetTop, false );
						} );
					}
				}
			} else if ( ! this.isSticky ) {
				this.secondary.removeClass( 'sidebar-sticky' );
				this.container.css( { 'position': '', 'top': '' } );
			}
		},
		'recalculate': function( top, offset, goUp ) {
			var $primary = this.primary, $secondary = this.secondary, $container = this.container, clear = true;
			if ( this.isSticky ) {
				var sidebarMarginTop = alpacaParseInt( this.sidebarMarginTop ), sidebarHeight = alpacaParseInt( this.sidebarHeight ),
					primaryHeight = alpacaParseInt( this.primaryHeight ), primaryOffsetTop = $primary.offset().top,
					container_offset_top = $container.offset().top, delta = alpacaParseInt( this.delta );

				$secondary.addClass( 'sidebar-sticky' );
				if ( goUp || ( sidebarHeight <= window.alpacaInnerHeight ) ) {
					var fixedTop = primaryOffsetTop - offset, fixBottom = fixedTop + delta,
						fixTop = fixedTop + sidebarMarginTop;

					this.downThresholdSet = false;
					if ( 'down' == this.previousAction ) {
						if ( 'fixed' == $container.css( 'position' ) ) {
							$container.css( { 'position': 'relative', 'top': ( top - primaryOffsetTop - sidebarHeight + window.alpacaInnerHeight ) } );
						}
						this.thresholdMin = $container.offset().top - offset;
						this.upThreshholdSet = true;
						clear = false;
					} else if( this.upThreshholdSet && ( top > this.thresholdMin ) ) {
						clear = false;
					} else {
						this.upThreshholdSet = false;
						if ( top > fixBottom ) {
							$container.css( { 'position': 'relative', 'top': ( delta + 'px' ) } );
							clear = false;
						} else if ( ( top >= fixTop ) && ( top <= fixBottom ) ) {
							$container.css( { 'position': 'fixed', 'top': ( offset + 'px' ) } );
						 	clear = false;
						}
					}
					this.previousAction = 'up';
				} else {
					var fixedTop 	= primaryOffsetTop - window.alpacaInnerHeight,
						fixTop 	= fixedTop + sidebarHeight,
						fixBottom 	= fixedTop + primaryHeight;

					this.upThreshholdSet = false;
					if ( 'up' == this.previousAction ) {
						if ( 'fixed' == $container.css( 'position' ) ) {
							$container.css( { 'position': 'relative', 'top': ( container_offset_top - primaryOffsetTop ) } );
						}
						this.thresholdMax = alpacaParseInt( container_offset_top ) + alpacaParseInt( sidebarHeight ) - window.alpacaInnerHeight;
						this.downThresholdSet = true;
						clear = false;
					} else if ( this.downThresholdSet && ( top < this.thresholdMax ) ) {
						clear = false;
					} else {
						this.downThresholdSet = false;
						if ( ( top >= fixTop ) && ( top <= fixBottom ) ) {
							$container.css( { 'position': 'fixed', 'top': ( window.alpacaInnerHeight - sidebarHeight ) + 'px' } );
							clear = false;
						} else if ( top > fixBottom ) {
							$container.css( { 'position': 'relative', 'top': ( delta + 'px' ) } );
							clear = false;
						}
					}
					this.previousAction = 'down';
				}
			} else {
				$secondary.removeClass( 'sidebar-sticky' );
				this.previousAction = '';
			}
			if ( clear ) {
				$container.css( { 'position': '', 'top': '' } );
			}
		}
	};

	$doc.on( 'alapca.init', function() {
		alpacaStickySidebar.init();
	} );
} ) ( jQuery );
