( function( $ ) {
	"use strict";
    function alpacaCheckPopupForm() {
        if ( $( '.popup-signup' ).length && alpacaPopupForm.autoDisplay ) {
            var current = new Date(), maxDuration = 2592000000;
            if ( alpacaPopupForm.oncePerSession ) {
                if ( alpacaSessionStorage.getItem( 'alpacaPopupFormVisited' ) ) {
                    return false;
                } else {
                    alpacaSessionStorage.setItem( 'alpacaPopupFormVisited', 'on' );
                }
            }
            if ( alpacaLocalStorage.getItem( 'alpacaDisablePopupForm' ) && alpacaLocalStorage.getItem( 'alpacaPopupFormDisabledTimestamp' ) ) {
                var disabled = 'on' == alpacaLocalStorage.getItem( 'alpacaDisablePopupForm' ),
                    lastDisabledTime = alpacaLocalStorage.getItem( 'alpacaPopupFormDisabledTimestamp' );
                if ( ! disabled || ! lastDisabledTime || ( ( current.getTime() - lastDisabledTime ) > maxDuration ) ) {
                    alpacaLocalStorage.setItem( 'alpacaDisablePopupForm', false );
                    alpacaLocalStorage.setItem( 'alpacaPopupFormDisabledTimestamp', false );
                    alpacaShowPopupForm();
                }
            } else {
                alpacaShowPopupForm();
            }
        }
    }
    function alpacaShowPopupForm() {
        var timer = false, $popupForm = $( '.popup-signup' );
        if ( alpacaPopupForm.timer && ( timer = alpacaParseInt( alpacaPopupForm.timer ) ) ) {
            setTimeout( function() { $popupForm.addClass( 'show' ); }, timer * 1000 )
        } else {
            $popupForm.addClass( 'show' );
        }
    }
	function alpacaAddLocalStorage() {
		var currentTime = new Date();
		alpacaLocalStorage.setItem( 'alpacaDisablePopupForm', 'on' );
		alpacaLocalStorage.setItem( 'alpacaPopupFormDisabledTimestamp', currentTime.getTime() );
	}

    document.addEventListener( 'DOMContentLoaded', function() {
        var $formWrap = $( '.popup-signup' ), hasPopupForm = $formWrap.length && $formWrap.find( 'form' ).length;
        if ( hasPopupForm && alpacaPopupForm ) {
            var $form = $formWrap.find( 'form' );
            alpacaCheckPopupForm();
            $( 'body' ).on( 'click', '.popup-signup.show .close-button, .popup-signup.show .alpaca-exit-popup-signup-form', function( e ) {
    			e.preventDefault();
    			$formWrap.removeClass( 'show' );
    		} )
    		.on( 'click', '.popup-signup.show .alpaca-disable-popup-signup-form', function( e ) {
    			e.preventDefault();
    			alpacaAddLocalStorage();
    			$formWrap.find( '.close-button' ).trigger( 'click' );
    		} )
			.on( 'click', '.header-more-btn.popup-signup-btn', function( e ) {
				if ( $( '.alpaca-disable-popup-signup-form' ).length ) {
					$( '.alpaca-disable-popup-signup-form' ).addClass( 'hide' );
				}
			} )
			.on( 'click', '.popup-signup.show .close-button', function( e ) {
				if ( $( '.alpaca-disable-popup-signup-form' ).length ) {
					$( '.alpaca-disable-popup-signup-form' ).removeClass( 'hide' );
				}
    		} );
            $form.append( $( '<input>', { 'type': 'hidden', 'name': 'action', 'value': alpacaPopupForm.action } ) );
            $form.on( 'submit', function( e ) {
                e.preventDefault();
                if ( $formWrap.hasClass( 'submitting-form' ) ) {
                    return false;
                }
				if ( $formWrap.find( '.mc4wp-response' ).length ) {
					$formWrap.find( '.mc4wp-response' ).remove();
				}
                var formCloned = $( this ).clone(), data = formCloned.find( '[name=_mc4wp_form_id]' ).attr( 'name', 'alpaca_mc4wp_form_id' ).end().serialize();
				$formWrap.addClass( 'submitting-form' );
                $.post( alpacaPopupForm.ajaxURL, data ).done( function( response ) {
                    var noMessage = ! response.data.html, success = response.data && response.data.html && $( response.data.html ).find( '.mc4wp-success' ).length;
                    if ( response.data && response.data.redirect && ( noMessage || success ) ) {
                        alpacaAddLocalStorage();
                        window.location.href = response.data.redirect;
                    } else if ( ! noMessage ) {
                        if ( success ) {
    						$formWrap.addClass( 'subscribed' );
    						alpacaAddLocalStorage();
    					}
                        $form.after( response.data.html );
                    }
                } ).always( function( e ) {
					$formWrap.removeClass( 'submitting-form' );
				} );
            } );
        }
        if ( $( 'form.mc4wp-form' ).length ) {
            var $forms = $( 'form.mc4wp-form' );
            if ( hasPopupForm ) {
                $forms = $forms.not( $formWrap.find( 'form' ) );
            }
            if ( $forms.length ) {
                $forms.on( 'submit', function( e ) {
                    e.preventDefault();
                    if ( $( this ).parent().hasClass( 'submitting-form' ) ) {
                        return false;
                    }

                    var $wrap = $( this ).parent(), formCloned = $( this ).clone(),
                        data = formCloned.find( '[name=_mc4wp_form_id]' ).attr( 'name', 'alpaca_mc4wp_form_id' ).end().serialize();
                    if ( $wrap.find( '.mc4wp-response' ).length ) {
                        $wrap.find( '.mc4wp-response' ).remove();
                    }

                    data += '&action=' + alpacaPopupForm.action;
                    $wrap.addClass( 'submitting-form' );
                    $.post( alpacaPopupForm.ajaxURL, data ).done( function( response ) {
                        var noMessage = ! response.data.html, success = response.data && response.data.html && $( response.data.html ).find( '.mc4wp-success' ).length;
                        if ( response.data && response.data.redirect && ( noMessage || success ) ) {
                            alpacaAddLocalstorage();
                            window.location.href = response.data.redirect;
                        } else if ( ! noMessage ) {
                            if ( success ) {
                                alpacaAddLocalStorage();
                            }
                            $wrap.append( response.data.html );
                        }
                    } ).always( function( e ) {
                        $wrap.removeClass( 'submitting-form' );
                    } );
                } );
            }
        }
    } );
} ) ( jQuery );
